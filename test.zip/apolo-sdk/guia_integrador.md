# Apolo SDK - Guia do Integrador

Bem-vindo! Este guia mostrará como integrar e personalizar o Apolo SDK em seu aplicativo Android. Você aprenderá a iniciar o fluxo de pagamento e a usar as poderosas ferramentas de customização para adaptar a experiência às necessidades do seu negócio.

## 1. Configuração e Inicialização

O ponto de entrada para toda a interação com o SDK é o `ApoloSdk`. A inicialização é feita através de um `Builder`, que permite encadear a configuração do fluxo desejado.

**Exemplo de inicialização do fluxo de Venda:**

```kotlin
// Em sua Activity ou onde for iniciar o fluxo
class MyActivity : AppCompatActivity() {

    fun startSale() {
        // O Builder configura e constrói a instância do SDK para um fluxo específico.
        ApoloSdk.Builder(this)
            .useSale() // Especifica que queremos usar o fluxo de Venda.
            .build()   // Constrói e inicia o fluxo.
    }
}
```
Isso é tudo! O SDK assumirá o controle, exibirá as telas de pagamento e retornará ao seu aplicativo quando o fluxo for concluído.

## 2. Guia de Customização

A verdadeira força do Apolo SDK está em sua capacidade de personalização. Todas as customizações são feitas através do `ApoloSdk.Builder` antes de chamar `.build()`.

### Personalizando a Aparência (`customize`)

Você pode alterar as cores e os textos padrão do SDK para que correspondam à identidade visual do seu aplicativo.

-   **`setColor(ColorToken, Color)`**: Altera uma cor.
-   **`setText(TextToken, String)`**: Altera um texto.

```kotlin
import com.pagonxt.sdk.uxal.core.ColorToken
import com.pagonxt.sdk.uxal.core.TextToken
import androidx.compose.ui.graphics.Color

// ...

ApoloSdk.Builder(this)
    .useSale()
    .customize {
        // Altera a cor primária dos botões e elementos principais
        setColor(
            token = ColorToken("uxal_color_primary"),
            color = Color(0xFF0066CC)
        )

        // Altera o título da tela de venda
        setText(
            token = TextToken("uxal_br_sale_title"),
            value = "Minha Venda"
        )
    }
    .build()
```
> **Nota**: Para uma lista completa de todos os `ColorToken` e `TextToken` disponíveis, consulte a documentação do SDK ou os arquivos de recursos nos módulos `uxal`.

### Inserindo Telas no Fluxo (`addFlowInterstitial`)

Intersticiais permitem que você insira uma tela Composable customizada em meio ao fluxo. É ideal para exibir alertas, pedir confirmações ou coletar informações adicionais.

**Cenário**: Exibir um aviso de "valor alto" se a venda for superior a R$ 1.000.

```kotlin
ApoloSdk.Builder(this)
    .useSale()
    .addFlowInterstitial<SaleFlowState>(
        // CONDIÇÃO: Quando esta tela deve aparecer?
        // Ex: Antes da seleção de produto, se o valor for maior que 1000.
        condition = { state ->
            state is BrSaleFlowState.ProductSelection && state.amount > 100_000 // R$ 1.000,00 em centavos
        },

        // CONTEÚDO: O que esta tela deve mostrar?
        content = { state, proceed ->
            // `state` é o estado que ativou a condição.
            // `proceed` é uma função que você DEVE chamar para continuar o fluxo.
            HighValueWarningDialog(
                onConfirm = { proceed() }, // Ao confirmar, o fluxo continua.
                onCancel = { finish() }    // Ao cancelar, podemos fechar a activity.
            )
        }
    )
    .build()
```

### Substituindo a Experiência do Usuário

Para uma customização completa, você pode substituir toda a camada de UI de um fluxo do SDK.
Mantendo a lógica de negócios intacta. Isso é possível passando uma fábrica de `ContentBuilder` para 
um dos métodos de ativação de Fluxo. Ex:. o método `useSale`.

**Cenário**: Você quer substituir completamente a experiência de usuário do fluxo de venda do Brasil, 
usando seus próprios componentes e navegação.

```kotlin
// 1. Crie sua implementação de ContentBuilder, que será seu novo roteador de UI.
class MyCustomSaleScreen : ContentBuilder<SaleFlowState, SaleFlowIntent> {
    @Composable
    override fun Content(
        resourceResolver: ResourceResolver,
        flowState: SaleFlowState,
        onIntent: (SaleFlowIntent) -> Unit,
        onExit: () -> Unit
    ) {
        // Você deve tratar TODOS os estados possíveis do fluxo de venda aqui.
        when(flowState) {
            is BrSaleFlowState.AmountDefinition -> MyAmountScreen(state = flowState, onIntent = onIntent)
            is BrSaleFlowState.ProductSelection -> MyProductScreen(state = flowState, onIntent = onIntent)
            // ... e todos os outros estados do BrSaleFlowState
            else -> DefaultErrorScreen(onExit = onExit)
        }
    }
}

// 2. Registre seu ContentBuilder customizado.
ApoloSdk.Builder(this)
    .useSale {
        MyCustomSaleScreen()
    }
    .build()
```

### Executando Lógica de Negócios com Hooks (`preHookAction` e `postHookAction`)

Hooks são a ferramenta mais poderosa para integrar lógicas de negócio externas. Eles permitem executar código `suspend` **antes** ou **depois** que um estado específico do fluxo seja processado.

-   **`preHookAction`**: Executa **antes** do estado ser emitido para a UI. Ideal para validar dados ou executar uma lógica que pode impedir a transição para aquele estado.
-   **`postHookAction`**: Executa **depois** que o estado já foi emitido. Perfeito para reagir a um evento (ex: "transação aprovada") ou para acionar uma ação subsequente.

**Cenário 1: Usando `preHookAction` para validação**
Antes de mostrar a tela de captura de cartão, verificar em um sistema externo se o terminal está habilitado para a venda.

```kotlin
.preHookAction<BrSaleFlowState.CardCapture.Presentation> { context, state, onIntent ->
    // Este bloco é executado ANTES da tela de "aproxime o cartão" aparecer.
    
    val terminalEnabled = myBackend.isTerminalEnabled() // Chamada de API (suspend)
    
    if (!terminalEnabled) {
        // Se o terminal não estiver habilitado, podemos, por exemplo,
        // finalizar o fluxo com uma intenção customizada.
        onIntent(BrSaleFlowIntent.AbortTransaction("Terminal Inativo"))
        return@preHookAction false // Retorna `false` para impedir a continuação do fluxo.
    }

    return@preHookAction true // Retorna `true` para permitir que o fluxo continue normalmente.
}
```

**Cenário 2: Usando `postHookAction` para reagir a um evento**
Após um cartão ser capturado com sucesso, chamar um serviço para verificar se o cliente possui 
alguma pontuação de pontos fidelidade

```kotlin
.postHookAction<BrSaleFlowState.CardCapture.Success> { context, state, onIntent ->
    // Este bloco é executado imediatamente DEPOIS que o cartão foi capturado, mas antes de iniciar a venda.
    
    try {
        var loyaltyData = loyaltySdk.checkDiscount(
            amount = state.amount,
            currencyCode = "BRL",
            method = when (state.method) {
                BrSaleMethod.CREDIT_CARD -> "CREDIT_CARD"
                BrSaleMethod.DEBIT_CARD -> "DEBIT_CARD"
                BrSaleMethod.PIX -> "PIX"
                else -> "OTHER"
            },
            cardMaskedPan = state.cardData.maskedPan,
            cardBin = state.cardData.bin,
            cardHolderName = state.cardData.cardholderName
        )
        // Intenções podem ser negadas caso não atendam os requisitos transacionais (ex: amount <= 0).
        return@postHookAction onIntent(BrSaleFlowIntent.ChangeAmount(loyaltyData.amountAfterDiscount))
    } catch (e: Exception) {
        // Lidar com falhas de comunicação, etc.
        return@postHookAction true ou false
    }
}
```

**Pontos Chave sobre Hooks**:
-   **Assíncronos**: A natureza `suspend` permite integrações limpas com outras bibliotecas (Retrofit, Room, etc.).
-   **Modificação de Fluxo**: Usando o callback `onIntent`, eles podem injetar novas intenções no `FlowEngine`.
-   **Controle de Fluxo**: Podem parar (`return false`) ou continuar (`return true`) o fluxo principal.

---

Ao dominar essas ferramentas de customização, você pode adaptar o Apolo SDK para praticamente qualquer necessidade de negócio, mantendo a integração simples e robusta.
