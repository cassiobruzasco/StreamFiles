package com.pagonxt.brazil.customizations

import com.pagonxt.sdk.core.presentation.navigation.SdkRoute
import kotlinx.serialization.Serializable

@Serializable
data object PartnerInterstitialRoute : SdkRoute