package com.pagonxt.brazil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.navigation.compose.rememberNavController
import com.pagonxt.brazil.customizations.PartnerInterstitialRoute
import com.pagonxt.brazil.interstitial.DeveloperInterstitialGuide
import com.pagonxt.sdk.core.presentation.navigation.SdkFlowInterceptor
import com.pagonxt.sdk.core.presentation.navigation.SdkRoute
import com.pagonxt.sdk.core.presentation.navigation.SdkUiNavigationConfig
import com.pagonxt.sdk.uxal.brazil.navigation.BrSaleNavGraph
import com.pagonxt.sdk.uxal.brazil.navigation.BrSdkRoutes

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize Koin Not here, but inside the Application class
        // startKoin {
        //     androidContext(this@MainActivity)
        //     modules(brazilPaymentModule, brazilHalModule, etc)
        // }

        // 2. Define the UI Interceptor Rules (The Slot API Configuration)
        val sdkConfig = SdkUiNavigationConfig(
            interceptor = object : SdkFlowInterceptor {
                override fun overrideNextRoute(
                    currentRoute: SdkRoute,
                    defaultNextRoute: SdkRoute
                ): SdkRoute {
                    // Business Rule: Hijack the flow after Amount Selection and show the Partner Interstitial
                    if (currentRoute is BrSdkRoutes.AmountAndProduct && defaultNextRoute is BrSdkRoutes.CardReading) {
                        return PartnerInterstitialRoute
                    }
                    return defaultNextRoute
                }
            },
            customScreens = mapOf(
                PartnerInterstitialRoute::class to { resumeFlow ->
                    // Render our custom screen
                    DeveloperInterstitialGuide(
                        onProceed = {
                            // Give control back to the SDK, telling it to go to Card Reading
                            resumeFlow(BrSdkRoutes.CardReading)
                        }
                    )
                }
            )
        )

        setContent {
            MaterialTheme {
                val navController = rememberNavController()

                BrSaleNavGraph(
                    navController = navController,
                    sdkConfig = sdkConfig
                )
            }
        }
    }
}