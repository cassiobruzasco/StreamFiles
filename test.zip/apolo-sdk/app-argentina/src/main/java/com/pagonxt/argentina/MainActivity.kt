package com.pagonxt.argentina

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.graphics.Color
import com.pagonxt.sdk.ApoloSdk
import com.pagonxt.sdk.core.uxal.ColorToken
import com.pagonxt.sdk.theme.GetnetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ApoloSdk.Builder(this)
            .useSale()
            .customize {
                setColor(ColorToken("uxal_color_primary"), Color(0xFFF44336))
            }
            .build()
        enableEdgeToEdge()
        setContent {
            GetnetTheme {
                LauncherHome()
            }
        }
    }
}