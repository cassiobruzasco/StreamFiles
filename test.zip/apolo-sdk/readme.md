# Apolo SDK - Guia de Arquitetura e Desenvolvimento

Bem-vindo ao Apolo SDK. Este documento serve como um guia para entender, manter e estender a arquitetura do projeto. O SDK foi desenvolvido sobre princípios de modularidade e extensibilidade, visando um forte desacoplamento entre a lógica de negócios e a interface do usuário (UI).

## Conceitos Fundamentais

Antes de iniciar o desenvolvimento, é essencial compreender os seguintes conceitos:

### 1. Fluxo (`FlowEngine`, `FlowState`, `FlowIntent`)

O termo "Fluxo" (ou `Flow`) é a nomenclatura central do SDK, utilizada para padronizar a comunicação entre as equipes de negócio e desenvolvimento. Um Fluxo representa qualquer operação orientada pelo SDK que aciona uma interface de usuário em primeiro plano.

-   **No contexto de negócios**: Um Fluxo pode ser uma venda, um cancelamento, uma consulta, etc.
-   **Tecnicamente**: Um Fluxo é uma máquina de estados finitos que orquestra as etapas de uma operação, como uma venda ou um cancelamento.

Este conceito baseia-se no padrão de arquitetura MVI (Model-View-Intent) para promover uma clara separação entre a lógica de negócios e a UI.

Um Fluxo é construído através da implementação do contrato `FlowEngine` (Motor de Fluxo), que opera com `FlowIntent`s e `FlowState`s.

-   **`FlowState`**: Representa um estado específico no fluxo. É um objeto imutável que contém todos os dados necessários para a UI se renderizar. Exemplos: `AmountDefinition`, `CardCapture.Presentation`.
-   **`FlowIntent`**: Representa uma ação do usuário ou um evento do sistema que instrui a máquina de estados a processar uma lógica e, eventualmente, transitar para um novo estado. Exemplos: `ChangeAmount`, `SelectProduct`.

A implementação do `FlowEngine` foca exclusivamente em processar `FlowIntent`s e emitir `FlowState`s, delegando a responsabilidade pela usabilidade e renderização de componentes visuais.

### 2. Construtor de Conteúdo (`ContentBuilder`)

O `ContentBuilder` é o componente responsável por reagir às emissões de `FlowState`s.

Ao iniciar um fluxo (como uma venda), o SDK conecta as implementações adequadas do `FlowEngine` e do `ContentBuilder` para a operação desejada. Sempre que um `FlowState` é emitido pelo `FlowEngine`, o `ContentBuilder` correspondente é acionado para fornecer o conteúdo (`@Composable`) adequado para esse estado.

No sentido inverso, quando o usuário interage com a UI, o `ContentBuilder` pode emitir `FlowIntent`s de volta para o `FlowEngine`, fechando o ciclo do MVI.

### 3. A Conexão: `FlowEngine` <-> `ContentBuilder`

A interligação entre o `FlowEngine` e o `ContentBuilder` é realizada por meio das abstrações presentes no módulo `:sdk`. Este módulo, além de fornecer a API `ApoloSdk` para parametrização e inicialização, conecta as partes que compõem um Fluxo.

Baseados no conceito de *Single-Activity Architecture*, a `FlowActivity` e o `FlowViewModel` atuam como entidades genéricas e centrais na orquestração de qualquer fluxo.

### 4. Abstração por País (Gradle e Injeção de Dependência)

O SDK é dividido em módulos independentes que isolam responsabilidades, permitindo que cada país tenha sua própria lógica de negócios e UI.

Os principais módulos são:

-   **`:sdk:core` (Domínio Central)**: Contém os elementos de domínio comuns a todos os países.
-   **`:sdk:payment:{pais}` (Backend)**: Contém a lógica de negócios específica de um país.
-   **`:sdk:uxal:{pais}` (Frontend - User eXperience Abstraction Layer)**: Contém a implementação da UI de um país.

Como o módulo `:sdk` (núcleo) utiliza a implementação correta de um país sem acoplamento direto?

A solução é aplicada em **tempo de compilação** através do uso de `Flavors` do Gradle. O `build.gradle.kts` do módulo `:sdk` declara dependências diferentes com base no `Flavor` selecionado (país).

Dessa forma, o SDK é distribuído como uma biblioteca específica para cada mercado. Exemplos:

-   `com.pagonxt.sdk:apolo-brazil`
-   `com.pagonxt.sdk:apolo-argentina`

---

## Recursos Avançados: Customizando o Fluxo

O `ApoloSdk.Builder` oferece APIs para customizar o comportamento e a aparência do SDK sem a necessidade de alterar o código-fonte dos módulos.

### White-Label Nível 1: `ContentOverriding`

Permite a customização de recursos da UI, como textos e cores, de forma programática. É possível substituir o conteúdo de elementos padronizados nas telas pré-implementadas, mantendo o wireframe original.

```kotlin
ApoloSdk
    .Builder(this)
    .customize {
        // Altera o texto de um botão ou título
        setText(TextToken("uxal_br_sale_title"), "Venda Customizada")
        
        // Altera uma cor primária ou de um componente
        setColor(ColorToken("uxal_color_primary"), Color(0xFF3AE170))
    }
```

### White-Label Nível 2: `addFlowInterstitial`

Permite inserir uma tela `@Composable` totalmente customizada (um "intersticial") em um ponto específico de um fluxo. O SDK interrompe a execução padrão, exibe a tela customizada e aguarda um callback (`proceed`) para continuar.

-   **`condition`**: Uma função lambda que recebe o `FlowState` atual e retorna `true` se o intersticial deve ser exibido.
-   **`content`**: Uma função `@Composable` que define a UI do intersticial.

```kotlin
ApoloSdk
    .Builder(this)
    .addFlowInterstitial<SaleFlowState>(
        // CONDIÇÃO: Exibir antes da seleção de produto, se o valor for maior que zero.
        condition = { state ->
            state is BrSaleFlowState.ProductSelection && state.amount > 0
        },
        // CONTEÚDO: Sua tela customizada.
        content = { state, proceed ->
            MyCustomInterstitialScreen(
                onContinue = { proceed() }, // Chama proceed() para continuar o fluxo do SDK
                onCancel = { finishActivity() }
            )
        }
    )
```

### White-Label Nível 3: `FlowOverriding`

Permite que **toda a experiência de usuário (UX) padrão de um fluxo** seja completamente substituída por uma implementação customizada fornecida pelo integrador.

```kotlin
class CustomSaleContentBuilder : ContentBuilder<SaleFlowState, SaleFlowIntent> {
    
    @Composable
    override fun Content(
        resourceResolver: ResourceResolver,
        flowState: SaleFlowState,
        onIntent: (SaleFlowIntent) -> Unit,
        onExit: () -> Unit
    ) {
        Scaffold() {
            // Sua customização aqui
        }
    }
}
ApoloSdk
    .Builder(this)
    .useSale {
        CustomSaleContentBuilder()
    }
```

### Interceptadores de Fluxo (Hooks): `preHookAction` e `postHookAction`

Permitem injetar uma lógica de negócios customizada **antes** (`pre`) ou **depois** (`post`) que um `FlowState` específico seja emitido. São úteis para cenários como chamadas de API, registro de eventos de analytics ou alteração do fluxo de execução.

-   **`preHookAction`**: Executado **antes** do estado ser emitido para a UI. Pode ser usado para validar uma condição e, opcionalmente, impedir a transição de estado.
-   **`postHookAction`**: Executado **depois** que o estado já foi emitido. Ideal para reagir a um evento.

```kotlin
class AfterCardReadHook : FlowHook {
    override suspend fun action(
        context: Context,
        flowState: FlowState,
        onIntent: (FlowIntent) -> Boolean
    ): Boolean {
        val saleState = flowState as BrSaleState
        if (saleState.cardData?.applicationName?.contains("VISA") == true) {
            Log.i("AfterCardReadHook", "Cliente VISA")
            delay(2000)
        }
        return true
    }
}

class BeforeCardReadingHook : FlowHook {
    override suspend fun action(
        context: Context,
        flowState: FlowState,
        onIntent: (FlowIntent) -> Boolean
    ): Boolean {
        val saleState = flowState as BrSaleState
        if (saleState.paymentMethod != BrSaleMethod.CREDIT_CARD) {
            return true
        }
        delay(5000)
        return true
    }
}

ApoloSdk
    .Builder(this)
    // HOOK ANTES DA CAPTURA DE CARTÃO
    .preHookAction<BrSaleFlowState.CardCapture.Presentation> {
        BeforeCardReadingHook()
    }
    // HOOK DEPOIS DO SUCESSO DA CAPTURA
    .postHookAction<BrSaleFlowState.CardCapture.Success> {
        AfterCardReadHook()
    }
```