plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.maven.publish)
}

kotlin {
    jvmToolchain(rootProject.extra["jvmToolchainVersion"] as Int)
}

android {
    namespace = "com.pagonxt.sdk.brazil"
    compileSdk {
        version = release(rootProject.extra["compileSdkVersion"] as Int)
    }

    defaultConfig {
        minSdk = rootProject.extra["minSdkVersion"] as Int

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
    }

    publishing {
        singleVariant("release") {
            withJavadocJar()
        }
    }
}

afterEvaluate {
    publishing {
        publications {
            create<MavenPublication>("release") {
                from(components["release"])

                groupId = "com.pagonxt.sdk"
                artifactId = "pagonxt-sdk-hal-brazil"
                version = "1.0.0-SNAPSHOT"
            }
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(project(":sdk:hal:middleware"))
    implementation(project(":sdk:core"))
    implementation(project(":sdk:uxal:ui-common"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.material)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.navigation.compose)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)

    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.foundation.layout)

    // AndroidX Lifecycle (ViewModel)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)

    // Koin DI
    implementation(platform(libs.koin.bom))
    implementation(libs.koin.android)
    testImplementation(libs.koin.test)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    //  New HAL
    // TODO: remove this local libs when upload to jfrog
    implementation(fileTree("libs"))
//    implementation(libs.middleware.libplatform.get().toString() + "@aar")
//    implementation(libs.middleware.libposdigital.get().toString() + "@aar")
    implementation(libs.middleware.utils.get().toString() + "@aar")
}