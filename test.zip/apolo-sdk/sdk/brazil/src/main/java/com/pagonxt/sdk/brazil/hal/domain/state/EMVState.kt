package com.pagonxt.sdk.brazil.hal.domain.state

import com.pagonxt.hal.emvKernel.CardData
import com.pagonxt.hal.emvKernel.Errors
import com.pagonxt.hal.emvKernel.ProcessResult
import com.pagonxt.hal.emvKernel.ResultData

sealed class EMVState {
    data object WaitingForCard : EMVState()
    data class CardDetected(
        val contact: String,
        val contactless: Boolean,
        val tap: Boolean
    ) : EMVState()

    data class SelectApplication(val list: List<String>) : EMVState()
    data object RequestPin : EMVState()
    data class PinDigitsChanged(val digit: Int) : EMVState()
    data object Processing : EMVState()
    data class Approved(
        val cardData: CardData?,
        val processResult: ProcessResult?,
        val resultData: ResultData?
    ) : EMVState()

    data class Declined(val data: String) : EMVState()
    data class Error(val error: Errors?) : EMVState()
    data object RemoveCard : EMVState()
    data object Finished : EMVState()
}