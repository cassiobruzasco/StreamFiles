package com.pagonxt.sdk.brazil.payment.domain.models

import com.pagonxt.sdk.core.domain.models.PaymentStep

/**
 * Brazil-specific steps that do not exist in the core flows.
 */
sealed interface BrPaymentStep : PaymentStep {
    data object PixQRCodeGeneration : BrPaymentStep
    data object VoucherValidation : BrPaymentStep
}