package com.pagonxt.sdk.brazil.payment.domain.models

/**
 * Represents the granular steps during an EMV chip capture.
 */
sealed interface BrSaleCapturingStep {
    data object Pin : BrSaleCapturingStep
    data object Online : BrSaleCapturingStep
}