package com.pagonxt.sdk.brazil.hal.domain.extension

import com.pagonxt.hal.emvKernel.AIDParameter
import com.pagonxt.hal.emvKernel.AIDParameter.ContactGeneric
import com.pagonxt.hal.emvKernel.AIDParameter.ContactMasterCard
import com.pagonxt.hal.emvKernel.AIDParameter.ContactlessAMEX
import com.pagonxt.hal.emvKernel.AIDParameter.ContactlessDiscover
import com.pagonxt.hal.emvKernel.AIDParameter.ContactlessMasterCard
import com.pagonxt.hal.emvKernel.AIDParameter.ContactlessVISA
import com.pagonxt.sdk.brazil.hal.constant.AidTableConst.AID_MASTER_CARD
import com.pagonxt.sdk.brazil.hal.constant.AidTableConst.AMEX_CONTACTLESS_READER_CAPABILITIES
import com.pagonxt.sdk.brazil.hal.constant.AidTableConst.TERMINAL_CAPABILITIES_CVM_BELOW_CVM_LIMIT
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildAMEXEnhancedContactlessReaderCapabilities
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildOnDeviceVerification
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTTQDiscover
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTTQVisa
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTerminalCapabilitiesAboveCVM
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTerminalCapabilitiesGeneral
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTerminalCapabilitiesODA
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.buildTerminalRiskManagementData
import com.pagonxt.sdk.brazil.hal.domain.utils.AidTableModelUtils.parseIfZero
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.AMEX_EXPRESS_PAY_EMV_MODE
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.AMEX_EXPRESS_PAY_MAG_STRIPE_MODE
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.D_PAS_EMV_MODE
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.D_PAS_MAG_STRIPE_MODE
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.MASTERCARD_PAY_PASS_MAG_STRIPE
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.MASTERCARD_PAY_PASS_M_CHIP
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.NOT_SUPPORTED
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.VISA_MSD
import com.pagonxt.sdk.hal.middleware.domain.enum.AidContactlessAppSupportEnum.VISA_VSDC
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel

internal fun AidTableModel.toAIDParameter(): AIDParameter {
    val cardBrandContactless =
        AidContactlessAppSupportEnum.from(value = appSupportContactless.toInt())

    val aidCode = code.uppercase()

    return when (cardBrandContactless) {
        VISA_MSD, VISA_VSDC ->
            ContactlessVISA(
                aid = aidCode,
                transactionLimit = transactionLimitContactless.toLong(),
                cvmLimit = requestCVMContactless.toLong(),
                floorLimit = parseIfZero(floorContactless, floor).toLong(),
                forcedOnline = true,
                ttq = buildTTQVisa(
                    terminalCapabilities = terminalCapability,
                    /**
                     * Follow as is on CreateStringAIDS() in line 82, fix value "0"(false)
                     */
                    issuerScript = false,
                    terminalType = type
                )
            )

        MASTERCARD_PAY_PASS_MAG_STRIPE, MASTERCARD_PAY_PASS_M_CHIP ->
            ContactlessMasterCard(
                aid = aidCode,
                transactionLimit = transactionLimitContactless.toLong(),
                transactionLimitMobile = transactionLimitContactless.toLong(),
                cvmLimit = requestCVMContactless.toLong(),
                floorLimit = parseIfZero(floorContactless, floor).toLong(),
                versionList = listOf(version1, version2, version3),
                forcedOnline = true,
                onDeviceVerification = buildOnDeviceVerification(
                    terminalCapabilities = terminalCapability
                ),
                terminalRiskManagementData = buildTerminalRiskManagementData(
                    terminalCapabilities = terminalCapability
                ),
                transactionCategoryCode = transactionCategoryCode.toInt(16).toChar().toString(),
                tacOnline = parseIfZero(
                    terminalActionCodeOnlineContactless,
                    terminalActionCodeOnline
                ),
                tacDenial = parseIfZero(
                    terminalActionCodeDenialContactless,
                    terminalActionCodeDenial
                ),
                tacDefault = parseIfZero(
                    terminalActionCodeDefaultContactless,
                    terminalActionCodeDefault
                ),
                terminalCapabilitiesGeneral =
                    buildTerminalCapabilitiesGeneral(
                        terminalCapabilities = terminalCapability
                    ),
                terminalCapabilitiesCVMAboveCvmLimit =
                    buildTerminalCapabilitiesAboveCVM(
                        terminalCapabilities = terminalCapability
                    ),
                terminalCapabilitiesCVMBelowCvmLimit = TERMINAL_CAPABILITIES_CVM_BELOW_CVM_LIMIT,
                terminalCapabilitiesODA =
                    buildTerminalCapabilitiesODA(
                        terminalCapabilities = terminalCapability
                    ),
                rrp = true,
                magStripeApplicationVersionNumber = magStripeVRSContactless
            )

        AMEX_EXPRESS_PAY_MAG_STRIPE_MODE, AMEX_EXPRESS_PAY_EMV_MODE ->
            ContactlessAMEX(
                aid = aidCode,
                transactionLimit = transactionLimitContactless.toLong(),
                cvmLimit = requestCVMContactless.toLong(),
                floorLimit = parseIfZero(floorContactless, floor).toLong(),
                versionList = listOf(version1, version2, version3),
                tacOnline = parseIfZero(
                    terminalActionCodeOnlineContactless,
                    terminalActionCodeOnline
                ),
                tacDenial = parseIfZero(
                    terminalActionCodeDenialContactless,
                    terminalActionCodeDenial
                ),
                tacDefault = parseIfZero(
                    terminalActionCodeDefaultContactless,
                    terminalActionCodeDefault
                ),
                terminalCapabilities = terminalCapability,
                contactlessReaderCapabilities = AMEX_CONTACTLESS_READER_CAPABILITIES,
                enhancedContactlessReaderCapabilities =
                    buildAMEXEnhancedContactlessReaderCapabilities(
                        terminalContactlessCapabilities = terminalCapability
                    ),
                forcedOnline = true
            )

        D_PAS_MAG_STRIPE_MODE, D_PAS_EMV_MODE ->
            ContactlessDiscover(
                aid = aidCode,
                transactionLimit = transactionLimitContactless.toLong(),
                cvmLimit = requestCVMContactless.toLong(),
                floorLimit = parseIfZero(floorContactless, floor).toLong(),
                forcedOnline = true,
                ttq = buildTTQDiscover(
                    terminalCapabilities = terminalCapability,
                    /**
                     * Follow as is on CreateStringAIDS() in line 82, fix value "0"(false)
                     */
                    issuerScript = false,
                    terminalType = type
                )
            )

        NOT_SUPPORTED -> {
            if (aidCode == AID_MASTER_CARD &&
                (appSupportContactless != MASTERCARD_PAY_PASS_M_CHIP.toString() ||
                        appSupportContactless != MASTERCARD_PAY_PASS_MAG_STRIPE.toString())
            ) {
                ContactMasterCard(
                    aid = aidCode,
                    floorLimit = parseIfZero(floorContactless, floor).toLong(),
                    versionList = listOf(version1, version2, version3),
                    forcedOnline = true,
                    terminalRiskManagementData = buildTerminalRiskManagementData(
                        terminalCapabilities = terminalCapability
                    ),
                    transactionCategoryCode = transactionCategoryCode.toInt(16).toChar().toString(),
                    tacOnline = terminalActionCodeOnline,
                    tacDenial = terminalActionCodeDenial,
                    tacDefault = terminalActionCodeDefault
                )
            } else {
                ContactGeneric(
                    aid = aidCode,
                    floorLimit = floor.toLong(),
                    forcedOnline = true,
                    versionList = listOf(version1, version2, version3),
                    tacOnline = terminalActionCodeOnline,
                    tacDenial = terminalActionCodeDenial,
                    tacDefault = terminalActionCodeDefault
                )
            }
        }
    }
}