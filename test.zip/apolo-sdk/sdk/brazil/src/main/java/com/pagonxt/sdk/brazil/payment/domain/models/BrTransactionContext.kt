package com.pagonxt.sdk.brazil.payment.domain.models

import com.pagonxt.sdk.core.domain.models.CardData
import com.pagonxt.sdk.core.domain.models.TransactionData
import com.pagonxt.sdk.hal.middleware.domain.model.ProcessResultModel

data class SaleParams(
    val amountInCents: Long = 0,
    val paymentMethod: BrSaleMethod? = null,
)

/**
 * Brazil implementation of TransactionData, extending the core contract
 * with Brazil-specific data like BrSaleMethod and ProcessResultModel.
 */
data class BrTransactionContext(
    val params: SaleParams,
    override val cardData: CardData? = null,
    val processResult: ProcessResultModel? = null
) : TransactionData {

    override val amountInCents: Long
        get() = params.amountInCents

    override val isReadyToCapture: Boolean
        get() = params.amountInCents > 0 && params.paymentMethod != null

    override val isCardCaptured: Boolean
        get() = cardData != null && processResult != null
}