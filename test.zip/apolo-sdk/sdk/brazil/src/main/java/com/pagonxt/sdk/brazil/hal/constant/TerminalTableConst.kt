package com.pagonxt.sdk.brazil.hal.constant

internal object TerminalTableConst {
    const val TERMINAL_CAPABILITIES = "E0F8C8"
    const val TERMINAL_ADDITIONAL_CAPABILITIES = "F000F0A001"
}