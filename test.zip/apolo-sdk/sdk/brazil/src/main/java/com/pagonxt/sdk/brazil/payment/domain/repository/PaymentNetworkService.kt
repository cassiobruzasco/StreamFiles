package com.pagonxt.sdk.brazil.payment.domain.repository

import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel

interface AidService {
    suspend fun getAidTable(): List<AidTableModel>
}

interface PaymentNetworkService {
    suspend fun postPayment(amountInCents: Int, pan: String, tagsEmv: String, track2: String)
}