package com.pagonxt.sdk.brazil.payment.domain.usecases

import android.os.Build
import androidx.annotation.RequiresApi
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVParams
import com.pagonxt.sdk.brazil.hal.domain.state.EMVState
import com.pagonxt.sdk.brazil.hal.domain.usecase.ObserveEMVEventsUseCase
import com.pagonxt.sdk.brazil.hal.domain.usecase.StartEMVTransactionUseCase
import com.pagonxt.sdk.brazil.payment.data.mapper.BrCardDataMapper
import com.pagonxt.sdk.brazil.payment.domain.repository.AidService
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext

/**
 * Caso de Uso de Domínio Puro para executar o processo de captura de cartão EMV.
 * Totalmente desacoplado do Android Context, estados de UI ou ViewModels.
 */
class BrRequestCardCaptureUseCase(
    private val repository: BrTransactionRepository,
    private val aidService: AidService,
    private val startEMVUseCase: StartEMVTransactionUseCase,
    private val observeEMVEventsUseCase: ObserveEMVEventsUseCase,
    private val cardDataMapper: BrCardDataMapper
) {
    // Mutex previne acessos concorrentes ao hardware (ex: duplo clique acidental em "Pagar")
    private val hardwareMutex = Mutex()

    @RequiresApi(Build.VERSION_CODES.O)
    suspend operator fun invoke(): CardCaptureResult = withContext(Dispatchers.IO) {
        if (!hardwareMutex.tryLock()) {
            return@withContext CardCaptureResult.HardwareError("BUSY", "Terminal is already in use.")
        }

        try {
            val transaction = repository.currentTransaction.value
            if (transaction == null || transaction.amountInCents <= 0) {
                return@withContext CardCaptureResult.InvalidAmount("Transaction not initialized or amount is zero.")
            }

            // 1. Busca a Tabela AID de forma segura e sequencial
            val aidList = aidService.getAidTable()

            // 2. Prepara os parâmetros para o terminal
            val emvParams = EMVParams(
                aidModels = aidList,
                strCodProd = transaction.params.paymentMethod?.code ?: "01",
                amount = transaction.amountInCents
            )

            // 3. Prevenção de Race Condition:
            // Preparamos o observador de fluxo ANTES de ligar o kernel EMV.
            // Isso garante que não perderemos estados terminais rápidos como 'Approved' ou 'Declined'.
            val terminalStateDeferred = async {
                observeEMVEventsUseCase()
                    .first { state ->
                        // Fica bloqueado aqui até que um estado final seja emitido
                        state is EMVState.Approved || state is EMVState.Error || state is EMVState.Declined
                    }
            }

            // 4. Inicia o kernel do hardware
            startEMVUseCase.startTransaction(emvParams)

            // 5. Suspende a execução até que o hardware termine seu trabalho e emita o resultado
            val terminalState = terminalStateDeferred.await()

            // 6. Avalia o resultado e atualiza a Fonte de Verdade (Repositório)
            return@withContext when (terminalState) {
                is EMVState.Approved -> {
                    val rawHalCardData = terminalState.cardData

                    if (rawHalCardData != null) {
                        // O Adapter traduz o dado cru do middleware para o modelo estrito do Domínio
                        val coreCardData = cardDataMapper.mapToDomain(rawHalCardData)
                        repository.recordCardData(coreCardData)

                        // Se existirem outros dados como ProcessResult a serem salvos para envio online:
                        // terminalState.processResult?.let { processResult ->
                        //      repository.recordProcessResult(processResultMapper.mapToDomain(processResult))
                        // }

                        CardCaptureResult.Success
                    } else {
                        CardCaptureResult.HardwareError("NO_DATA", "Cartão aprovado, mas sem dados retornados.")
                    }
                }
                is EMVState.Error -> {
                    val errorCode = terminalState.error?.name ?: "UNKNOWN_ERROR"
                    CardCaptureResult.HardwareError(errorCode, "Hardware failure during capture.")
                }
                is EMVState.Declined -> {
                    CardCaptureResult.HardwareError("DECLINED", "Card declined by chip: ${terminalState.data}")
                }
                else -> CardCaptureResult.HardwareError("FATAL", "Unexpected terminal state.")
            }

        } catch (e: Exception) {
            return@withContext CardCaptureResult.HardwareError("EXCEPTION", e.message ?: "Fatal error")
        } finally {
            hardwareMutex.unlock()
        }
    }
}

/**
 * Resultado de domínio agnóstico representando a conclusão da operação de hardware.
 */
sealed interface CardCaptureResult {
    data object Success : CardCaptureResult
    data class HardwareError(val code: String, val message: String) : CardCaptureResult
    data class InvalidAmount(val message: String) : CardCaptureResult
    data class HaltedByInterceptor(val reason: String) : CardCaptureResult
}