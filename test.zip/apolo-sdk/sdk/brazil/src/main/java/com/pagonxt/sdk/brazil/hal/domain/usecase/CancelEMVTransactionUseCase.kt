package com.pagonxt.sdk.brazil.hal.domain.usecase

import com.pagonxt.sdk.brazil.hal.domain.repository.EMVRepository

class CancelEMVTransactionUseCase(
    private val repository: EMVRepository
) {
    suspend operator fun invoke() {
        repository.cancel()
    }
}
