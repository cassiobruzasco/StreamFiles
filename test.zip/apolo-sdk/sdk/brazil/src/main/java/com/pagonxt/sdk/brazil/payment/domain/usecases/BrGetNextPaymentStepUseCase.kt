package com.pagonxt.sdk.brazil.payment.domain.usecases

import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.core.domain.models.CorePaymentStep
import com.pagonxt.sdk.core.domain.models.PaymentStep
import com.pagonxt.sdk.core.domain.usecases.GetNextPaymentStepUseCase

/**
 * Core business logic to determine the next step in the Brazil payment flow.
 */
class BrGetNextPaymentStepUseCase constructor(
    private val repository: BrTransactionRepository,
) : GetNextPaymentStepUseCase() {

    override fun evaluateNextStep(currentStep: PaymentStep): PaymentStep {
        val transaction = repository.currentTransaction.value
        val params = repository.params.value

        return when (currentStep) {
            // 1. Amount defined -> go to product selection
            is CorePaymentStep.AmountEntry -> {
                if (params.amountInCents > 0) CorePaymentStep.ProductSelection else CorePaymentStep.AmountEntry
            }

            // 2. Product selected -> evaluate next step
            is CorePaymentStep.ProductSelection -> {

                /*
                 * DEMONSTRAÇÃO DE EXTENSIBILIDADE (WHITE-LABEL / FLAVORS):
                 * Se o método de pagamento selecionado for PIX, podemos desviar
                 * o fluxo padrão (que iria pedir o cartão) para uma tela customizada
                 * de geração de QR Code, definida exclusivamente para o Brasil.
                 * * if (params.paymentMethod is BrSaleMethod.Pix) {
                 * return BrPaymentStep.PixQRCodeGeneration
                 * }
                 */

                if (params.paymentMethod != null && params.amountInCents > 0) {
                    CorePaymentStep.CardCapture
                } else {
                    CorePaymentStep.ProductSelection
                }
            }

            /*
             * DEMONSTRAÇÃO DE RETORNO DO FLUXO CUSTOMIZADO:
             * Após exibir o QR Code, o fluxo pode ser finalizado ou ir para o recibo.
             * * is BrPaymentStep.PixQRCodeGeneration -> CorePaymentStep.ReceiptPrinting
             */

            // 3. Card captured -> process the transaction (EMV/Online)
            is CorePaymentStep.CardCapture -> {
                if (transaction?.cardData != null) CorePaymentStep.EmvProcessing
                else CorePaymentStep.CardCapture
            }

            // 4. EMV Processed -> print the receipt
            is CorePaymentStep.EmvProcessing -> {
                if (transaction?.processResult != null) CorePaymentStep.ReceiptPrinting
                else CorePaymentStep.EmvProcessing
            }

            // 5. Receipt printed -> finish the flow
            is CorePaymentStep.ReceiptPrinting -> CorePaymentStep.Finished

            // Fallback safety
            else -> CorePaymentStep.Finished
        }
    }
}