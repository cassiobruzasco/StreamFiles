package com.pagonxt.sdk.brazil.hal.domain.platform

import android.util.Log
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.DUKPT_SLOT_KEY2
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.DUKPT_SLOT_KEY3
import com.pagonxt.sdk.brazil.hal.domain.extension.toAIDParameter
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager

class BrPlatformManager(
    private val halPlatformManager: PlatformManager
) {

    companion object {
        private val TAG = BrPlatformManager::class.simpleName
    }

    fun setupEMVParameters() {
        halPlatformManager.setupEMVParameters(
            onCompletion = {},
            setAIDParameter = { aidTableModels ->
                setAIDParameter(aidTableModels)
            }
        )
    }

    private fun setAIDParameter(aidCustomList: List<AidTableModel>? = null) {
        halPlatformManager.emvService?.apply {
            aidCustomList
                ?.map { it.toAIDParameter() }
                ?.let { aidList -> setAIDParameter(aidList) }
        } ?: run {
            Log.d(TAG, "Error on 'setAids' method, emvService is null.")
        }
    }

    /**
     * Encryption Service
     */
    // TODO: verify where and when call this
    fun getDUKPTPosition() =
        halPlatformManager.getDUKPTPosition(
            DUKPT_SLOT_KEY3,
            DUKPT_SLOT_KEY2
        )
}