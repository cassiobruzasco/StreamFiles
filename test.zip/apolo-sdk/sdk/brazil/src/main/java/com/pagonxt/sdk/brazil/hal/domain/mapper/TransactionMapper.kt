package com.pagonxt.sdk.brazil.hal.domain.mapper

import android.os.Build
import androidx.annotation.RequiresApi
import com.pagonxt.hal.emvKernel.Transaction
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.BRAZIL_CURRENCY_CODE
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.CURRENCY_EXPONENT_BRL
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.PAYMENT
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.PIN_TIMEOUT_SECONDS
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.REFUND
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst.WAIT_CARD_TIMEOUT_SECONDS
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.Date

@RequiresApi(Build.VERSION_CODES.O)
class TransactionMapper {
    fun getTransaction(
        amount: Long,
        otherAmount: Long,
        isRefund: Boolean,
    ) = Transaction(
        amount = amount,
        otherAmount = otherAmount,
        date = convertDateToLocalDateTime(Date.from(Instant.now())),
        transactionType = if (isRefund) REFUND else PAYMENT,
        currencyCode = BRAZIL_CURRENCY_CODE,
        currencyExponent = CURRENCY_EXPONENT_BRL,
        forcedOnLine = true,
        ctsEnable = 1,
        pinTimeout = PIN_TIMEOUT_SECONDS,
        waitCardTimeout = WAIT_CARD_TIMEOUT_SECONDS
    )

    private fun convertDateToLocalDateTime(
        date: Date,
        zoneId: ZoneId = ZoneId.systemDefault()
    ): LocalDateTime {
        return date.toInstant()
            .atZone(zoneId)
            .toLocalDateTime()
    }
}