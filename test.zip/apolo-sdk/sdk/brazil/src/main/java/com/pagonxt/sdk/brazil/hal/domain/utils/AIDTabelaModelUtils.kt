package com.pagonxt.sdk.brazil.hal.domain.utils

import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_1
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_2
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_3
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_4
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_5
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_6
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_7
import com.pagonxt.sdk.hal.middleware.domain.constant.ByteConst.BIT_8
import java.math.BigInteger

internal object AidTableModelUtils {

    fun buildTerminalCapabilitiesGeneral(
        terminalCapabilities: String
    ): String =
        terminalCapabilities
            .toByteArray(Charsets.UTF_8)
            .filterIndexed { index, _ -> index < 2 }
            .toByteArray()
            .toString(Charsets.UTF_8)
            .uppercase()

    fun buildTerminalCapabilitiesAboveCVM(
        terminalCapabilities: String
    ): String {
        var byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                byte2 = SetByteParams(
                    listOf(
                        Pair(BIT_1, getBit(data.hexToBinary().toInt(2), BIT_1)),
                        Pair(BIT_2, getBit(data.hexToBinary().toInt(2), BIT_2)),
                        Pair(BIT_3, getBit(data.hexToBinary().toInt(2), BIT_3)),
                        Pair(BIT_4, 0),
                        Pair(BIT_5, getBit(data.hexToBinary().toInt(2), BIT_5)),
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_6)),
                        Pair(BIT_7, getBit(data.hexToBinary().toInt(2), BIT_7)),
                        Pair(BIT_8, getBit(data.hexToBinary().toInt(2), BIT_8)),
                    )
                )
            }
        return setByte(byte2).binaryToHex()
    }

    fun buildTerminalCapabilitiesODA(
        terminalCapabilities: String
    ): String =
        terminalCapabilities
            .toByteArray(Charsets.UTF_8)
            .filterIndexed { index, _ -> index in 4..5 }
            .toByteArray()
            .toString(Charsets.UTF_8)
            .uppercase()

    /**
     * Follow this documentation to build theses bytes
     * <a href="https://emv.cool/2020/12/24/Enhanced-Contactless-Reader-Capabilities-9F6E-AMEX/"> EMV COOL </a>
     * <a href="https://gitlab.ingenico.com.br/Mercosur/Brasil/pagonxt/hal/-/blob/main/docs/Conversion.md?ref_type=heads"> Documentation </a>
     */
    fun buildAMEXEnhancedContactlessReaderCapabilities(
        terminalContactlessCapabilities: String
    ): String {
        val byte1 = SetByteParams(
            bytes = listOf(
                Pair(BIT_3, 0),
                Pair(BIT_4, 1),
                Pair(BIT_5, 1),
                Pair(BIT_6, 0),
                Pair(BIT_7, 1),
                Pair(BIT_8, 1)
            )
        )
        val byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalContactlessCapabilities
        )
            .let { data ->
                byte2 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_5, 0),
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_6)),
                        Pair(BIT_7, getBit(data.hexToBinary().toInt(2), BIT_7)),
                        Pair(BIT_8, 1)
                    )
                )
            }
        val byte3 = SetByteParams(bytes = listOf())
        val byte4 = SetByteParams(bytes = listOf())

        return setByte(byte1).binaryToHex() +
                setByte(byte2).binaryToHex() +
                setByte(byte3).binaryToHex() + 0 +
                setByte(byte4).binaryToHex() + 0
    }

    fun parseIfZero(data: String, elseValue: String): String {
        return if (!data.contains(regex = Regex("^[0-9]")))
            data
        else {
            data.sumOf { it.digitToInt() }.let {
                if (it != 0) data else elseValue
            }
        }
    }

    /**
     * Follow ABECS Versão: 2.20 (20-dez-24)
     * Specific params - Visa PayWave page 226 / 292
     * TTQ: Terminal Transaction Qualifiers
     * TAG: 9F66h
     * |  Byte | Bit |              Description              |                 Value                |
     * _____________________________________________________________________________________________
     * |   1   |  8  |          MSD Supported                |               0 (fixo)               |
     * |       |  7  |          RFU                          |               0 (fixo)               |
     * |       |  6  |          qVSDC supported              |               1 (fixo)               |
     * |       |  5  |     EMV contact chip supported        |  Bit 6 do 1º byte de T1_TRMCAPAB     |
     * |       |  4  |          Offline-only reader          |  Ativar se T1_TRMTYP = “x3” ou “x6”  |
     * |       |  3  |          Online PIN supported         |  Bit 7 do 2º byte de T1_CTLSTRMCP    |
     * |       |  2  |          Signature supported          |  Bit 6 do 2º byte de T1_CTLSTRMCP    |
     * |       |  1  |    Offline Data Authentication for    |               0 (fixo)               |
     * |       |     |    Online Authorizations supported.   |                                      |
     * _____________________________________________________________________________________________
     * |   2   |  8  |  Online cryptogram required           |  Preenchido pelo Kernel EMV CTLS.    |
     * |       |  7  |  CVM required                         |  Preenchido pelo Kernel EMV CTLS.    |
     * |       |  6  |  (Contact Chip) Offline PIN supported |  Bit 8 do 2º byte de T1_TRMCAPAB     |
     * |       | 5-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     * |   3   |  8  |  Issuer Update Processing supported   |  Ativar se T1_CTLSISSSCR = “1”       |
     * |       |  7  |  Mobile functionality supported       |              1 (fixo)                |
     * |       |     |  (Consumer Device CVM)                |                                      |
     * |       | 6-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     * |   4   | 8-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     */
    fun buildTTQVisa(
        terminalCapabilities: String,
        issuerScript: Boolean,
        terminalType: String
    ): String {
        val byte1: SetByteParams
        getByte1FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { byte1TermCap ->
                getByte2FromTerminalCapabilities(
                    terminalCapabilities = terminalCapabilities
                )
                    .let { byte2TermCap ->
                        byte1 = SetByteParams(
                            bytes = listOf(
                                Pair(BIT_1, 0),
                                Pair(BIT_2, getBit(byte2TermCap.hexToBinary().toInt(2), BIT_6)),
                                Pair(BIT_3, getBit(byte2TermCap.hexToBinary().toInt(2), BIT_7)),
                                Pair(BIT_4, verifyByte1Bit4TTQ(terminalType = terminalType)),
                                Pair(BIT_5, getBit(byte1TermCap.hexToBinary().toInt(2), BIT_6)),
                                Pair(BIT_6, 1),
                                Pair(BIT_7, 0),
                                Pair(BIT_8, 0)
                            )
                        )
                    }
            }

        val byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                byte2 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_8))
                    )
                )
            }

        val byte3: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let {
                byte3 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_7, 1),
                        Pair(BIT_8, if (issuerScript) 1 else 0)
                    )
                )
            }

        val byte4 = SetByteParams(bytes = listOf())

        return setByte(byte1).binaryToHex() +
                setByte(byte2).binaryToHex() +
                setByte(byte3).binaryToHex() +
                setByte(byte4).binaryToHex() + 0
    }

    /**
     * Follow ABECS Versão: 2.20 (20-dez-24)
     * Specific params - Discover D-PAS page 230 / 292
     * TTQ: Terminal Transaction Qualifiers
     * TAG: 9F66h
     * |  Byte | Bit |              Description              |                 Value                |
     * _____________________________________________________________________________________________
     * |   1   |  8  |          MSD Supported                |               0 (fixo)               |
     * |       |  7  |          RFU                          |               0 (fixo)               |
     * |       |  6  |          EMV mode supported           |               1 (fixo)               |
     * |       |  5  |      EMV contact chip supported       |  Bit 6 do 1º byte de T1_TRMCAPAB     |
     * |       |  4  |   Offline-only Contactless Reader     |  Ativar se T1_TRMTYP = “x3” ou “x6”  |
     * |       |  3  |          Online PIN supported         |  Bit 7 do 2º byte de T1_CTLSTRMCP    |
     * |       |  2  |          Signature supported          |  Bit 6 do 2º byte de T1_CTLSTRMCP    |
     * |       |  1  |    Offline Data Authentication for    |               0 (fixo)               |
     * |       |     |    Online Authorizations supported.   |                                      |
     * _____________________________________________________________________________________________
     * |   2   |  8  |  Online cryptogram required           |  Preenchido pelo Kernel EMV CTLS.    |
     * |       |  7  |  CVM required                         |  Preenchido pelo Kernel EMV CTLS.    |
     * |       |  6  |  (Contact Chip) Offline PIN supported |  1 se o bit 8 ou o bit 5 do 2º byte  |
     * |       |     |                                       |  de T1_TRMCAPAB estiverem ativos.    |
     * |       |  5  |  RFU                                  |               0 (fixo)               |
     * |       |  4  |  Fast Mode Supported                  |               0 (fixo)               |
     * |       |  3  |  Transit Terminal                     |               0 (fixo)               |
     * |       | 2-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     * |   3   |  8  |  Issuer Update Processing supported   |  Ativar se T1_CTLSISSSCR = “1”       |
     * |       |  7  |  Consumer Device CVM supported        |               1 (fixo)               |
     * |       |  6  |  Consumer Device CVM for Transit MCC  |               0 (fixo)               |
     * |       | 5-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     * |   4   | 8-1 |  RFU                                  |               0 (fixo)               |
     * _____________________________________________________________________________________________
     */
    fun buildTTQDiscover(
        terminalCapabilities: String,
        issuerScript: Boolean,
        terminalType: String
    ): String {
        val byte1: SetByteParams
        getByte1FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { byte1TermCap ->
                getByte2FromTerminalCapabilities(
                    terminalCapabilities = terminalCapabilities
                )
                    .let { byte2TermCap ->
                        byte1 = SetByteParams(
                            bytes = listOf(
                                Pair(BIT_1, 0),
                                Pair(BIT_2, getBit(byte2TermCap.hexToBinary().toInt(2), BIT_6)),
                                Pair(BIT_3, getBit(byte2TermCap.hexToBinary().toInt(2), BIT_7)),
                                Pair(BIT_4, verifyByte1Bit4TTQ(terminalType = terminalType)),
                                Pair(BIT_5, getBit(byte1TermCap.hexToBinary().toInt(2), BIT_6)),
                                Pair(BIT_6, 1),
                                Pair(BIT_7, 0),
                                Pair(BIT_8, 0)
                            )
                        )
                    }
            }

        val byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let {
                byte2 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_6, verifyByte2Bit6TTQ(terminalCapabilities)),
                    )
                )
            }

        val byte3: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let {
                byte3 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_7, 1),
                        Pair(BIT_8, if (issuerScript) 1 else 0)
                    )
                )
            }

        val byte4 = SetByteParams(bytes = listOf())

        return setByte(byte1).binaryToHex() +
                setByte(byte2).binaryToHex() +
                setByte(byte3).binaryToHex() +
                setByte(byte4).binaryToHex() + 0
    }

    /**
     * Follow ABECS Versão: 2.20 (20-dez-24)
     * Specific params - MasterCard PayPass page 228 / 292
     * Terminal Risk Management Data
     * TAG: 9F1Dh
     * |  Byte | Bit |              Description              |                 Value                |
     * _____________________________________________________________________________________________
     * |   1   |  7  |  Enciphered PIN verified online       |     Bit 7 de CVM Capability – CVM    |
     * |       |     |  (Contactless)                        |     Required (tag DF8118h);          |
     * |       |  6  |  Signature (paper) (Contactless)      |     Bit 6 de CVM Capability – CVM    |
     * |       |     |                                       |     Required (tag DF8118h);          |
     * |       |  4  |  No CVM required (Contactless)        |              1 (fixo)                |
     * |       |  3  |  CDCVM (Contactless)                  |              1 (fixo)                |
     * _____________________________________________________________________________________________
     * |   2   |  7  |  Enciphered PIN verified online       |   Bit 7 do 2º byte de T1_TRMCAPAB    |
     * |       |     |  (Contact)                            |                                      |
     * |       |  6  |  Signature (paper) (Contact)          |   Bit 6 do 2º byte de T1_TRMCAPAB    |
     * |       |  5  |  Enciphered PIN verification          |   Bit 5 do 2º byte de T1_TRMCAPAB    |
     * |       |     |  performed by ICC (Contact)           |                                      |
     * |       |  4  |  No CVM required (Contact)            |   Bit 4 do 2º byte de T1_TRMCAPAB    |
     * |       |  2  |  Plaintext PIN verification           |   Bit 8 do 2º byte de T1_TRMCAPAB    |
     * |       |     |  performed by ICC (Contact)           |                                      |
     * _____________________________________________________________________________________________
     * |   3   |  8  |  Mag-Stripe mode contactless          |              1 (fixo)                |
     * |       |     |  transactions not supported           |                                      |
     * |       |  7  |  EMV mode contactless transactions    |              0 (fixo)                |
     * |       |     |  not supported                        |                                      |
     * _____________________________________________________________________________________________
     * |   4   | 8-1 |                                       |              0 (fixo)                |
     * _____________________________________________________________________________________________
     * |   5   | 8-1 |                                       |              0 (fixo)                |
     * _____________________________________________________________________________________________
     * |   6   | 8-1 |                                       |              0 (fixo)                |
     * _____________________________________________________________________________________________
     */

    fun buildTerminalRiskManagementData(
        terminalCapabilities: String
    ): String {
        val byte1: SetByteParams
        buildCMVCapability(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                byte1 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_3, 1),
                        Pair(BIT_4, 1),
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_6)),
                        Pair(BIT_7, getBit(data.hexToBinary().toInt(2), BIT_7))
                    )
                )
            }

        val byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                byte2 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_2, getBit(data.hexToBinary().toInt(2), BIT_8)),
                        Pair(BIT_4, getBit(data.hexToBinary().toInt(2), BIT_4)),
                        Pair(BIT_5, getBit(data.hexToBinary().toInt(2), BIT_5)),
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_6)),
                        Pair(BIT_7, getBit(data.hexToBinary().toInt(2), BIT_7))
                    )
                )
            }

        val byte3: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let {
                byte3 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_7, 0),
                        Pair(BIT_8, 1),
                    )
                )
            }

        val byte4 = SetByteParams(bytes = listOf())
        val byte5 = SetByteParams(bytes = listOf())
        val byte6 = SetByteParams(bytes = listOf())
        val byte7 = SetByteParams(bytes = listOf())
        val byte8 = SetByteParams(bytes = listOf())

        return setByte(byte1).binaryToHex() +
                setByte(byte2).binaryToHex() +
                setByte(byte3).binaryToHex() +
                setByte(byte4).binaryToHex() + 0 +
                setByte(byte5).binaryToHex() + 0 +
                setByte(byte6).binaryToHex() + 0 +
                setByte(byte7).binaryToHex() + 0 +
                setByte(byte8).binaryToHex() + 0
    }

    fun buildOnDeviceVerification(terminalCapabilities: String): Boolean =
        getByte1FromTerminalCapabilities(
            terminalCapabilities = buildTerminalRiskManagementData(
                terminalCapabilities
            )
        )
            .let { data ->
                getBit(data.hexToBinary().toInt(2), BIT_4) == 1
            }

    /**
     * Follow ABECS Versão: 2.20 (20-dez-24)
     * Specific params - MasterCard PayPass page 227 / 292
     * CVM Capability
     * TAG: DF8118h
     * |  Object                |     Tag     |                       Value                         |
     * _____________________________________________________________________________________________
     * |   CVM Capability –     |   DF8118h   |     Segundo byte de T1_CTLSTRMCP,                   |
     * |   CVM Required         |             |     desabilitando-se os bits:                       |
     * |                        |             |     b8 - Plaintext PIN for ICC verification;        |
     * |                        |             |     b6(*) - Signature (paper);                      |
     * |                        |             |     b5 - Enciphered PIN for offline verification;   |
     * |                        |             |     b4 = No CVM required.                           |
     * |                        |             |     (*) Desabilitar se débito (Maestro), pois este  |
     * |                        |             |     não deve suportar assinatura em papel.          |
     * _____________________________________________________________________________________________
     */
    private fun buildCMVCapability(
        terminalCapabilities: String
    ): String {
        val byte2: SetByteParams
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                byte2 = SetByteParams(
                    bytes = listOf(
                        Pair(BIT_1, getBit(data.hexToBinary().toInt(2), BIT_1)),
                        Pair(BIT_2, getBit(data.hexToBinary().toInt(2), BIT_2)),
                        Pair(BIT_3, getBit(data.hexToBinary().toInt(2), BIT_3)),
                        Pair(BIT_4, 0),
                        Pair(BIT_5, 0),
                        Pair(BIT_6, getBit(data.hexToBinary().toInt(2), BIT_6)),
                        Pair(BIT_7, getBit(data.hexToBinary().toInt(2), BIT_7)),
                        Pair(BIT_8, 0)
                    )
                )
            }

        return setByte(byte2).binaryToHex()
    }

    private fun getByte2FromTerminalCapabilities(terminalCapabilities: String): String =
        terminalCapabilities
            .toByteArray(Charsets.UTF_8)
            .filterIndexed { index, _ -> index in 2..3 }
            .toByteArray()
            .toString(Charsets.UTF_8)

    private fun getByte1FromTerminalCapabilities(terminalCapabilities: String): String =
        terminalCapabilities
            .toByteArray(Charsets.UTF_8)
            .filterIndexed { index, _ -> index < 2 }
            .toByteArray()
            .toString(Charsets.UTF_8)


    private fun verifyByte1Bit4TTQ(terminalType: String): Int =
        terminalType.toInt(16).let { if (it == 0x03 || it == 0x06) 1 else 0 }

    private fun verifyByte2Bit6TTQ(terminalCapabilities: String): Int =
        getByte2FromTerminalCapabilities(
            terminalCapabilities = terminalCapabilities
        )
            .let { data ->
                when {
                    getBit(data.hexToBinary().toInt(2), BIT_5) == 1 -> 1
                    getBit(data.hexToBinary().toInt(2), BIT_8) == 1 -> 1
                    else -> 0
                }
            }

    private fun getBit(value: Int, position: Int): Int {
        return (value shr position - 1) and 1
    }

    private fun setByte(byteParam: SetByteParams): String {
        val byteResult = mutableListOf(0, 0, 0, 0, 0, 0, 0, 0)
        byteParam.bytes.forEach {
            byteResult[byteResult.size - it.first] = it.second
        }
        return byteResult.joinToString("")
    }

    private fun String.binaryToHex(): String =
        String.format("%X", this.toInt(radix = 2))

    private fun String.hexToBinary(): String =
        BigInteger(this, 16).toString(2)
}

data class SetByteParams(
    val bytes: List<Pair<Int, Int>>
)