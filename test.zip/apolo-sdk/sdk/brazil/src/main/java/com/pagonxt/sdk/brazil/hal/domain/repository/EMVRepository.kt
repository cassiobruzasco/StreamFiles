package com.pagonxt.sdk.brazil.hal.domain.repository

import com.pagonxt.sdk.brazil.hal.domain.state.EMVState
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel
import kotlinx.coroutines.flow.Flow

/**
 * Domain-facing EMV repository.
 *
 * Exposes the EMV transaction lifecycle as a stream of [EmvEvent]s.
 * The data layer adapts hardware callbacks (HAL) into these domain events.
 */
interface EMVRepository {
    fun events(): Flow<EmvEvent>

    suspend fun startTransaction(params: EMVParams)

    suspend fun cancel()
}

/**
 * Domain event type emitted by [EMVRepository.events].
 *
 * We reuse the existing domain state model to keep the public surface small.
 */
typealias EmvEvent = EMVState

data class EMVParams(
    val aidModels: List<AidTableModel>,
    val strCodProd: String,
    val amount: Long
)