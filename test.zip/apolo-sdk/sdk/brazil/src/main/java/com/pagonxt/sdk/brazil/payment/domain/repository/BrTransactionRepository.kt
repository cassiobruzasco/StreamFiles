package com.pagonxt.sdk.brazil.payment.domain.repository

import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.brazil.payment.domain.models.BrTransactionContext
import com.pagonxt.sdk.brazil.payment.domain.models.SaleParams
import com.pagonxt.sdk.core.domain.repository.TransactionRepository
import com.pagonxt.sdk.hal.middleware.domain.model.ProcessResultModel
import kotlinx.coroutines.flow.StateFlow

/**
 * Brazil-specific repository extending the core contract.
 * Exposes additional methods and states tailored for this country.
 */
interface BrTransactionRepository : TransactionRepository<BrTransactionContext> {
    val params: StateFlow<SaleParams>

    fun updatePaymentMethod(method: BrSaleMethod)
    fun recordProcessResult(result: ProcessResultModel)
    fun beginTransaction()
}