package com.pagonxt.sdk.brazil.payment.data.repository

import com.pagonxt.sdk.core.domain.models.CardData
import com.pagonxt.sdk.hal.middleware.domain.model.ProcessResultModel
import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.brazil.payment.domain.models.BrTransactionContext
import com.pagonxt.sdk.brazil.payment.domain.models.SaleParams
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class BrTransactionRepositoryImpl : BrTransactionRepository {

    private val _params = MutableStateFlow(SaleParams())
    override val params: StateFlow<SaleParams> = _params.asStateFlow()

    private val _currentTransaction = MutableStateFlow<BrTransactionContext?>(null)
    override val currentTransaction: StateFlow<BrTransactionContext?> = _currentTransaction.asStateFlow()

    override fun updateAmount(amountInCents: Long) {
        // use case
        _params.update { it.copy(amountInCents = amountInCents) }
    }

    override fun updatePaymentMethod(method: BrSaleMethod) {
        _params.update { it.copy(paymentMethod = method) }
    }

    override fun beginTransaction() {
        if (_params.value.amountInCents > 0 && _params.value.paymentMethod != null) {
            _currentTransaction.value = BrTransactionContext(params = _params.value)
        }
    }

    override fun recordCardData(cardData: CardData) {
        _currentTransaction.update { it?.copy(cardData = cardData) }
    }

    override fun recordProcessResult(result: ProcessResultModel) {
        _currentTransaction.update { it?.copy(processResult = result) }
    }

    override fun clearTransaction() {
        _currentTransaction.value = null
        _params.value = SaleParams()
    }
}