package com.pagonxt.sdk.brazil.payment.data.mapper

import com.pagonxt.sdk.core.domain.models.CardData
import com.pagonxt.sdk.core.domain.models.CardProducts
import com.pagonxt.sdk.core.domain.models.CardType
import com.pagonxt.hal.emvKernel.CardData as HalKernelCardData
import com.pagonxt.hal.emvKernel.CardType as HalKernelCardType

/**
 * Adapter puro responsável por isolar a camada de Domínio do SDK
 * das estruturas de dados proprietárias do kernel de hardware (HAL).
 */
class BrCardDataMapper {

    /**
     * Converte o modelo bruto do Kernel EMV para o modelo estrito do Core.
     */
    fun mapToDomain(rawHalModel: HalKernelCardData): CardData {
        return CardData(
            aid = rawHalModel.aid,
            applicationName = rawHalModel.applicationName,
            cardholderName = rawHalModel.cardholderName,
            expirationDate = rawHalModel.expirationDate,
            issuerCountryCode = rawHalModel.issuerCountryCode,
            labelName = rawHalModel.labelName,
            pan = rawHalModel.pan,
            serviceCode = rawHalModel.serviceCode,
            track1 = rawHalModel.track1,
            track2 = rawHalModel.track2,
            track3 = rawHalModel.track3,
            type = mapCardType(rawHalModel.type),
            products = mapProducts(rawHalModel.aid)
        )
    }

    private fun mapCardType(halType: HalKernelCardType?): CardType {
        // Como o tipo vem do Kernel (provavelmente um Enum Java/Kotlin),
        // usamos a propriedade .name para traduzir de forma segura para nossa Sealed Interface
        return when (halType?.name) {
            "MAGNETIC" -> CardType.Magnetic
            "CONTACT" -> CardType.Contact
            "CONTACTLESS" -> CardType.Contactless
            "CONTACTLESS_MAG" -> CardType.ContactlessMag
            else -> CardType.Contact // Fallback de segurança para transações de chip
        }
    }

    private fun mapProducts(aid: String?): List<CardProducts> {
        // Exemplo de regra de negócio flexível focada no Brasil:
        // Se a regra for baseada no final do AID (ex: terminação 2 para débito):
        val isDebit = aid?.endsWith("2") == true

        return if (isDebit) {
            listOf(CardProducts.Debit)
        } else {
            listOf(CardProducts.Credit)
        }
    }
}