package com.pagonxt.sdk.brazil.di

import com.pagonxt.sdk.brazil.payment.data.mapper.BrCardDataMapperimport com.pagonxt.sdk.brazil.payment.data.repository.BrTransactionRepositoryImpl
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.brazil.payment.domain.usecases.BrGetNextPaymentStepUseCase
import com.pagonxt.sdk.brazil.payment.domain.usecases.BrRequestCardCaptureUseCase
import org.koin.core.module.dsl.bind
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.module


/** * Brazil payment module: Provides the pure domain/data bindings using Koin Core.
 */
val brazilPaymentModule = module {

    // Repository is a Singleton, retaining state throughout the flow
    singleOf(::BrTransactionRepositoryImpl) { bind<BrTransactionRepository>() }

    // UseCases should generally be factories so they don't hold stale state
    factoryOf(::BrGetNextPaymentStepUseCase)

    // Mappers
    factoryOf(::BrCardDataMapper)

    // Use Cases
    factoryOf(::BrRequestCardCaptureUseCase)
}