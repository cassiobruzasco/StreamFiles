package com.pagonxt.sdk.brazil.di

import android.os.Build
import androidx.annotation.RequiresApi
import com.pagonxt.sdk.brazil.hal.data.repository.EMVRepositoryImpl
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVRepository
import com.pagonxt.sdk.brazil.hal.domain.usecase.CancelEMVTransactionUseCase
import com.pagonxt.sdk.brazil.hal.domain.usecase.ObserveEMVEventsUseCase
import com.pagonxt.sdk.brazil.hal.domain.usecase.StartEMVTransactionUseCase
import com.pagonxt.sdk.brazil.hal.domain.mapper.TransactionMapper
import com.pagonxt.sdk.brazil.hal.domain.platform.BrPlatformManager
import org.koin.core.module.Module
import org.koin.dsl.module

/**
 * Koin module for Brazil HAL domain/data.
 *
 * [BrPlatformManager] is registered as a singleton so the same instance is used
 * both inside use-cases and as the onPlatformBound callback wired in SdkDi (Brazil flavor).
 */
@RequiresApi(Build.VERSION_CODES.O)
val brazilHalModule: Module = module {

    // Repository (domain boundary)
    single { EMVRepositoryImpl(get()) }
    single<EMVRepository> { get<EMVRepositoryImpl>() }

    // Mappers
    factory { TransactionMapper() }

    // Use-cases
    factory {
        StartEMVTransactionUseCase(
            repository = get(),
            emvRepositoryImpl = get(),
            platformManager = get(),
            bcGlobal = get(),
            transactionMapper = get()
        )
    }
    factory { CancelEMVTransactionUseCase(repository = get()) }
    factory { ObserveEMVEventsUseCase(repository = get()) }

    // Manager
    single { BrPlatformManager(halPlatformManager = get()) }
}
