package com.pagonxt.sdk.brazil.hal.data.repository

import com.pagonxt.hal.emvKernel.Candidate
import com.pagonxt.hal.emvKernel.CardData
import com.pagonxt.hal.emvKernel.Errors
import com.pagonxt.hal.emvKernel.Message
import com.pagonxt.hal.emvKernel.ProcessResult
import com.pagonxt.hal.emvKernel.ResultData
import com.pagonxt.hal.emvService.EMVEvents
import com.pagonxt.hal.emvService.IOnCardCallback
import com.pagonxt.hal.emvService.IOnDrawPinCallback
import com.pagonxt.hal.emvService.IOnProcessedCallback
import com.pagonxt.hal.emvService.IOnSelectCallback
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVParams
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVRepository
import com.pagonxt.sdk.brazil.hal.domain.repository.EmvEvent
import com.pagonxt.sdk.brazil.hal.domain.state.EMVState
import com.pagonxt.sdk.hal.middleware.domain.emv.BCGlobal
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Data-layer adapter: converts HAL EMV callbacks ([EMVEvents]) into a domain event stream.
 *
 * Note: wiring to the actual EMV service start/cancel is intentionally left outside for now.
 * The SDK code that owns the platform binding should call [startTransaction] / [cancel] and
 * also pass this instance into `emvService.create(...)` so callbacks arrive here.
 */
// TODO: need to have BCGlobal?
// TODO: Maybe BCGlobal can be removed and the implementation do in usecase?
class EMVRepositoryImpl(
    private val bcGlobal: BCGlobal,
) : EMVEvents(), EMVRepository {

    private val _events = MutableSharedFlow<EmvEvent>(
        replay = 1,
        extraBufferCapacity = 64
    )

    private var cardDataModel: CardData? = null
    private var processResultModel: ProcessResult? = null
    private var resultDataModel: ResultData? = null

    override fun events(): Flow<EmvEvent> = _events.asSharedFlow()

    override suspend fun startTransaction(params: EMVParams) {
        _events.emit(EMVState.WaitingForCard)
    }

    override suspend fun cancel() {
        _events.emit(EMVState.Finished)
    }

    override fun onDetect(contact: Boolean, contactless: Boolean, tap: Boolean) {
        _events.tryEmit(
            EMVState.CardDetected(
                contact = contact.toString(),
                contactless = contactless,
                tap = tap
            )
        )
        bcGlobal.onDetect(
            contact = contact,
            contactless = contactless,
            tap = tap
        )
    }

    override fun onCard(cardData: CardData?, process: IOnCardCallback?) {
        cardDataModel = cardData
        _events.tryEmit(EMVState.Processing)
        bcGlobal.onCard(
            cardData = cardData,
            process = process
        )
    }

    override fun onSelect(
        candidates: MutableList<Candidate>?,
        contactless: Boolean,
        select: IOnSelectCallback?
    ) {
        val list: List<String> =
            candidates?.let {
                List(it.size) { index -> "Application ${index + 1}" }
            } ?: emptyList()

        _events.tryEmit(EMVState.SelectApplication(list))
        bcGlobal.onSelect(
            candidates = candidates,
            contactless = contactless,
            select = select
        )
    }

    override fun onDrawPin(drawPinCallback: IOnDrawPinCallback?) {
        _events.tryEmit(EMVState.RequestPin)
        bcGlobal.onDrawPin(drawPinCallback)
    }

    override fun onShowPinEntry(numDigits: Int) {
        _events.tryEmit(EMVState.PinDigitsChanged(numDigits))
        bcGlobal.onShowPinEntry(numDigits)
    }

    override fun onProcess() {
        _events.tryEmit(EMVState.Processing)
        bcGlobal.onProcess()
    }

    override fun onProcessed(result: ProcessResult?, finish: IOnProcessedCallback?) {
        processResultModel = result
        _events.tryEmit(EMVState.Processing)
        bcGlobal.onProcessed(
            result = result,
            finish = finish
        )
    }

    override fun onFinish(data: ResultData?) {
        resultDataModel = data
        if (data?.approved == true) {
            _events.tryEmit(
                EMVState.Approved(
                    cardData = cardDataModel,
                    processResult = processResultModel,
                    resultData = resultDataModel
                )
            )
        } else {
            _events.tryEmit(EMVState.Declined(data.toString()))
        }
        bcGlobal.onFinish(
            data = data
        )
    }

    override fun onRemove(contactless: Boolean) {
        _events.tryEmit(EMVState.RemoveCard)
        bcGlobal.onRemove(contactless = contactless)
    }

    override fun onRemoved() {
        _events.tryEmit(EMVState.RemoveCard)
        bcGlobal.onRemoved()
    }

    override fun onEnd() {
        _events.tryEmit(EMVState.Finished)
        bcGlobal.onEnd()
    }

    override fun onError(error: Errors?) {
        _events.tryEmit(
            EMVState.Error(error = error)
        )
        bcGlobal.onError(error = error)
    }

    override fun onMessage(message: Message?) {
        bcGlobal.onMessage(message = message)
    }

    override fun onPanic(data: String?) {
        _events.tryEmit(EMVState.Error(error = Errors.INTERR))
        bcGlobal.onPanic(data = data)
    }

    override fun onPinSuccess(pinBlock: String, ksn: String) {
        _events.tryEmit(EMVState.Processing)
        bcGlobal.onPinSuccess(pinBlock = pinBlock, ksn = ksn)
    }
}