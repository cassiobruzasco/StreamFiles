package com.pagonxt.sdk.brazil.hal.domain.emv

import com.pagonxt.hal.emvKernel.CardType
import com.pagonxt.sdk.brazil.hal.constant.TransactionConst

// TODO: will be use when we implement the EMV process
class BrBCGlobal {
    private fun parseCardType(type: CardType): String =
        when (type) {
            CardType.Contact -> TransactionConst.CHIP_CODE
            CardType.Magnetic -> TransactionConst.MAG_STRIPE_CODE
            CardType.Contactless -> TransactionConst.CONTACTLESS_CODE
            CardType.ContactlessMag -> TransactionConst.MAG_STRIPE_CODE_FALLBACK
        }
}