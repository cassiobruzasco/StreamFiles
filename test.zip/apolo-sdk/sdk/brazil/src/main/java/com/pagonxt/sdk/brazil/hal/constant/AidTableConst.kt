package com.pagonxt.sdk.brazil.hal.constant

internal object AidTableConst {

    /**
     * Value fixed from documentation of ingenico
     * <a href="https://gitlab.ingenico.com.br/Mercosur/Brasil/pagonxt/hal/-/blob/main/docs/Conversion.md?ref_type=heads"> Documentation </a>
     */
    const val TERMINAL_CAPABILITIES_CVM_BELOW_CVM_LIMIT = "08"

    /**
     * Value fixed from documentation of ingenico
     * <a href="https://gitlab.ingenico.com.br/Mercosur/Brasil/pagonxt/hal/-/blob/main/docs/Conversion.md?ref_type=heads"> Documentation </a>
     */
    const val AMEX_CONTACTLESS_READER_CAPABILITIES = "C0"

    const val AID_MASTER_CARD = "A0000000041010"
}