package com.pagonxt.sdk.brazil.hal.domain.usecase

import com.pagonxt.sdk.brazil.hal.domain.repository.EMVRepository
import com.pagonxt.sdk.brazil.hal.domain.repository.EmvEvent
import kotlinx.coroutines.flow.Flow

class ObserveEMVEventsUseCase(
    private val repository: EMVRepository,
) {
    operator fun invoke(): Flow<EmvEvent> = repository.events()
}
