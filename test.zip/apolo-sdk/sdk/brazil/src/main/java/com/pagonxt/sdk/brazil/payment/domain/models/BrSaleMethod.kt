package com.pagonxt.sdk.brazil.payment.domain.models

/**
 * Represents the available payment methods for Brazil.
 * Implemented as a sealed interface to allow safe exhaustive checks without enums.
 */
sealed interface BrSaleMethod {
    val code: String

    data object CreditCard : BrSaleMethod { override val code = "01" }
    data object DebitCard : BrSaleMethod { override val code = "02" }
    data object Voucher : BrSaleMethod { override val code = "03" }
    data object Pix : BrSaleMethod { override val code = "05" }

    companion object {
        /**
         * Parses a code string into a BrSaleMethod safely.
         */
        fun fromCode(code: String): BrSaleMethod? {
            return listOf(CreditCard, DebitCard, Voucher, Pix).find { it.code == code }
        }
    }
}