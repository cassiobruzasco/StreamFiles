package com.pagonxt.sdk.brazil.payment.domain.usecases

import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.brazil.payment.domain.repository.PaymentNetworkService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface PaymentNetworkResult {
    data object Approved : PaymentNetworkResult
    data class Denied(val code: String, val reason: String) : PaymentNetworkResult
}

class ProcessPaymentUseCase(
    private val repository: BrTransactionRepository,
    private val paymentNetworkService: PaymentNetworkService
) {
    suspend operator fun invoke(): PaymentNetworkResult = withContext(Dispatchers.IO) {
        val transaction = repository.currentTransaction.value

        // Valida se o cartão já foi capturado antes de ir para a rede
        if (transaction == null || !transaction.isCardCaptured || transaction.cardData == null) {
            return@withContext PaymentNetworkResult.Denied("500", "Dados do cartão ausentes")
        }

        return@withContext try {
            // Executa a chamada de rede (API)
            paymentNetworkService.postPayment(
                amountInCents = transaction.amountInCents.toInt(),
                pan = transaction.cardData.pan,
                tagsEmv = transaction.processResult?.tagsEmv.orEmpty(),
                track2 = transaction.cardData.track2.orEmpty()
            )

            PaymentNetworkResult.Approved

        } catch (e: Exception) {
            // Em um cenário real, você mapearia HttpException, Timeout, etc.
            PaymentNetworkResult.Denied("API_ERROR", e.message ?: "Erro de conexão")
        }
    }
}