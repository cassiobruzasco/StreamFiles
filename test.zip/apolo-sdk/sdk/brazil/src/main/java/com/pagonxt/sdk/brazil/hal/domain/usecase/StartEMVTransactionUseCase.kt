package com.pagonxt.sdk.brazil.hal.domain.usecase

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import com.pagonxt.hal.emvService.IEMVInterface
import com.pagonxt.sdk.brazil.hal.data.repository.EMVRepositoryImpl
import com.pagonxt.sdk.brazil.hal.domain.mapper.TransactionMapper
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVParams
import com.pagonxt.sdk.brazil.hal.domain.repository.EMVRepository
import com.pagonxt.sdk.brazil.hal.domain.state.EMVState
import com.pagonxt.sdk.hal.middleware.domain.emv.BCGlobal
import com.pagonxt.sdk.hal.middleware.domain.extension.runIfIsBound
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager

/**
 * Use case to start an EMV transaction.
 *
 * Responsibilities:
 * 1. Filter the relevant AIDs for the product.
 * 2. Register [EMVRepositoryImpl] as the HAL callback receiver via [IEMVInterface.create].
 * 3. Start the EMV kernel via [IEMVInterface.start].
 * 4. Set a retry lambda in [BCGlobal] so the kernel can restart after a failed read.
 *
 * Events from the hardware arrive via [EMVRepositoryImpl] callbacks (extends EMVEvents)
 * and are emitted into [EMVRepository.events] — a hot SharedFlow.
 * The ViewModel must collect [EMVRepository.events] via [ObserveEMVEventsUseCase] separately.
 *
 * [startTransaction] is a plain suspend fun — it does NOT return a Flow of states.
 */
class StartEMVTransactionUseCase(
    private val repository: EMVRepository,
    private val emvRepositoryImpl: EMVRepositoryImpl,
    private val platformManager: PlatformManager,
    private val bcGlobal: BCGlobal,
    private val transactionMapper: TransactionMapper,
) {
    companion object {
        private val TAG = StartEMVTransactionUseCase::class.java.simpleName
    }

    private val emvService: IEMVInterface?
        get() = platformManager.emvService

    /**
     * Starts the EMV transaction.
     *
     * - Signals the repository that we are waiting for a card (emits [EMVState.WaitingForCard]
     *   into the hot stream so any active subscriber is notified).
     * - Wires [emvRepositoryImpl] as the HAL event receiver.
     * - Starts the EMV kernel.
     *
     * After this returns, hardware events (card detected, approved, error, etc.)
     * will arrive via [EMVRepository.events].
     */
    @RequiresApi(Build.VERSION_CODES.O)
    suspend fun startTransaction(params: EMVParams) {
        repository.startTransaction(params)

        val emvTransaction = transactionMapper.getTransaction(
            amount = params.amount,
            otherAmount = 0L,
            isRefund = false
        )
        Log.d(TAG, "startTransaction: emvTransaction=$emvTransaction")

        val aids = filterAids(
            aidModels = params.aidModels,
            strCodProd = params.strCodProd
        )

        bcGlobal.setRetryTransaction {
            startEMVKernel(aids = aids, transaction = emvTransaction)
        }

        if (platformManager.isReady) {
            startEMVKernel(aids = aids, transaction = emvTransaction)
        } else {
            Log.d(TAG, "startTransaction: platform not ready, waiting for bind")
        }
    }

    private fun filterAids(aidModels: List<AidTableModel>, strCodProd: String): List<String> =
        aidModels
            .filter { it.product == strCodProd }
            .map { it.code.uppercase() }
            .distinct()
            .also { Log.d(TAG, "filterAids: $it") }

    /**
     * Registers [emvRepositoryImpl] as the HAL callback receiver and starts the EMV kernel.
     * Must be called only when the platform is bound ([PlatformManager.isReady]).
     */
    private fun startEMVKernel(
        aids: List<String>,
        transaction: com.pagonxt.hal.emvKernel.Transaction?
    ) {
        platformManager.runIfIsBound(
            bound = {
                // create() registers emvRepositoryImpl so HAL callbacks arrive in the hot stream.
                emvService?.create(emvRepositoryImpl)
                emvService?.start(aids, transaction)
                Log.d(TAG, "startEMVKernel: started")
            },
            notBound = {
                Log.d(TAG, "startEMVKernel: platform not bound, skipping")
            }
        )
    }
}
