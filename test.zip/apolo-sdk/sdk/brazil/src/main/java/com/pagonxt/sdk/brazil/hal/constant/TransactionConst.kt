package com.pagonxt.sdk.brazil.hal.constant

object TransactionConst {
    const val MONEY_VALUE_ZERO = "R$ 0,00"
    const val BRAZIL_COUNTRY_CODE = "076"
    const val BRAZIL_CURRENCY_CODE = "986"
    const val MAG_STRIPE_CODE: String = "021"
    const val MAG_STRIPE_CODE_FALLBACK: String = "801"
    const val CHIP_CODE: String = "051"
    const val CONTACTLESS_CODE: String = "071"
    const val REFUND = "20"
    const val PAYMENT = "00"
    const val CURRENCY_EXPONENT_BRL = 2
    const val PIN_TIMEOUT_SECONDS = 60
    const val WAIT_CARD_TIMEOUT_SECONDS = 30
    const val DUKPT_SLOT_KEY3 = 3
    const val DUKPT_SLOT_KEY2 = 2
    const val PIN_DUKPT_ENCRYPTION_METHOD = 3
    const val PIN_MIN_DIGITS = 4
    const val PIN_MAX_DIGITS = 8
    const val BUTTON_POINTS = "buttonPoints"
}