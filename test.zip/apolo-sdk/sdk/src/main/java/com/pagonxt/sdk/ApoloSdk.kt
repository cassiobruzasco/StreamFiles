package com.pagonxt.sdk

import android.content.Context
import androidx.compose.runtime.Composable
import com.pagonxt.sdk.core.ContentRouter
import com.pagonxt.sdk.core.FlowActivity
import com.pagonxt.sdk.core.SdkCountry
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.core.flow.sale.SaleFlowIntent
import com.pagonxt.sdk.core.flow.sale.SaleFlowState
import com.pagonxt.sdk.core.hooks.FlowHook
import com.pagonxt.sdk.core.hooks.PostEmissiveState
import com.pagonxt.sdk.core.hooks.PreEmissiveState
import com.pagonxt.sdk.core.uxal.ColorToken
import com.pagonxt.sdk.core.uxal.TextToken
import com.pagonxt.sdk.customizations.ContentRegistry
import com.pagonxt.sdk.customizations.HookRegistry
import com.pagonxt.sdk.customizations.InterstitialRegistry
import com.pagonxt.sdk.di.SdkDI
import com.pagonxt.sdk.features.ContentBuilderFactory
import com.pagonxt.sdk.features.ContentOverriding
import com.pagonxt.sdk.features.FlowHookSetup
import com.pagonxt.sdk.features.HookProvider
import com.pagonxt.sdk.features.InterstitialSetup
import com.pagonxt.sdk.features.ThemeOverriding
import com.pagonxt.sdk.brazil.uxal.SaleFlowBuilder

/**
 * Contrato principal para interação com o Apolo SDK.
 * Define as operações de alto nível que o SDK expõe para o aplicativo cliente.
 */
interface Apolo {
    /**
     * Inicia o fluxo de pagamento gerenciado pelo SDK.
     *
     * Esta função lança a `Activity` principal do SDK, que cuidará de todos os passos
     * da transação, desde a entrada de valores até a comunicação com serviços de pagamento.
     *
     * @param context O `Context` do aplicativo hospedeiro a partir da qual o fluxo será iniciado.
     */
    fun initSale(context: Context)
}

/**
 * Implementação interna do cliente Apolo.
 * Responsável por traduzir as chamadas da interface [Apolo] em ações concretas,
 * como iniciar a Activity do fluxo de pagamento.
 */
internal class ApoloImpl : Apolo {
    override fun initSale(context: Context) {
        val intent = FlowActivity.newIntent(context, "sale_flow")
        context.startActivity(intent)
    }
}

/**
 * Ponto de entrada principal para o Apolo SDK.
 *
 * Use [ApoloSdk.Builder] para configurar e criar uma instância do cliente [Apolo].
 * O SDK deve ser inicializado apenas uma vez na aplicação.
 *
 * Exemplo de uso:
 * ```
 * val apoloClient = ApoloSdk.Builder(applicationContext)
 *     .customize { ... }
 *     .build()
 * ```
 */
object ApoloSdk {
    private var instance: Apolo? = null

    /**
     * Retorna a instância singleton do cliente [Apolo].
     *
     * @throws IllegalStateException se o SDK não tiver sido inicializado através do [Builder.build].
     * @return A instância configurada do cliente [Apolo].
     */
    fun getClient(): Apolo {
        return instance
            ?: throw IllegalStateException("SDK não inicializado. Use ApoloSdk.Builder()...build() primeiro.")
    }

    /**
     * Construtor para configurar e inicializar o [ApoloSdk].
     * Permite a personalização de temas, a substituição de telas e a injeção de lógicas customizadas.
     *
     * @param context O `Context` da aplicação, usado para acessar recursos e iniciar Activities.
     */
    class Builder(private val context: Context) {
        internal val colorOverrides = mutableMapOf<String, Long>()
        internal val textOverrides = mutableMapOf<String, String>()

        internal val contentRegistry: ContentRegistry = ContentRegistry()
        internal val interstitialRegistry: InterstitialRegistry =
            InterstitialRegistry()
        internal val hookRegistry: HookRegistry = HookRegistry()


        /**
         * Finaliza a configuração e inicializa o SDK, retornando a instância do cliente [Apolo].
         * Este método configura a injeção de dependência interna do SDK com todas as
         * personalizações fornecidas.
         */
        fun build(): Apolo {
            // TODO: review this implementation about witch country to choose
            val country = when (BuildConfig.SDK_COUNTRY) {
                "BRAZIL" -> SdkCountry.BRAZIL
                "ARGENTINA" -> SdkCountry.ARGENTINA
                else -> error("Unknown BuildConfig.SDK_COUNTRY='${BuildConfig.SDK_COUNTRY}'")
            }

            SdkDI.init(
                context = context,
                country = country,
                colorOverrides = colorOverrides,
                textOverrides = textOverrides,
                hookRepository = hookRegistry,
                contentRouter = ContentRouter(
                    contentRegistry,
                    interstitialRegistry
                )
            )

            val client = ApoloImpl()

            instance = client

            return client
        }

        /**
         * Personaliza a aparência do SDK para corresponder à identidade visual do aplicativo.
         * Permite a sobrescrita de cores e textos definidos por tokens.
         *
         * @param block Um lambda com o receptor [ThemeOverriding] para definir as personalizações.
         * @see ThemeOverriding para tokens de customização disponíveis.
         * @see ColorToken
         * @see TextToken
         */
        fun customize(block: ThemeOverriding.() -> Unit): Builder {
            val themeOverriding = ThemeOverriding()
            themeOverriding.block()

            colorOverrides.putAll(themeOverriding.colors)
            textOverrides.putAll(themeOverriding.texts)
            return this
        }

        /**
         * Adiciona uma tela "intersticial" customizada a ser exibida durante o fluxo de pagamento.
         *
         * Um intersticial é uma tela que pode ser exibida condicionalmente quando o fluxo atinge
         * um determinado estado [U]. É útil para exibir informações adicionais, solicitar confirmações
         * ou realizar ações que não fazem parte do fluxo padrão, sem substituir a tela original.
         *
         * @param U O tipo de [FlowState] que acionará este intersticial.
         * @param condition Uma função que avalia o estado atual [U] e retorna `true` se o intersticial deve ser exibido.
         * @param content O conteúdo Composable da tela intersticial. Recebe o estado atual e uma função `proceed`
         * que deve ser chamada para continuar o fluxo normal.
         */
        inline fun <reified U : FlowState> addFlowInterstitial(
            noinline condition: (U) -> Boolean,
            noinline content: @Composable (state: U, proceed: () -> Unit) -> Unit
        ): Builder {
            val definition = InterstitialSetup(this)
            return definition.whenState(U::class, condition, content)
        }

        /**
         * Registra uma ação (hook) a ser executada *antes* da lógica de negócio de um estado [U] ser processada.
         *
         * Hooks são úteis para executar efeitos colaterais (side-effects) que não envolvem UI,
         * como logging, analytics ou modificações em dados que serão usados pelo estado.
         * A ação não deve realizar operações de longa duração na thread principal.
         *
         * @param U O tipo de [PreEmissiveState] que acionará esta ação.
         * @param provider Um [HookProvider] para obtenção do [FlowHook] a ser executado.
         */
        inline fun <reified U : PreEmissiveState> preHookAction(provider: HookProvider): Builder {
            val definition = FlowHookSetup(this)
            return definition.before(U::class, provider)
        }

        /**
         * Registra uma ação (hook) a ser executada *depois* da lógica de negócio de um estado [U] ser processada.
         *
         * Hooks são úteis para executar efeitos colaterais (side-effects) que não envolvem UI,
         * como logging, analytics ou reagir a um resultado de uma operação.
         * A ação não deve realizar operações de longa duração na thread principal.
         *
         * @param U O tipo de [PostEmissiveState] que acionará esta ação.
         * @param provider Um [HookProvider] para obtenção do [FlowHook] a ser executado.
         */
        inline fun <reified U : PostEmissiveState> postHookAction(provider: HookProvider): Builder {
            val definition = FlowHookSetup(this)
            return definition.after(U::class, provider)
        }

        /**
         * Habilita o uso do Fluxo de Venda no SDK.
         *
         * @param factory Um [ContentBuilderFactory] opcional para personalizar a UI do fluxo de venda.
         * @return O próprio [Builder] para permitir o encadeamento de chamadas.
         */
        fun useSale(
            factory: ContentBuilderFactory<SaleFlowState, SaleFlowIntent>? = null
        ): Builder {
            return ContentOverriding(this)
                .register(
                    SaleFlowState::class,
                    SaleFlowIntent::class,
                    "sale_flow",
                    SaleFlowState.InitialState,
                    factory ?: ContentBuilderFactory { SaleFlowBuilder() }
                )
        }
    }
}