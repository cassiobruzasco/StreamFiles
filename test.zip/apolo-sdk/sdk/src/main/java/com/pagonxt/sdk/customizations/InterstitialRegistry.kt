package com.pagonxt.sdk.customizations

import com.pagonxt.sdk.ApoloSdk
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.features.Interstitial
import kotlin.reflect.KClass

/**
 * Registro central para as telas "intersticiais" do fluxo.
 *
 * Um intersticial é uma tela customizada que pode ser inserida condicionalmente
 * no fluxo de UI quando um determinado [FlowState] é atingido.
 *
 * Esta classe armazena e fornece as definições de [Interstitial] que foram
 * configuradas através do método [ApoloSdk.Builder.addFlowInterstitial].
 *
 * O [com.pagonxt.sdk.core.ContentRouter] consulta este registro para determinar se há algum
 * intersticial a ser exibido para o estado atual do fluxo.
 */
internal class InterstitialRegistry {
    private val interstitials = mutableMapOf<KClass<*>, MutableList<Interstitial<*>>>()

    /**
     * Registra um [Interstitial] para um tipo de estado específico.
     *
     * @param U O tipo de [FlowState] que acionará o intersticial.
     * @param kClass O [KClass] do estado.
     * @param interceptor A definição do [Interstitial] a ser registrada.
     */
    fun <U : FlowState> registerFor(kClass: KClass<U>, interceptor: Interstitial<U>) {
        val list = interstitials.getOrPut(kClass) { mutableListOf() }
        // O cast não verificado é seguro porque o mapa é indexado pela KClass,
        // garantindo que a lista recuperada corresponda ao tipo U.
        @Suppress("UNCHECKED_CAST")
        (list as MutableList<Interstitial<U>>).add(interceptor)
    }

    /**
     * Retorna a lista de intersticiais registrados para um tipo de estado específico.
     *
     * @param U O tipo de [FlowState].
     * @param kClass O [KClass] do estado.
     * @return Uma lista de [Interstitial] para o tipo de estado especificado, ou uma lista vazia se nenhum for encontrado.
     */
    @Suppress("UNCHECKED_CAST")
    fun <U : FlowState> getFor(kClass: KClass<U>): List<Interstitial<U>> {
        return interstitials[kClass] as? List<Interstitial<U>> ?: emptyList()
    }
}