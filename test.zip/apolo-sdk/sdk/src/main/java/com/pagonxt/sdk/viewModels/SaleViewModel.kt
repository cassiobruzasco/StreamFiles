package com.pagonxt.sdk.viewModels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pagonxt.sdk.core.flow.sale.SaleFlowIntent
import com.pagonxt.sdk.core.flow.sale.SaleFlowState
import com.pagonxt.sdk.di.SdkDI
import com.pagonxt.sdk.payment.core.contracts.FlowEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * O ViewModel principal para o fluxo de venda.
 *
 * Este ViewModel atua como a **ponte** entre a camada de lógica de negócios (o [SaleFlowEngine])
 * e a camada de UI (a [SaleFlowActivity] e suas [FlowScreen]s). Ele adere aos princípios
 * de arquitetura do Android, sobrevivendo a mudanças de configuração e gerenciando o ciclo de vida.
 *
 * ## Arquitetura e Adaptação
 *
 * 1.  **Injeção de Dependência Agnóstica:** O ViewModel injeta a interface abstrata [SaleFlowEngine].
 *     Ele não conhece a implementação concreta (ex: `BrSaleEngineImpl`, `ArSaleEngineImpl`).
 *     O sistema de DI (Koin) é responsável por fornecer a instância correta do motor
 *     com base na configuração do SDK, tornando o ViewModel totalmente reutilizável e
 *     independente do país.
 *
 * 2.  **Unidirectional Data Flow (UDF):** Ele observa o `state` do [SaleFlowEngine] e o expõe
 *     como um `StateFlow` (`uiState`) para a UI. A UI reage a essas mudanças de estado.
 *
 * 3.  **Delegação de Intenções:** As intenções geradas pela UI são recebidas pelo método
 *     [processIntent] e são simplesmente encaminhadas para o [SaleFlowEngine] para processamento.
 *
 * 4.  **Gerenciamento do Ciclo de Vida:** Ele garante que o [SaleFlowEngine] seja limpo (`onCleared`)
 *     quando o ViewModel é destruído, evitando vazamentos de memória e coroutines.
 */
internal class SaleViewModel : ViewModel(), KoinComponent {

    // Implementa KoinComponent para usar a injeção de dependência do SDK.
    override fun getKoin() = SdkDI.getKoin()

    // Injeta a implementação correta do motor de fluxo (agnóstico ao país).
    private val saleFlowEngine: FlowEngine<SaleFlowState, SaleFlowIntent> by inject()

    // O estado interno que será atualizado com as emissões do motor.
    private val _uiState = MutableStateFlow<SaleFlowState>(
        SaleFlowState.InitialState
    )

    init {
        // Coleta os estados emitidos pelo motor e os atualiza no _uiState.
        viewModelScope.launch {
            saleFlowEngine.state.collect {
                emitState(it)
            }
        }
    }

    /**
     * O fluxo de estado da UI, observado pela Activity para renderizar a tela apropriada.
     */
    val uiState = _uiState.asStateFlow()

    /**
     * Atualiza o estado da UI.
     */
    fun emitState(newState: SaleFlowState) {
        _uiState.value = newState
    }

    /**
     * Encaminha uma intenção da UI para o motor de fluxo para ser processada.
     */
    fun processIntent(intent: SaleFlowIntent) {
        saleFlowEngine.processEvent(intent)
    }

    /**
     * Garante a limpeza dos recursos do motor quando o ViewModel é destruído.
     */
    override fun onCleared() {
        super.onCleared()
        saleFlowEngine.onCleared()
    }
}