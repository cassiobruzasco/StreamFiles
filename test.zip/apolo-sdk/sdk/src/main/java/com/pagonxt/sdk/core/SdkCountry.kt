package com.pagonxt.sdk.core

/**
 * Defines which country-specific implementation should be used by the SDK.
 */
enum class SdkCountry {
    BRAZIL,
    ARGENTINA,
}
