package com.pagonxt.sdk.customizations

import com.pagonxt.sdk.ApoloSdk
import com.pagonxt.sdk.core.hooks.PostEmissiveState
import com.pagonxt.sdk.core.hooks.PreEmissiveState
import com.pagonxt.sdk.payment.core.contracts.FlowHookRepository
import com.pagonxt.sdk.core.hooks.FlowHook
import com.pagonxt.sdk.features.HookProvider
import kotlin.reflect.KClass

/**
 * Registro central para as ações de "hook" (gancho) do fluxo de pagamento.
 *
 * Esta classe armazena e fornece as ações customizadas que devem ser executadas
 * antes ([PreEmissiveState]) ou depois ([PostEmissiveState]) de um estado específico
 * do fluxo ser processado pela lógica de negócios.
 *
 * As instâncias de [FlowHook] são registradas aqui através dos métodos
 * [ApoloSdk.Builder.preHookAction] e [ApoloSdk.Builder.postHookAction]. O [com.pagonxt.sdk.payment.core.contracts.FlowEngine]
 * então consulta este registro usando os métodos `getPreHooks` e `getPostHooks`
 * para executar as ações apropriadas no momento certo.
 *
 * A classe implementa a interface [FlowHookRepository], atuando como a fonte da verdade
 * para os hooks injetados via DI.
 */
internal class HookRegistry : FlowHookRepository {
    private val preHooks = mutableMapOf<KClass<*>, MutableList<HookProvider>>()
    private val postHooks = mutableMapOf<KClass<*>, MutableList<HookProvider>>()

    /**
     * Registra uma ação de "pre-hook" para um tipo de estado específico.
     *
     * @param kClass O [KClass] do estado que acionará o hook.
     * @param provider O [HookProvider] para obtenção do [FlowHook] a ser executado.
     */
    fun <U : PreEmissiveState> registerPreHook(
        kClass: KClass<U>,
        provider: HookProvider
    ) {
        val list = preHooks.getOrPut(kClass) { mutableListOf() }
        list.add(provider)
    }

    /**
     * Retorna a lista de "pre-hooks" registrados para um tipo de estado.
     */
    override fun <U : PreEmissiveState> getPreHooks(kClass: KClass<U>): List<FlowHook> {
        return preHooks[kClass]?.map { it.obtain() } ?: emptyList()
    }

    /**
     * Registra uma ação de "post-hook" para um tipo de estado específico.
     *
     * @param kClass O [KClass] do estado que acionará o hook.
     * @param provider O [HookProvider] para obtenção do [FlowHook] a ser executado.
     */
    fun <U : PostEmissiveState> registerPostHook(
        kClass: KClass<U>,
        provider: HookProvider
    ) {
        val list = postHooks.getOrPut(kClass) { mutableListOf() }
        list.add(provider)
    }

    /**
     * Retorna a lista de "post-hooks" registrados para um tipo de estado.
     */
    override fun <U : PostEmissiveState> getPostHooks(kClass: KClass<U>): List<FlowHook> {
        return postHooks[kClass]?.map { it.obtain() } ?: emptyList()
    }
}