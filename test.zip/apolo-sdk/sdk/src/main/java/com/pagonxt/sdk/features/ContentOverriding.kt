package com.pagonxt.sdk.features

import com.pagonxt.sdk.ApoloSdk.Builder
import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.core.uxal.ContentBuilder
import kotlin.reflect.KClass

/**
 * DSL para gerenciar a lógica de sobreescrita de fluxos de telas.
 */
class ContentOverriding internal constructor(
    private val builder: Builder
) {
    fun <U : FlowState, T : FlowIntent> register(
        stateClass: KClass<U>,
        intentClass: KClass<T>,
        key: String,
        initialState: U,
        factory: ContentBuilderFactory<U, T>
    ): Builder {
        builder.contentRegistry.register(stateClass, intentClass, key, initialState, factory)
        return builder
    }
}

/**
 * Factory interface for creating instances of [ContentBuilder].
 */
fun interface ContentBuilderFactory<U : FlowState, T : FlowIntent> {
    fun create(): ContentBuilder<U, T>
}