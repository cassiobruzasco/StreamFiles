package com.pagonxt.sdk.features

import androidx.compose.runtime.Composable
import com.pagonxt.sdk.ApoloSdk.Builder
import com.pagonxt.sdk.core.flow.FlowState
import kotlin.reflect.KClass

data class Interstitial<U : FlowState>(
    val condition: (U) -> Boolean,
    val content: @Composable (state: U, onProceed: () -> Unit) -> Unit
)

/**
 * DSL para gerenciar a lógica de registro de interstitials.
 */
class InterstitialSetup(
    private val builder: Builder
) {
    fun <U : FlowState> whenState(
        kClass: KClass<U>,
        condition: (U) -> Boolean,
        content: @Composable (state: U, proceed: () -> Unit) -> Unit
    ): Builder {
        builder.interstitialRegistry.registerFor(kClass, Interstitial(condition, content))
        return builder
    }
}