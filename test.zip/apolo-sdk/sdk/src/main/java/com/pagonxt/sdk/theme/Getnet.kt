package com.pagonxt.sdk.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.pagonxt.sdk.di.SdkDI
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.uxal.ui_common.utils.toComposeColor

@Composable
fun GetnetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val resolver = SdkDI.getKoin().get<ResourceResolver>()
    val colorScheme = when {
        else -> lightColorScheme(
            primary = resolver.resolveColor("uxal_color_primary").toComposeColor(),
            onPrimary = resolver.resolveColor("uxal_color_on_primary").toComposeColor(),
            primaryContainer = resolver.resolveColor("uxal_color_primary_container")
                .toComposeColor(),
            onPrimaryContainer = resolver.resolveColor("uxal_color_on_primary_container")
                .toComposeColor(),
            secondary = resolver.resolveColor("uxal_color_secondary").toComposeColor(),
            onSecondary = resolver.resolveColor("uxal_color_on_secondary").toComposeColor(),
            tertiary = resolver.resolveColor("uxal_color_tertiary").toComposeColor(),
            background = resolver.resolveColor("uxal_color_background").toComposeColor(),
            surface = resolver.resolveColor("uxal_color_surface").toComposeColor(),
            onBackground = resolver.resolveColor("uxal_color_onBackground").toComposeColor(),
            onSurface = resolver.resolveColor("uxal_color_onSurface").toComposeColor()
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            @Suppress("DEPRECATION")
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(
            headlineLarge = TextStyle(
                fontFamily = FontFamily.Default, // TODO: Substituir por Font(R.font.santander_bold)
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                lineHeight = 40.sp,
                letterSpacing = 0.sp,
            ),
            titleLarge = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.SemiBold,
                fontSize = 22.sp,
                lineHeight = 28.sp,
                letterSpacing = 0.sp,
            ),
            bodyLarge = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Normal,
                fontSize = 16.sp,
                lineHeight = 24.sp,
                letterSpacing = 0.5.sp,
            ),
            labelLarge = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                letterSpacing = 0.1.sp,
            )
        ),
        content = content
    )
}