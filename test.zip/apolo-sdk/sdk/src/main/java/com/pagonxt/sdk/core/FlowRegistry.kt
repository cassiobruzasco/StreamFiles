package com.pagonxt.sdk.core

import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import kotlin.reflect.KClass

/**
 * Contém a configuração completa necessária para inicializar e executar um fluxo de UI.
 *
 * Esta classe de dados encapsula todos os componentes essenciais que a [FlowActivity]
 * precisa para orquestrar um fluxo dinamicamente: as classes de `State` e `Intent`
 * para resolução de UI e o estado inicial para a `FlowViewModel`.
 *
 * @param S O tipo de [FlowState] que governa o fluxo.
 * @param I O tipo de [FlowIntent] que o fluxo processa.
 * @property stateClass A referência `KClass` para o estado, usada para encontrar a UI correta.
 * @property intentClass A referência `KClass` para a intenção, usada para encontrar a UI correta.
 * @property initialState O estado com o qual a `FlowViewModel` deve ser inicializada.
 */
internal data class FlowConfiguration<S : FlowState, I : FlowIntent>(
    val stateClass: KClass<S>,
    val intentClass: KClass<I>,
    val initialState: S
)

/**
 * Um registro central que mapeia chaves de string (ex: "sale_flow") para as suas
 * respectivas configurações de fluxo ([FlowConfiguration]).
 *
 * Este registro é o mecanismo que permite à [FlowActivity] ser genérica. A activity
 * usa uma chave recebida via `Intent` para consultar este registro e descobrir qual
 * fluxo ela precisa renderizar, sem nunca conhecer os tipos concretos em tempo de compilação.
 */
internal interface FlowRegistry {
    /**
     * Registra uma nova configuração de fluxo associada a uma chave única.
     *
     * Esta função é chamada durante a inicialização do SDK para cada fluxo disponível.
     *
     * @param key A chave de string única para o fluxo (ex: "sale_flow").
     * @param configuration O objeto [FlowConfiguration] que define o fluxo.
     */
    fun register(key: String, configuration: FlowConfiguration<*, *>)

    /**
     * Obtém uma configuração de fluxo previamente registrada a partir de sua chave.
     *
     * @param key A chave do fluxo a ser recuperado.
     * @return A [FlowConfiguration] correspondente ou `null` se a chave não for encontrada.
     */
    fun get(key: String): FlowConfiguration<*, *>?
}

/**
 * Implementação padrão e em memória do [FlowRegistry].
 *
 * Armazena as configurações de fluxo em um mapa mutável.
 */
internal class InMemoryFlowRegistry : FlowRegistry {
    private val flows = mutableMapOf<String, FlowConfiguration<*, *>>()

    override fun register(key: String, configuration: FlowConfiguration<*, *>) {
        if (flows.containsKey(key)) {
            throw IllegalArgumentException("Flow with key $key already exists")
        }
        flows[key] = configuration
    }

    override fun get(key: String): FlowConfiguration<*, *>? = flows[key]
}