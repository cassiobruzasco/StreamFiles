package com.pagonxt.sdk.features

import com.pagonxt.sdk.core.uxal.ColorToken
import com.pagonxt.sdk.core.uxal.TextToken

/**
 * DSL para customização do tema do SDK.
 * Fornece métodos para sobrescrever cores e textos.
 */
class ThemeOverriding internal constructor() {
    internal val colors = mutableMapOf<String, Long>()
    internal val texts = mutableMapOf<String, String>()

    /**
     * Sobrescreve uma cor do tema.
     * @param token O [ColorToken] que identifica a cor a ser alterada.
     * @param color A nova [androidx.compose.ui.graphics.Color] a ser aplicada.
     */
    fun setColor(token: ColorToken, color: androidx.compose.ui.graphics.Color) {
        colors[token.key] = color.value.toLong()
    }

    /**
     * Sobrescreve um texto do tema.
     * @param token O [TextToken] que identifica o texto a ser alterado.
     * @param value O novo valor [String] a ser aplicado.
     */
    fun setText(token: TextToken, value: String) {
        texts[token.key] = value
    }
}