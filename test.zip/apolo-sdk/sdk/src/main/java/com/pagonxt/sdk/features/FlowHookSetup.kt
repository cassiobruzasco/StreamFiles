package com.pagonxt.sdk.features

import com.pagonxt.sdk.ApoloSdk.Builder
import com.pagonxt.sdk.core.hooks.PostEmissiveState
import com.pagonxt.sdk.core.hooks.PreEmissiveState
import com.pagonxt.sdk.core.hooks.FlowHook
import kotlin.reflect.KClass

/**
 * DSL para gerenciar a lógica de registro de hooks.
 */
class FlowHookSetup(
    private val builder: Builder
) {
    fun <U : PreEmissiveState> before(kClass: KClass<U>, hook: HookProvider): Builder {
        builder.hookRegistry.registerPreHook(kClass, hook)
        return builder
    }

    fun <U : PostEmissiveState> after(kClass: KClass<U>, hook: HookProvider): Builder {
        builder.hookRegistry.registerPostHook(kClass, hook)
        return builder
    }
}

fun interface HookProvider {
    fun obtain(): FlowHook
}