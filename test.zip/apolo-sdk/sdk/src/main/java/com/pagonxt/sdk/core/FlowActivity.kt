package com.pagonxt.sdk.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.di.SdkDI
import com.pagonxt.sdk.theme.GetnetTheme
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.hal.middleware.Middleware
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager
import com.pagonxt.sdk.hal.middleware.sdk.SdkHelper
import java.util.UUID
import kotlin.jvm.java

/**
 * Activity genérica que hospeda e orquestra um fluxo de UI completo do SDK.
 *
 * Esta Activity atua como o ponto de entrada único para qualquer fluxo de tela,
 * seja ele de venda, devolução ou qualquer outro. Ela é projetada para ser
 * completamente agnóstica em relação ao fluxo específico que está sendo executado.
 *
 * ## Arquitetura e Funcionamento
 *
 * 1.  **Iniciação por Chave:** Para iniciar um fluxo, a Activity deve ser chamada
 *     com uma `String` (a "chave de fluxo", ex: "sale_flow") passada via `Intent`.
 *
 * 2.  **Resolução Dinâmica:** No `onCreate`, a Activity utiliza esta chave para consultar
 *     o [FlowRegistry]. Este registro, configurado na inicialização do SDK,
 *     fornece a configuração completa do fluxo (classes de `State` e `Intent`, e o estado inicial).
 *
 * 3.  **Construção de UI e ViewModel:** Com a configuração em mãos, a Activity:
 *     - Obtém a `ContentFactory` correta do [ContentRegistry] para construir a UI.
 *     - Cria uma `ViewModelProvider.Factory` para instanciar a [FlowViewModel] genérica
 *       com o estado inicial apropriado.
 *
 * 4.  **Delegação da Renderização:** A Activity observa o `uiState` da ViewModel e o
 *     passa para a `Content` da UI, que é responsável por renderizar a tela
 *     adequada para o estado atual.
 *
 * Este design desacoplado permite que novos fluxos de UI sejam adicionados ao SDK
 * sem a necessidade de criar novas Activities, exigindo apenas o registro de uma
 * nova configuração.
 */
internal class FlowActivity : ComponentActivity() {

    private var sessionId: String? = null
    private val koin = SdkDI.getKoin()
    private val platform: PlatformManager by lazy { koin.get() }
    private val sdkHelper: SdkHelper by lazy { koin.get() }

    override fun onStart() {
        super.onStart()
        platform.registerPlatform()
    }

    override fun onResume() {
        super.onResume()
        platform.registerPlatform()
    }

    override fun onPause() {
        super.onPause()
        platform.unregisterPlatform()
    }

    override fun onStop() {
        super.onStop()
        platform.unbindPlatform()
        platform.unregisterPlatform()
        platform.cancel()
        sdkHelper.disconnectSdk()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize HAL middleware services
        Middleware(sdkHelper).setup()

        val flowKey = intent.getStringExtra(KEY_FLOW_KEY)
            ?: throw IllegalArgumentException("A chave do fluxo (KEY_FLOW_KEY) é obrigatória no Intent.")

        sessionId = savedInstanceState?.getString(KEY_SESSION_ID)
            ?: UUID.randomUUID().toString()

        val contentRouter: ContentRouter = koin.get()
        val resourceResolver: ResourceResolver = koin.get()

        val (contentBuilder, initialState) = contentRouter.resolve(flowKey)
            ?: throw IllegalStateException("Nenhuma configuração de fluxo encontrada para a chave '$flowKey'")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
            }
        })

        setContent {
            val viewModelFactory = object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    if (modelClass.isAssignableFrom(FlowViewModel::class.java)) {
                        @Suppress("UNCHECKED_CAST")
                        return FlowViewModel<FlowState, FlowIntent>(initialState) as T
                    }
                    throw IllegalArgumentException("ViewModel desconhecida: ${modelClass.name}")
                }
            }

            val viewModel: FlowViewModel<FlowState, FlowIntent> = viewModel(
                key = sessionId,
                factory = viewModelFactory
            )

            val onIntent: (FlowIntent) -> Unit = { intent ->
                viewModel.processIntent(intent)
            }

            val state = viewModel.uiState.collectAsState().value

            GetnetTheme {
                contentBuilder.Content(
                    resourceResolver,
                    flowState = state,
                    onIntent = onIntent,
                    onExit = { finish() }
                )
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_SESSION_ID, sessionId)
    }

    companion object {
        private const val KEY_SESSION_ID = "flowSessionId"
        private const val KEY_FLOW_KEY = "flowKey"

        /**
         * Cria um `Intent` para iniciar a `FlowActivity` com um fluxo específico.
         *
         * @param context O contexto de origem.
         * @param flowKey A chave que identifica o fluxo a ser iniciado (ex: "sale_flow").
         * @return O `Intent` configurado para iniciar a `FlowActivity`.
         */
        fun newIntent(context: Context, flowKey: String): Intent {
            return Intent(context, FlowActivity::class.java).apply {
                putExtra(KEY_FLOW_KEY, flowKey)
            }
        }
    }
}