package com.pagonxt.sdk.customizations


import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.core.uxal.ContentBuilder
import com.pagonxt.sdk.features.ContentBuilderFactory
import kotlin.reflect.KClass

/**
 * Registro central para os construtores de Fluxo.
 *
 * Este registro armazena mapeamentos de um par `(FlowState, FlowIntent)` para uma
 * [ContentBuilderFactory] específica.
 *
 * O [com.pagonxt.sdk.core.ContentRouter] consulta este registro para encontrar uma fábrica customizada
 * para a combinação de estado e intenção atual, antes de recorrer à implementação padrão do SDK.
 */
internal class ContentRegistry {

    internal data class Configuration<S : FlowState, I : FlowIntent>(
        val stateClass: KClass<S>,
        val intentClass: KClass<I>,
        val initialState: S
    )

    private val flows = mutableMapOf<String, Configuration<*, *>>()

    private val factories = mutableMapOf<Pair<KClass<*>, KClass<*>>, ContentBuilderFactory<*, *>>()

    /**
     * Registra uma [ContentBuilderFactory] para uma combinação específica de estado e intenção.
     *
     * @param U O tipo de [FlowState].
     * @param T O tipo de [FlowIntent].
     * @param stateClass O [KClass] do estado.
     * @param intentClass O [KClass] da intenção.
     * @param factory A [ContentBuilderFactory] que criará a tela customizada.
     */
    fun <U : FlowState, T : FlowIntent> register(
        stateClass: KClass<U>,
        intentClass: KClass<T>,
        key: String,
        initialState: U,
        factory: ContentBuilderFactory<U, T>,
    ) {
        if (flows.containsKey(key))
            throw IllegalArgumentException("Flow with key $key already exists")
        flows[key] = Configuration(stateClass, intentClass, initialState)
        factories[stateClass to intentClass] = factory
    }

    /**
     * Obtém um [ContentBuilder] para um fluxo específico.
     *
     * @param key A chave única que identifica o Flow desejado
     * @return Um par contendo o [ContentBuilder] e o estado inicial do fluxo, ou `null` se nenhum registro for encontrado.
     */
    fun getForFlow(key: String): Pair<Configuration<*, *>, ContentBuilderFactory<*, *>>? {
        val config = flows[key] ?: return null
        val factory = factories[config.stateClass to config.intentClass] ?: return null
        return config to factory
    }
}