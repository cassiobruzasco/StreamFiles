package com.pagonxt.sdk.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.customizations.ContentRegistry
import com.pagonxt.sdk.core.uxal.ContentBuilder
import com.pagonxt.sdk.features.Interstitial
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.customizations.InterstitialRegistry

/**
 * Orquestrador central que resolve e constrói a tela apropriada para um dado estado de fluxo.
 *
 * O `ScreenRegistry` é o cérebro da renderização da UI. Ele combina as personalizações
 * de `override` e `interstitial` com a implementação padrão do SDK para determinar
 * qual tela deve ser exibida.
 *
 * A resolução segue uma hierarquia clara:
 * 1.  **Intersticiais:** Primeiro, verifica se há alguma tela intersticial [Interstitial]
 *     cuja condição seja atendida para o estado atual. Se sim, o intersticial é exibido.
 *     O intersticial tem controle sobre quando e como continuar para a tela original.
 * 2.  **Substituições (Overrides):** Se nenhum intersticial estiver ativo, ele procura por uma
 *     substituição de tela completa no [OverrideRegistry]. Se uma for encontrada para a
 *     combinação de estado e intenção, ela é usada.
 * 3.  **Implementação Padrão (DI):** Se não houver substituição, ele recorre ao sistema de
 *     Injeção de Dependência (Koin) para obter a implementação padrão da tela para o
 *     estado atual. É assim que as telas específicas de cada país (ex: `BrSaleScreen`)
 *     são injetadas no fluxo.
 *
 * @param contentRegistry O registro para as substituições de tela.
 * @param interstitialRegistry O registro para as telas intersticiais.
 */
internal class ContentRouter(
    private val contentRegistry: ContentRegistry,
    private val interstitialRegistry: InterstitialRegistry
) {

    /**
     * Uma implementação de [ContentBuilder] que atua como um "decorador", envolvendo uma tela
     * original com a lógica para exibir intersticiais.
     */
    private class InterstitialContentBuilder<U : FlowState, T : FlowIntent>(
        private val originalRenderer: ContentBuilder<U, T>,
        private val interstitials: List<Interstitial<U>>
    ) : ContentBuilder<U, T> {

        @Composable
        override fun Content(
            resourceResolver: ResourceResolver,
            flowState: U,
            onIntent: (T) -> Unit,
            onExit: () -> Unit
        ) {
            val activeOverlay = interstitials.firstOrNull { it.condition(flowState) }

            var isIntercepted by remember(flowState, activeOverlay) {
                mutableStateOf(activeOverlay != null)
            }

            if (isIntercepted && activeOverlay != null) {
                activeOverlay.content(flowState) {
                    isIntercepted = false
                }
            } else {
                originalRenderer.Content(resourceResolver, flowState, onIntent, onExit)
            }
        }
    }

    fun resolve(flowKey: String): Pair<ContentBuilder<*, *>, FlowState>? {
        val (config, factory) = contentRegistry.getForFlow(flowKey)
            ?: return null
        val interstitials = interstitialRegistry.getFor(config.stateClass)
        val builder = factory.create()
        return if (interstitials.isNotEmpty()) {
            @Suppress("UNCHECKED_CAST")
            InterstitialContentBuilder(
                builder,
                interstitials as List<Interstitial<FlowState>>
            ) to config.initialState
        } else {
            builder to config.initialState
        }
    }
}