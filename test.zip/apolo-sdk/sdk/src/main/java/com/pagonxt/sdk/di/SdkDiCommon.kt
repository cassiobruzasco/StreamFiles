package com.pagonxt.sdk.di

import android.content.Context
import com.pagonxt.sdk.core.ContentRouter
import com.pagonxt.sdk.core.SdkCountry
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.hal.middleware.Middleware
import com.pagonxt.sdk.payment.core.contracts.FlowHookRepository
import com.pagonxt.sdk.uxal.ui_common.services.ResourceResolverImpl
import com.pagonxt.sdk.uxal.ui_common.services.WhiteLabelConfig
import org.koin.core.module.Module
import org.koin.core.qualifier.named
import org.koin.dsl.module

internal object SdkDiCommon {
    fun baseModules(
        context: Context,
        country: SdkCountry,
        colorOverrides: Map<String, Long>,
        textOverrides: Map<String, String>,
        hookRepository: FlowHookRepository,
        contentRouter: ContentRouter,
        /**
         * Called once PosDigital is connected AND the PlatformService is successfully bound.
         * Use this to inject country-specific hardware setup (e.g. BrPlatformManager.setUpEMVParameters).
         * Defaults to null (no-op) for flavors that don't need platform-bound initialization.
         */
        onPlatformBound: (() -> Unit)? = null,
    ): List<Module> = listOf(
        module {
            single { country }
            single(named("colorOverrides")) { colorOverrides }
            single(named("textOverrides")) { textOverrides }
        },
        module { single<FlowHookRepository> { hookRepository } },
        module { single<ContentRouter> { contentRouter } },
        module {
            single<WhiteLabelConfig> {
                WhiteLabelConfig(
                    colorOverrides = get(named("colorOverrides")),
                    textOverrides = get(named("textOverrides"))
                )
            }
            single<ResourceResolver> {
                ResourceResolverImpl(
                    context = context,
                    whiteLabelConfig = get()
                )
            }
        },
        Middleware.injection(context, onPlatformBound),
    )
}
