package com.pagonxt.sdk.core

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pagonxt.sdk.core.flow.FlowIntent
import com.pagonxt.sdk.core.flow.FlowState
import com.pagonxt.sdk.di.SdkDI
import com.pagonxt.sdk.payment.core.contracts.FlowEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * ViewModel genérica que atua como a ponte entre a camada de UI e a camada de lógica de negócios (MVI).
 *
 * Esta ViewModel é projetada para funcionar com qualquer tipo de [FlowState] e [FlowIntent],
 * tornando-a um componente central e reutilizável para todos os fluxos do SDK.
 *
 * @param S O tipo de [FlowState] que esta ViewModel gerencia.
 * @param I O tipo de [FlowIntent] que esta ViewModel processa.
 * @param initialState O estado inicial do fluxo, fornecido durante a criação da ViewModel.
 *
 * ## Funcionamento
 *
 * 1.  **Injeção de Dependência:** A ViewModel injeta uma instância genérica do [FlowEngine]
 *     usando Koin. O Koin é responsável por prover a implementação correta do motor
 *     (ex: `SaleEngineImpl`) com base nos tipos `S` e `I` definidos no módulo de DI.
 *
 * 2.  **Coleta de Estado (Unidirectional Data Flow):** No `init`, a ViewModel começa a coletar
 *     o `state` exposto pelo [FlowEngine]. Qualquer nova emissão de estado pelo motor
 *     é imediatamente refletida no `uiState`.
 *
 * 3.  **Exposição de Estado:** O estado coletado é exposto para a UI através do `uiState`,
 *     um `StateFlow` que a `FlowActivity` observa para redesenhar a tela.
 *
 * 4.  **Delegação de Intenções:** As intenções geradas pela UI são recebidas pelo método
 *     [processIntent] e são simplesmente encaminhadas para o [FlowEngine] para processamento.
 *
 * 5.  **Gerenciamento de Ciclo de Vida:** O método `onCleared` garante que os recursos do
 *     [FlowEngine] (como coroutines) sejam liberados quando a ViewModel é destruída,
 *     evitando vazamentos de memória.
 */
internal class FlowViewModel<S : FlowState, I : FlowIntent>(
    initialState: S
) : ViewModel(), KoinComponent {

    override fun getKoin() = SdkDI.getKoin()

    private val flowEngine: FlowEngine<S, I> by inject()

    private val _uiState = MutableStateFlow(initialState)
    val uiState: StateFlow<S> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            flowEngine.state.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    /**
     * Encaminha uma intenção da UI para o motor de fluxo para ser processada.
     */
    fun processIntent(intent: I) {
        flowEngine.processEvent(intent)
    }

    /**
     * Garante a limpeza dos recursos do motor quando a ViewModel é destruída.
     */
    override fun onCleared() {
        super.onCleared()
        flowEngine.onCleared()
    }
}