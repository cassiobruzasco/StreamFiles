package com.pagonxt.sdk.di

import android.content.Context
import com.pagonxt.sdk.brazil.di.brazilHalModule
import com.pagonxt.sdk.brazil.di.brazilPaymentModule
import com.pagonxt.sdk.brazil.hal.domain.platform.BrPlatformManager
import com.pagonxt.sdk.core.ContentRouter
import com.pagonxt.sdk.core.SdkCountry
import com.pagonxt.sdk.payment.core.contracts.FlowHookRepository
import com.pagonxt.sdk.payment.di.brazilPaymentEngineModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.KoinApplication
import org.koin.dsl.koinApplication

/**
 * Brazil flavor DI entry point.
 *
 * Passes [BrPlatformManager.setupEMVParameters] as [SdkDiCommon.baseModules] `onPlatformBound`
 * callback so EMV parameters are configured automatically once PosDigital connects and the
 * PlatformService is bound — with no module-order fragility.
 */
internal object SdkDI {
    private var koinApp: KoinApplication? = null

    fun getKoin() = koinApp?.koin ?: error("SDK não inicializado!")

    fun init(
        context: Context,
        country: SdkCountry,
        colorOverrides: Map<String, Long>,
        textOverrides: Map<String, String>,
        hookRepository: FlowHookRepository,
        contentRouter: ContentRouter,
    ) {
        if (koinApp == null) {
            koinApp = koinApplication {
                androidContext(context)

                val allModules = SdkDiCommon.baseModules(
                    context = context,
                    country = country,
                    colorOverrides = colorOverrides,
                    textOverrides = textOverrides,
                    hookRepository = hookRepository,
                    contentRouter = contentRouter,
                    onPlatformBound = { koin.get<BrPlatformManager>().setupEMVParameters() },
                ) + listOf(
                    brazilHalModule,
                    brazilPaymentModule,
                    brazilPaymentEngineModule,
                )

                modules(allModules)
            }
        }
    }
}
