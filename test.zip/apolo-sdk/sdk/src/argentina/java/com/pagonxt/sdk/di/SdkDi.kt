package com.pagonxt.sdk.di

import android.content.Context
import com.pagonxt.sdk.core.ContentRouter
import com.pagonxt.sdk.core.SdkCountry
import com.pagonxt.sdk.payment.core.contracts.FlowHookRepository
import com.pagonxt.sdk.payment.di.argentinaPaymentModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.KoinApplication
import org.koin.dsl.koinApplication

/**
 * Argentina flavor DI entry point.
 *
 * This file is only compiled into the argentina variant, so it can safely reference
 * argentina-only modules.
 */
internal object SdkDI {
    private var koinApp: KoinApplication? = null

    fun getKoin() = koinApp?.koin ?: error("SDK não inicializado!")

    fun init(
        context: Context,
        country: SdkCountry,
        colorOverrides: Map<String, Long>,
        textOverrides: Map<String, String>,
        hookRepository: FlowHookRepository,
        contentRouter: ContentRouter,
    ) {
        if (koinApp == null) {
            koinApp = koinApplication {
                androidContext(context)
                modules(
                    SdkDiCommon.baseModules(
                        context = context,
                        country = country,
                        colorOverrides = colorOverrides,
                        textOverrides = textOverrides,
                        hookRepository = hookRepository,
                        contentRouter = contentRouter,
                    ) + listOf(
                        argentinaPaymentModule,
                    )
                )
            }
        }
    }
}
