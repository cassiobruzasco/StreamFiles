plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.maven.publish)
}

kotlin {
    jvmToolchain(rootProject.extra["jvmToolchainVersion"] as Int)
}

android {
    namespace = "com.pagonxt.sdk"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        minSdk = 26
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    flavorDimensions += "country"
    productFlavors {
        create("brazil") {
            dimension = "country"
            buildConfigField("String", "SDK_COUNTRY", "\"BRAZIL\"")
        }
        create("argentina") {
            dimension = "country"
            buildConfigField("String", "SDK_COUNTRY", "\"ARGENTINA\"")
        }
    }

    packaging { resources.excludes += "META-INF/*" }

    publishing {
        singleVariant("brazilRelease") {
            withJavadocJar()
        }
        singleVariant("argentinaRelease") {
            withJavadocJar()
        }
    }
}

afterEvaluate {
    publishing {
        publications {
            create<MavenPublication>("brazilRelease") {
                from(components["brazilRelease"])

                groupId = "com.pagonxt.sdk"
                artifactId = "pagonxt-sdk-brazil"
                version = "1.0.0-SNAPSHOT"
            }
            create<MavenPublication>("argentinaRelease") {
                from(components["argentinaRelease"])

                groupId = "com.pagonxt.sdk"
                artifactId = "pagonxt-sdk-argentina"
                version = "1.0.0-SNAPSHOT"
            }
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.runtime)
    api(project(":sdk:core"))
    implementation(project(":sdk:hal:middleware"))
    implementation(project(":sdk:uxal:ui-common"))

    // Brazil flavor deps
    add("brazilImplementation", project(":sdk:brazil"))
    add("brazilApi", project(":sdk:uxal:brazil"))

    // Argentina flavor deps
    add("argentinaApi", project(":sdk:uxal:argentina"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.material)
    implementation(libs.kotlinx.coroutines.core)
    implementation(platform(libs.koin.bom))
    implementation(libs.koin.android)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}