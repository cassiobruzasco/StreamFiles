package com.pagonxt.sdk.hal.middleware.domain.emv

import android.content.Context
import android.graphics.Point
import android.util.Log
import com.getnet.posdigital.PosDigital
import com.google.gson.Gson
import com.pagonxt.hal.emvKernel.ButtonPos
import com.pagonxt.hal.emvKernel.Candidate
import com.pagonxt.hal.emvKernel.CardData
import com.pagonxt.hal.emvKernel.CardType
import com.pagonxt.hal.emvKernel.Errors
import com.pagonxt.hal.emvKernel.Host
import com.pagonxt.hal.emvKernel.Message
import com.pagonxt.hal.emvKernel.ProcessData
import com.pagonxt.hal.emvKernel.ProcessResult
import com.pagonxt.hal.emvKernel.ResultData
import com.pagonxt.hal.emvService.IOnCardCallback
import com.pagonxt.hal.emvService.IOnDrawPinCallback
import com.pagonxt.hal.emvService.IOnProcessedCallback
import com.pagonxt.hal.emvService.IOnSelectCallback
import com.pagonxt.hal.utils.byteArray.toHex
import com.pagonxt.hal.utils.byteArray.toHexByteArray
import com.pagonxt.hal.utils.byteArray.toInt
import com.pagonxt.hal.utils.tlv.toByteArray
import com.pagonxt.sdk.hal.middleware.domain.enum.StatusChipEnum
import com.pagonxt.sdk.hal.middleware.domain.enum.TagChipValueEnum
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager
import com.pagonxt.sdk.hal.middleware.domain.utils.TransactionUtils.parseEMVTAGS
import java.util.Locale

class BCGlobal(
    private val platformManager: PlatformManager,
    private val context: Context
) {
    companion object {
        private val TAG = BCGlobal::class.java.simpleName
    }

    private var cardDataResult: CardData? = null
    private var processResult: ProcessResult? = null
    private var finishCallback: IOnProcessedCallback? = null
    private var onSelectCallback: IOnSelectCallback? = null
    private var aidCandidates: MutableList<Candidate>? = null
    private var resultData: ResultData? = null
    private var isContactless: Boolean = false
    private var isChip: Boolean = false
    private var statusChip: StatusChipEnum = StatusChipEnum.CHIP_NEVER_INSERTED
    private var isMagStripe: Boolean = false
    private var retryTransactionCalled: Boolean = false
    private var retryTransaction: () -> Unit? = { null }
    private var isCancelCalled: Boolean = false
    private var onRemovedMessage: String? = null


    fun setRetryTransaction(retryTransaction: () -> Unit) {
        this.retryTransaction = retryTransaction
        retryTransactionCalled = false
    }

    fun onProcess() {
        Log.d(TAG, "onProcess")
    }

    fun onMessage(message: Message?) {
        Log.d(TAG, "onMessage: ${message?.javaClass?.simpleName}")
        // TODO: Implementar o método para chamar o sendMessage de acordo com a subclasse de Message recebida
    }

    fun onDetect(contact: Boolean, contactless: Boolean, tap: Boolean) {
        Log.d(TAG, "onDetect: contact=$contact, contactless=$contactless, tap=$tap")
    }

    fun onDrawPin(drawPinCallback: IOnDrawPinCallback?) {
        Log.d(TAG, "onDrawPin: $drawPinCallback")

        val sp = context.getSharedPreferences("", Context.MODE_PRIVATE)

        val list: List<ButtonPos> =
            ButtonPos.Function.entries.mapIndexedNotNull { index, keyFunction ->
                val value = sp.getString("btn$index", null)
                if (!value.isNullOrEmpty()) {
                    val strSplit = value.split("#")
                    if (strSplit.size >= 4) {
                        val coordinates = strSplit.take(4).mapNotNull { it.toIntOrNull() }
                        if (coordinates.size == 4) {
                            val (x1, y1, x2, y2) = coordinates
                            return@mapIndexedNotNull ButtonPos(
                                Point(x1, y1),
                                Point(x2, y2),
                                keyFunction
                            )
                        }
                    }
                }
                null
            }

        drawPinCallback?.drawPin(false, list)
    }

    fun onSelect(
        candidates: MutableList<Candidate>?,
        contactless: Boolean,
        select: IOnSelectCallback?
    ) {
        onSelectCallback = select
        aidCandidates = candidates

        if (!candidates.isNullOrEmpty() && select != null) {
            onSelectSuccess(candidates, select)
        } else {
            onSelectError(isCallbackError = select == null)
        }
    }

    fun onCard(cardData: CardData?, process: IOnCardCallback?) {
        Log.d(TAG, "onCard: ${Gson().toJson(cardData)}")
        when {
            cardData == null -> return
            cardData.track1.isNullOrEmpty() && cardData.track2.isNullOrEmpty() -> onCardTrackError()
            cardData.aid.isNullOrEmpty() -> onCardAIDError()
            process == null -> onCardProcessCallbackError()
            else -> onCardSuccess(cardData, process)
        }
    }

    fun onProcessed(result: ProcessResult?, finish: IOnProcessedCallback?) {
        Log.d(TAG, "onProcessed: ${Gson().toJson(result)}")
        result?.let { resultData ->
            onProcessedSuccess(resultData, finish)
        } ?: run {
            Log.d(TAG, "onProcessed: ProcessResult is null")
        }
    }

    fun onShowPinEntry(numDigits: Int) {
        Log.d(TAG, "onShowPinEntry: numDigits:$numDigits")
    }

    fun onFinish(data: ResultData?) {
        Log.d(TAG, "onFinish: $data")
        resultData = data
    }

    fun onRemove(contactless: Boolean) {
        Log.d(TAG, "onRemove: contactless:$contactless")
    }

    fun onRemoved() {
        Log.d(TAG, "onRemoved")
        if (isChip) {
            statusChip = StatusChipEnum.CHIP_REMOVED
        }
    }

    fun onEnd() {
        Log.d(TAG, "onEnd")
    }

    fun onPanic(data: String?) {
        Log.d(TAG, "onPanic: $data")
    }

    fun onPinSuccess(pinBlock: String, ksn: String) {
        Log.d(TAG, "onPinSuccess: pinBlock: ${pinBlock}, ksn: $ksn")
        // TODO: Verificar necessidade de chamar o método changeContent quando o onDrawPin for implementado
        // changeContent(null)

        pinBlock
        ksn
    }

    fun onError(error: Errors?) {
        Log.d(TAG, "onError: $error.")
    }

    private fun onCardSuccess(
        data: CardData,
        onCardCallback: IOnCardCallback
    ) {
        Log.d(TAG, "onCardSuccess: aid ${data.aid.orEmpty()}")
        cardDataResult = data
        isContactless = data.type == CardType.Contactless
        isChip = data.type == CardType.Contact
        isMagStripe = data.type == CardType.Magnetic

        when (data.type) {
            CardType.ContactlessMag -> return
            CardType.Magnetic -> return
            else -> continueToOnCardProcess(data, onCardCallback)
        }
    }

    private fun continueToOnCardProcess(
        cardData: CardData,
        onCardCallback: IOnCardCallback
    ) {
        platformManager.setRiskManagement(aidSelected = cardData.aid.orEmpty())
        if (isContactless)
            PosDigital.getInstance().getBeeper().success()

        // TODO: will be remove from here
        // TODO: need to use getDUKPTPosition from each country
        val dukptKeySlot = platformManager.getDUKPTPosition(3,2)
        when {
            else -> onCardCallback.process(
                ProcessData(
                    panInBlackList = false,
                    requested = getTagsFromAid(aid = cardData.aid.orEmpty()),
                    dukptKeySlot = dukptKeySlot,
                    tlvs = null
                )
            )
        }
    }

    private fun onCardTrackError() {
        Log.d(TAG, "onCardTrackError: track 1 or track 2 is null or empty.")
    }

    private fun onCardAIDError() {
        Log.d(TAG, "onCardAIDError: AID is null.")
    }

    private fun onCardProcessCallbackError() {
        Log.d(TAG, "onCardProcessCallbackError: process callback is null.")
    }

    private fun onProcessedSuccess(
        resultData: ProcessResult,
        finish: IOnProcessedCallback?
    ) {
        processResult = resultData
        finishCallback = finish
        runSecondAnalysis(
            arc = "",
            connected = true,
            shouldCallFinish = true
        )
    }

    private fun onErrorFallback(error: Errors?) {
        when (error) {
            Errors.CARDAPPNAV -> chipInsertedFallback()
            Errors.CTLSFALLBACK -> return
            else -> return
        }
    }

    private fun onSelectSuccess(
        candidates: MutableList<Candidate>,
        onSelectCallback: IOnSelectCallback
    ) {
        when {
            candidates.size == 1 -> {
                Log.d(TAG, "onSelectSuccess: candidate: ${candidates.first().name}.")
                onSelectCallback.select(candidates.first())
            }

            else -> {
                val candidateLabels = candidates.mapIndexed { index, candidate ->
                    String.format(
                        Locale.ENGLISH,
                        "%02d-",
                        index + 1
                    ) + candidate.name
                }
                Log.d(TAG, "onSelectSuccess: candidates: ${candidateLabels.joinToString(" / ")}.")
            }
        }
    }

    private fun onSelectError(isCallbackError: Boolean) {
        if (isCallbackError) {
            Log.d(TAG, "onSelectError: onSelectCallback is null.")
        } else {
            Log.d(TAG, "onSelectError: candidates is null or empty.")
        }
    }

    /**
     * CardReader necessities below
     */

    fun setCancelCalled() {
        isCancelCalled = true
    }

    fun getCardData(): CardData? = cardDataResult

    fun getTrack1(): String = cardDataResult?.track1.orEmpty()

    fun getTrack2(): String = cardDataResult?.track2.orEmpty()

    fun getTrack3(): String = cardDataResult?.track3.orEmpty()

    fun getLabelName(): String = cardDataResult?.labelName.orEmpty()

    fun getCardHolderName(): String = cardDataResult?.cardholderName.orEmpty()

    fun getIsContactless(): Boolean = isContactless

    fun getIsChip(): Boolean = isChip

    fun getIsMagStripe(): Boolean = isMagStripe

    fun isChipInserted(): Boolean = statusChip == StatusChipEnum.CHIP_INSERTED

    fun isChipRemoved(): Boolean = statusChip == StatusChipEnum.CHIP_REMOVED

    private fun chipInsertedFallback() {
        statusChip = StatusChipEnum.CHIP_INSERTED
    }

    fun setOnRemovedMessage(message: String?) {
        onRemovedMessage = message
    }

    fun runSecondAnalysis(
        arc: String?,
        connected: Boolean,
        shouldCallFinish: Boolean
    ): String {
        if (shouldCallFinish) {
            Log.d(TAG, "runSecondAnalysis: call finish")
            finishCallback?.finish(
                Host(
                    communicationOK = connected,
                    responseCode = arc,
                    authorizationCode = arc,
                    data = processResult?.tlvs,
                    requested = processResult?.tlvs?.map { it.tag.toHex() }
                )
            )
        }
        return resultData?.issuerScriptResult.let {
            Log.d(TAG, "runSecondAnalysis: issuerScriptResult is $it")
            it
        } ?: run {
            Log.d(TAG, "runSecondAnalysis: resultData is null")
            ""
        }
    }

    fun isOfflineDeclined(): Boolean {
        return if (isChip) resultData?.let { !it.approved } ?: false
        else false
    }

    fun onReselection(selected: Int): Int {
        val selectedCandidate = aidCandidates?.get(selected - 1) ?: run {
            onSelectError(isCallbackError = false)
            return selected
        }
        Log.d(TAG, "onReselection: candidate: ${selectedCandidate.name}.")
        onSelectCallback?.select(selectedCandidate) ?: onSelectError(isCallbackError = true)
        return selected
    }

    fun getTagsFromChip(): String {
        return processResult?.let {
            Log.d(TAG, "getTagsFromChip: ${it.tlvs.toByteArray().toHex()}")
            it.tlvs.toByteArray().toHex()
        } ?: run {
            Log.d(TAG, "getTagsFromChip: processResult is null")
            ""
        }
    }

    fun getTagValueFromChip(tag: Int): ByteArray? {
        return when (tag) {
            TagChipValueEnum.TAG_5F34.tag, TagChipValueEnum.TAG_9F26.tag -> findTagValue(tag)
            TagChipValueEnum.TAG_57.tag -> cardDataResult?.track2?.toHexByteArray()
            else -> ByteArray(0)
        }
    }

    fun getIssuerCountryCode(defaultCountry: String) =
        cardDataResult?.issuerCountryCode?.padStart(3, '0') ?: defaultCountry

    fun runFlow() {

        if (isChip)
            statusChip = StatusChipEnum.CHIP_INSERTED
    }

    private fun getTagsFromAid(aid: String): List<String> =
        // TODO: Implement method to get tags from AID, for now it returns an empty list
        parseEMVTAGS(
            ""
        ).map {
            it.toString(16).uppercase()
        }

    private fun findTagValue(tag: Int): ByteArray =
        processResult?.tlvs?.find { it.tag.toInt() == tag }?.value ?: ByteArray(0)
}
