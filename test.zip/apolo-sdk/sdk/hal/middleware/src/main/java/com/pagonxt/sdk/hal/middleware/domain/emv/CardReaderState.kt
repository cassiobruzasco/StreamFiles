package com.pagonxt.sdk.hal.middleware.domain.emv

import com.pagonxt.sdk.hal.middleware.domain.enum.ErrorsEnum
import com.pagonxt.sdk.hal.middleware.domain.model.CardDataModel
import com.pagonxt.sdk.hal.middleware.domain.model.ProcessResultModel
import com.pagonxt.sdk.hal.middleware.domain.model.ResultDataModel

// TODO: verify if this states is enough
sealed class CardReaderState {
    data object OnProcess : CardReaderState()
    data object OnDetect : CardReaderState()
    data class OnSuccess(
        val cardData: CardDataModel?,
        val processResult: ProcessResultModel?,
        val resultData: ResultDataModel?
    ) : CardReaderState()
    data object OnRemoved : CardReaderState()
    data object OnPanic : CardReaderState()
    data class OnPinSuccess(val pinBlock: String, val ksn: String) : CardReaderState()
    data class OnError(val error: ErrorsEnum?) : CardReaderState()
}