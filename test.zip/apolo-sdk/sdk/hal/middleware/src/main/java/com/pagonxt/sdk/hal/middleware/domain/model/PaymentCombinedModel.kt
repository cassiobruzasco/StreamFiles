package com.pagonxt.sdk.hal.middleware.domain.model

data class PaymentCombinedModel(
    val sellerId: String?,
    val requestId: String?,
    val orderId: String?,
    val amount: String?,
    val combinedId: String?,
    val payments: List<PaymentCombinedItemModel>?,
)

data class PaymentCombinedItemModel(
    val idempotencyKey: String?,
    val paymentId: String?,
    val status: String?,
    val paymentMethod: String?,
    val receivedAt: String?,
    val transactionId: String?,
    val originalTransactionId: String?,
    val authorizedAt: String?,
    val reasonCode: String?,
    val reasonMessage: String?,
    val acquirer: String?,
    val softDescriptor: String?,
    val brand: String?,
    val authorizationCode: String?,
    val acquirerTransactionId: String?,
    val eci: String?,
    val paymentReceivedTimestamp: String?,
    val cardId: String?,
    val merchantAdviceCode: String?,
    val amount: String?
)

data class PaymentCombinedErrorModel(
    val message: String?,
    val name: String?,
    val statusCode: Int?,
    val details: List<PaymentCombinedErrorDetailModel>?
)

data class PaymentCombinedErrorDetailModel(
    val status: String?,
    val errorCode: String?,
    val description: String?,
    val descriptionDetail: String?
)
