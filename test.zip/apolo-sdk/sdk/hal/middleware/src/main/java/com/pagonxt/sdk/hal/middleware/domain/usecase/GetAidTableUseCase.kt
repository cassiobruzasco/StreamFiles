package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.pagonxt.sdk.hal.middleware.domain.mapper.AidTableMapper
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel
import com.pagonxt.sdk.hal.middleware.domain.repository.TransactionRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class GetAidTableUseCase(
    private val repository: TransactionRepository,
    private val mapper: AidTableMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke() = flow {
        try {
            repository.getAidTable().let { response ->
                when (response.code()) {
                    200 -> {
                        response.body()?.let { body ->
                            emit(AidTableState.Success(mapper.getAidTable(body)))
                        } ?: run {
                            emit(AidTableState.Error("AidTable empty response body"))
                        }
                    }

                    else -> {
                        emit(AidTableState.Error("Error ${response.code()}: ${response.message()}"))
                    }
                }
            }
        } catch (e: Exception) {
            emit(AidTableState.Error(e.message ?: "Unknown Error"))
        }
    }.onStart {
        emit(AidTableState.Loading)
    }.flowOn(coroutineContext)
}

sealed class AidTableState {
    data object Loading : AidTableState()
    data class Success(val data: List<AidTableModel>) : AidTableState()
    data class Error(val message: String) : AidTableState()
}