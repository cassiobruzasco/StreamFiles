package com.pagonxt.sdk.hal.middleware.domain.constant

internal object PlatformManagerConst {
    const val BIND_PLATFORM_ATTEMPTS = 10
    const val BIND_PLATFORM_DELAY_DURATION = 1000L
}