package com.pagonxt.sdk.hal.middleware.domain.extension

import com.pagonxt.hal.emvKernel.CAKey
import com.pagonxt.sdk.hal.middleware.domain.model.PublicKeyTableModel

internal fun PublicKeyTableModel.toCAKey(): CAKey {
    return CAKey(
        rid = rid.uppercase(),
        index = index,
        module = module,
        exponent = exponentFormatted()
    )
}

/** This function formats the exponent value according to the TAMEXP field. */
internal fun PublicKeyTableModel.exponentFormatted(): String {
    val expByteLength = tamExponent.toInt()
    val expNormalized = exponent.replace(" ", "").uppercase()

    /** Each byte is represented by 2 hexadecimal digits. **/
    val bytes = expNormalized.chunked(2)
    /** Retrieves bytes according to the given size and creates a string. **/
    return bytes.take(expByteLength).joinToString("")
}
