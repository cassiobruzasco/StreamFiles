package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.sdk.hal.middleware.data.response.TerminalTableResponse
import com.pagonxt.sdk.hal.middleware.domain.model.TerminalTableModel

internal class TerminalTableMapper {
    fun getTerminalTable(response: TerminalTableResponse): TerminalTableModel =
        TerminalTableModel(
            version = response.version,
            establishment = response.establishment,
            cnpj = response.cnpj,
            technicianPassword = response.technicianPassword,
            crypto = response.crypto,
            workingKey = response.workingKey,
            masterKeyIndex = response.masterKeyIndex,
            smid = response.smid,
            nii = response.nii,
            profile = response.profile,
            tamHeader = response.tamHeader,
            header = response.header,
            tamCorporateName = response.tamCorporateName,
            corporateName = response.corporateName,
            tamMerchantCity = response.tamMerchantCity,
            merchantCity = response.merchantCity,
            tamMerchantName = response.tamMerchantName,
            merchantName = response.merchantName,
            countryCode = response.countryCode,
            timeZone = response.timeZone,
            timeZoneSignal = response.timeZoneSignal,
            summerTimeDifference = response.summerTimeDifference,
            summerTimeStart = response.summerTimeStart,
            summerTimeEnd = response.summerTimeEnd,
            option1 = response.option1,
            option2 = response.option2,
            dukptIndex = response.dukptIndex,
            configNii = response.configNii,
            qrcodeTimeout = response.qrcodeTimeout,
            qrcodeNii = response.qrcodeNii,
            merchantCategoryCode = response.merchantCategoryCode,
            pixTimeout = response.pixTimeout,
            pixNii = response.pixNii
        )
}