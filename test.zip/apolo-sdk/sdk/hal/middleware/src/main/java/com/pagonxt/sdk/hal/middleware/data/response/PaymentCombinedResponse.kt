package com.pagonxt.sdk.hal.middleware.data.response

import com.google.gson.annotations.SerializedName

data class PaymentCombinedResponse(
    @SerializedName("seller_id") val sellerId: String?,
    @SerializedName("request_id") val requestId: String?,
    @SerializedName("order_id") val orderId: String?,
    @SerializedName("amount") val amount: String?,
    @SerializedName("combined_id") val combinedId: String?,
    @SerializedName("payments") val payments: List<PaymentCombinedItemResponse>?,

    // Parameters below are present only in case of error
    @SerializedName("message") val message: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("statusCode") val statusCode: Int?,
    @SerializedName("details") val details: List<PaymentCombinedErrorDetail>?
)

data class PaymentCombinedItemResponse(
    @SerializedName("idempotency_key") val idempotencyKey: String?,
    @SerializedName("payment_id") val paymentId: String?,
    @SerializedName("status") val status: String?,
    @SerializedName("payment_method") val paymentMethod: String?,
    @SerializedName("received_at") val receivedAt: String?,
    @SerializedName("transaction_id") val transactionId: String?,
    @SerializedName("original_transaction_id") val originalTransactionId: String?,
    @SerializedName("authorized_at") val authorizedAt: String?,
    @SerializedName("reason_code") val reasonCode: String?,
    @SerializedName("reason_message") val reasonMessage: String?,
    @SerializedName("acquirer") val acquirer: String?,
    @SerializedName("soft_descriptor") val softDescriptor: String?,
    @SerializedName("brand") val brand: String?,
    @SerializedName("authorization_code") val authorizationCode: String?,
    @SerializedName("acquirer_transaction_id") val acquirerTransactionId: String?,
    @SerializedName("eci") val eci: String?,
    @SerializedName("payment_received_timestamp") val paymentReceivedTimestamp: String?,
    @SerializedName("card_id") val cardId: String?,
    @SerializedName("merchant_advice_code") val merchantAdviceCode: String?,
    @SerializedName("amount") val amount: String?
)

data class PaymentCombinedErrorDetail(
    @SerializedName("status") val status: String?,
    @SerializedName("error_code") val errorCode: String?,
    @SerializedName("description") val description: String?,
    @SerializedName("description_detail") val descriptionDetail: String?
)