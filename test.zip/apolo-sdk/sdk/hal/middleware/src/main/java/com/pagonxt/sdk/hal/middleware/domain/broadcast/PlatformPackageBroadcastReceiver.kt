package com.pagonxt.sdk.hal.middleware.domain.broadcast

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import androidx.core.content.edit
import com.pagonxt.sdk.hal.middleware.domain.constant.PackageManagerConst.PLATFORM_PACKAGE_NAME

internal class PlatformPackageBroadcastReceiver(
    private val sharedPreferences: SharedPreferences
) : BroadcastReceiver() {
    companion object {
        private const val PLATFORM_HAS_CHANGED = "PLATFORM_HAS_CHANGED"
        private const val PLATFORM_HAS_REGISTER = "PLATFORM_HAS_REGISTER"
        private val TAG = PlatformPackageBroadcastReceiver::class.simpleName
    }

    fun hasPlatformChanged(): Boolean =
        sharedPreferences.getBoolean(PLATFORM_HAS_CHANGED, false)

    fun resetPlatformFlag() =
        sharedPreferences.edit { putBoolean(PLATFORM_HAS_CHANGED, false) }

    override fun onReceive(context: Context, intent: Intent) {
        val packageName = intent.data?.schemeSpecificPart
        if (getIntentFilter().hasAction(intent.action) && packageName == PLATFORM_PACKAGE_NAME) {
            Log.d(TAG, "Platform package changed: $packageName, action: ${intent.action}.")
            sharedPreferences.edit { putBoolean(PLATFORM_HAS_CHANGED, true) }
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun registerReceiver(context: Context) {
        if (!sharedPreferences.getBoolean(PLATFORM_HAS_REGISTER, false)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(this, getIntentFilter(), Context.RECEIVER_NOT_EXPORTED)
            } else {
                context.registerReceiver(this, getIntentFilter())
            }
            sharedPreferences.edit { putBoolean(PLATFORM_HAS_REGISTER, true) }
        }
    }

    fun unregisterReceiver(context: Context) {
        if (sharedPreferences.getBoolean(PLATFORM_HAS_REGISTER, false)) {
            try {
                context.unregisterReceiver(this)
            } catch (e: IllegalArgumentException) {
                Log.d(TAG, "Receiver was not registered: ${e.message}.")
            }
            sharedPreferences.edit { putBoolean(PLATFORM_HAS_REGISTER, false) }
        }
    }

    private fun getIntentFilter(): IntentFilter = IntentFilter().apply {
        addAction(Intent.ACTION_PACKAGE_REMOVED)
        addAction(Intent.ACTION_PACKAGE_REPLACED)
        addAction(Intent.ACTION_PACKAGE_RESTARTED)
        addDataScheme("package")
    }
}