package com.pagonxt.sdk.hal.middleware.domain.repository

import com.pagonxt.sdk.hal.middleware.data.repository.SdkInfoRepositoryState
import com.pagonxt.sdk.hal.middleware.data.repository.SdkRepositoryState

interface SdkRepository {
    suspend fun connect(): SdkRepositoryState
    suspend fun disconnect(): SdkRepositoryState
    suspend fun info(): SdkInfoRepositoryState
}