package com.pagonxt.sdk.hal.middleware.domain.model

data class PublicKeyTableModel(
    val rid: String,
    val index: String,
    val tamExponent: String,
    val exponent: String,
    val tamModule: String,
    val module: String,
    val checkSum: String
)