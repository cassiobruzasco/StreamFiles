package com.pagonxt.sdk.hal.middleware.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.pagonxt.sdk.hal.middleware.R
import com.pagonxt.sdk.hal.middleware.data.constant.SharedPreferencesConst.AUTH_TOKEN
import com.pagonxt.sdk.hal.middleware.data.remote.ApiService
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.PaymentRequestBody
import com.pagonxt.sdk.hal.middleware.data.response.AidTableResponse
import com.pagonxt.sdk.hal.middleware.data.response.AuthResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentResponse
import com.pagonxt.sdk.hal.middleware.data.response.PublicKeyTableResponse
import com.pagonxt.sdk.hal.middleware.data.response.TerminalTableResponse
import com.pagonxt.sdk.hal.middleware.domain.repository.SEPRepository
import com.pagonxt.sdk.hal.middleware.domain.repository.TransactionRepository
import okhttp3.ResponseBody.Companion.toResponseBody
import retrofit2.Response

internal class RepositoryImpl(
    private val apiService: ApiService,
    private val context: Context,
    private val sharedPreferences: SharedPreferences
) : TransactionRepository, SEPRepository {
    // TODO: consume correct APIs when available
    override suspend fun getAidTable(): Response<List<AidTableResponse>> {
        return try {
            val inputStream = context.resources.openRawResource(
                R.raw.aid_table
            )
            val json = inputStream.bufferedReader().use { it.readText() }
            val aidTableResponseList =
                Gson().fromJson(json, Array<AidTableResponse>::class.java).toList()
            Response.success(aidTableResponseList)
        } catch (e: Exception) {
            Response.error(
                500,
                (e.message ?: "Error reading aid_table.json")
                    .toResponseBody((null as okhttp3.MediaType?))
            )
        }
    }

    // TODO: consume correct APIs when available
    override suspend fun getPublicKeyTable(): Response<List<PublicKeyTableResponse>> {
        return try {
            val inputStream = context.resources.openRawResource(
                R.raw.ca_keys_table
            )
            val json = inputStream.bufferedReader().use { it.readText() }
            val publicKeyResponseList =
                Gson().fromJson(json, Array<PublicKeyTableResponse>::class.java).toList()
            Response.success(publicKeyResponseList)
        } catch (e: Exception) {
            Response.error(
                500,
                (e.message ?: "Error reading ca_keys_table.json")
                    .toResponseBody((null as okhttp3.MediaType?))
            )
        }
    }

    // TODO: consume correct APIs when available
    override suspend fun getTerminalTable(): Response<TerminalTableResponse> {
        return try {
            val inputStream = context.resources.openRawResource(
                R.raw.terminal_table
            )
            val json = inputStream.bufferedReader().use { it.readText() }
            val terminalResponse = Gson().fromJson(json, TerminalTableResponse::class.java)
            Response.success(terminalResponse)
        } catch (e: Exception) {
            Response.error(
                500,
                (e.message ?: "Error reading ca_keys_table.json")
                    .toResponseBody((null as okhttp3.MediaType?))
            )
        }
    }

    override suspend fun postGenerateToken(): Response<AuthResponse> =
        apiService.postGenerateToken()

    override suspend fun postPaymentCombined(
        requestBody: PaymentCombinedRequestBody
    ): Response<PaymentCombinedResponse> =
        // TODO: verify where get sellerId, authorization, country and tenant
        apiService.postPaymentCombined(
            sellerId = "21c417b3-80b5-43de-88f6-ed280f986ad2",
            authorization = sharedPreferences.getString(AUTH_TOKEN, "") ?: "",
            country = "br",
            tenant = "b",
            requestBody = requestBody
        )

    override suspend fun postPayment(requestBody: PaymentRequestBody): Response<PaymentResponse> =
        apiService.postPayment(
            authorization = sharedPreferences.getString(AUTH_TOKEN, "") ?: "",
            requestBody = requestBody
        )
}