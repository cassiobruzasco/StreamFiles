package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedErrorDetail
import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedItemResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedResponse
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedErrorDetailModel
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedErrorModel
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedItemModel
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedModel

class PaymentCombinedMapper {
    internal fun getPaymentCombinedModel(response: PaymentCombinedResponse): PaymentCombinedModel =
        PaymentCombinedModel(
            sellerId = response.sellerId,
            requestId = response.requestId,
            orderId = response.orderId,
            amount = response.amount,
            combinedId = response.combinedId,
            payments = response.payments?.map { getPaymentCombinedItemModel(it) }
        )

    internal fun getPaymentCombinedErrorModel(response: PaymentCombinedResponse): PaymentCombinedErrorModel =
        PaymentCombinedErrorModel(
            message = response.message,
            name = response.name,
            statusCode = response.statusCode,
            details = response.details?.map { getPaymentCombinedErrorDetailModel(it) }
        )

    private fun getPaymentCombinedItemModel(item: PaymentCombinedItemResponse): PaymentCombinedItemModel =
        PaymentCombinedItemModel(
            idempotencyKey = item.idempotencyKey,
            paymentId = item.paymentId,
            status = item.status,
            paymentMethod = item.paymentMethod,
            receivedAt = item.receivedAt,
            transactionId = item.transactionId,
            originalTransactionId = item.originalTransactionId,
            authorizedAt = item.authorizedAt,
            reasonCode = item.reasonCode,
            reasonMessage = item.reasonMessage,
            acquirer = item.acquirer,
            softDescriptor = item.softDescriptor,
            brand = item.brand,
            authorizationCode = item.authorizationCode,
            acquirerTransactionId = item.acquirerTransactionId,
            eci = item.eci,
            paymentReceivedTimestamp = item.paymentReceivedTimestamp,
            cardId = item.cardId,
            merchantAdviceCode = item.merchantAdviceCode,
            amount = item.amount
        )

    private fun getPaymentCombinedErrorDetailModel(detail: PaymentCombinedErrorDetail): PaymentCombinedErrorDetailModel =
        PaymentCombinedErrorDetailModel(
            status = detail.status,
            errorCode = detail.errorCode,
            description = detail.description,
            descriptionDetail = detail.descriptionDetail
        )
}
