package com.pagonxt.sdk.hal.middleware.data.response

import com.google.gson.annotations.SerializedName

data class PublicKeyTableResponse(
    @SerializedName("RID") val rid: String,
    @SerializedName("CAPK_IDX") val index: String,
    @SerializedName("TAM_EXP") val tamExponent: String,
    @SerializedName("EXP") val exponent: String,
    @SerializedName("TAM_MOD") val tamModule: String,
    @SerializedName("MOD") val module: String,
    @SerializedName("CHECKSUM") val checkSum: String
)