package com.pagonxt.sdk.hal.middleware.data.constant

internal object NamedQualifierConst {
    const val DUMMY_API_NAMED = "dummyRetrofit"
    const val OTHER_API_NAMED = "otherRetrofit"
    const val DUMMY_API_NAMED_QUALIFIER = "dummyApiService"
    const val OTHER_API_NAMED_QUALIFIER = "otherApiService"
}