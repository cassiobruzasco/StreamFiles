package com.pagonxt.sdk.hal.middleware.domain.mapper

import android.content.SharedPreferences
import androidx.core.content.edit
import com.pagonxt.sdk.hal.middleware.data.constant.SharedPreferencesConst.AUTH_TOKEN
import com.pagonxt.sdk.hal.middleware.data.response.AuthResponse
import com.pagonxt.sdk.hal.middleware.domain.model.AuthModel

class AuthMapper(private val sharedPreferences: SharedPreferences) {
    internal fun getAuthModel(response: AuthResponse): AuthModel {
        "${response.tokenType} ${response.accessToken}".let { authorization ->
            sharedPreferences.edit {
                putString(AUTH_TOKEN, authorization)
            }
            return AuthModel(
                authorization = authorization,
                scope = response.scope,
                expiresIn = response.expiresIn
            )

        }
    }
}