package com.pagonxt.sdk.hal.middleware.domain.extension

import com.pagonxt.hal.emvKernel.Terminal
import com.pagonxt.sdk.hal.middleware.domain.model.TerminalTableModel

internal fun TerminalTableModel.toTerminal(): Terminal {
    return Terminal(
        countyCode = countryCode,
        merchantIdentifier = establishment,
        merchantCategoryCode = merchantCategoryCode,
        terminalIdentifier = "12345678",
        terminalType = "22",
        terminalCapabilities = "TERMINAL_CAPABILITIES",
        terminalAdditionalCapabilities = "TERMINAL_ADDITIONAL_CAPABILITIES"
    )
}