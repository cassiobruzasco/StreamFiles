package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.sdk.hal.middleware.data.response.PublicKeyTableResponse
import com.pagonxt.sdk.hal.middleware.domain.model.PublicKeyTableModel

internal class PublicKeyTableMapper {
    fun getPublicKey(response: List<PublicKeyTableResponse>): List<PublicKeyTableModel> =
        response.map {
            PublicKeyTableModel(
                rid = it.rid,
                index = it.index,
                module = it.module,
                tamModule = it.tamModule,
                exponent = it.exponent,
                tamExponent = it.tamExponent,
                checkSum = it.checkSum
            )
        }
}