package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.getnet.posdigital.PosDigital
import com.getnet.posdigital.info.InfoResponse
import com.pagonxt.sdk.hal.middleware.data.repository.SdkInfoRepositoryState
import com.pagonxt.sdk.hal.middleware.data.repository.SdkRepositoryState
import com.pagonxt.sdk.hal.middleware.domain.repository.SdkRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

class GetSdkUseCase (
    private val repository: SdkRepository,
    private val coroutineContext: CoroutineContext
) {
    fun connectSdk() = flow {
        try {
            repository.connect().let {
                when (it) {
                    SdkRepositoryState.OnConnected -> emit(GetSdkUseCaseState.OnConnected)

                    SdkRepositoryState.OnDisconnected -> emit(GetSdkUseCaseState.OnDisconnected)

                    is SdkRepositoryState.OnError -> {
                        if (PosDigital.getInstance().isInitiated()) {
                            disconnectSdk()
                        }
                        repository.connect()
                        emit(GetSdkUseCaseState.OnError(it.error))
                    }
                }
            }
        } catch (e: Exception) {
            emit(GetSdkUseCaseState.OnError(e))
        }
    }.onStart {
        GetSdkUseCaseState.Loading
    }.flowOn(coroutineContext)

    fun disconnectSdk() = flow {
        try {
            repository.disconnect().let {
                when (it) {
                    SdkRepositoryState.OnDisconnected -> emit(GetSdkUseCaseState.OnDisconnected)

                    SdkRepositoryState.OnConnected -> emit(GetSdkUseCaseState.OnConnected)

                    is SdkRepositoryState.OnError -> emit(GetSdkUseCaseState.OnError(it.error))
                }
            }
        } catch (e: Exception) {
            emit(GetSdkUseCaseState.OnError(e))
        }
    }.onStart {
        GetSdkUseCaseState.Loading
    }.flowOn(coroutineContext)

    fun getInfoSdk() = flow {
        try {
            repository.info().let {
                when (it) {
                    is SdkInfoRepositoryState.OnInfo -> emit(
                        GetSdkInfoUseCaseState.OnInfo(
                            it.data
                        )
                    )

                    is SdkInfoRepositoryState.OnError -> emit(
                        GetSdkInfoUseCaseState.OnError(
                            it.error
                        )
                    )
                }
            }
        } catch (e: Exception) {
            emit(GetSdkInfoUseCaseState.OnError(e.message))
        }
    }.onStart {
        GetSdkInfoUseCaseState.Loading
    }.flowOn(coroutineContext)
}

sealed class GetSdkUseCaseState {
    data object OnConnected : GetSdkUseCaseState()
    data object OnDisconnected : GetSdkUseCaseState()
    data object Loading : GetSdkUseCaseState()
    data class OnError(val error: Exception?) : GetSdkUseCaseState()
}

sealed class GetSdkInfoUseCaseState {
    data object Loading : GetSdkInfoUseCaseState()
    data class OnInfo(val data: InfoResponse) : GetSdkInfoUseCaseState()
    data class OnError(val error: String?) : GetSdkInfoUseCaseState()
}