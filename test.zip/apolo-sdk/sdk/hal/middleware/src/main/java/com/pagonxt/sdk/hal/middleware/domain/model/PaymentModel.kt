package com.pagonxt.sdk.hal.middleware.domain.model

data class PaymentModel(
    val sellerId: String?,
    val paymentId: String?,
    val orderId: String?,
    val amount: String?,
    val currency: String?,
    val status: String?,
    val paymentMethod: String?,
    val receivedAt: String?,
    val transactionId: String?,
    val originalTransactionId: String?,
    val authorizedAt: String?,
    val reasonCode: String?,
    val reasonMessage: String?,
    val acquirer: String?,
    val softDescriptor: String?,
    val authorizationCode: String?,
    val acquirerTransactionId: String?
)