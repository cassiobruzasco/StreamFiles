package com.pagonxt.sdk.hal.middleware.domain.repository

import com.pagonxt.sdk.hal.middleware.data.response.AidTableResponse
import com.pagonxt.sdk.hal.middleware.data.response.PublicKeyTableResponse
import com.pagonxt.sdk.hal.middleware.data.response.TerminalTableResponse
import retrofit2.Response

interface TransactionRepository {
    suspend fun getAidTable(): Response<List<AidTableResponse>>
    suspend fun getPublicKeyTable(): Response<List<PublicKeyTableResponse>>
    suspend fun getTerminalTable(): Response<TerminalTableResponse>
}