package com.pagonxt.sdk.hal.middleware.domain.enum

internal enum class TagChipValueEnum(val tag: Int) {
    TAG_5F34(0x5F34),
    TAG_9F26(0x9F26),
    TAG_57(0x57);
}