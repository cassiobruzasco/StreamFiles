package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.pagonxt.sdk.hal.middleware.domain.mapper.AuthMapper
import com.pagonxt.sdk.hal.middleware.domain.model.AuthModel
import com.pagonxt.sdk.hal.middleware.domain.repository.SEPRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class PostGenerateTokenUseCase(
    private val repository: SEPRepository,
    private val mapper: AuthMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke() = flow {
        try {
            repository.postGenerateToken().let { response ->
                when (response.code()) {
                    200 -> {
                        response.body()?.let { responseBody ->
                            emit(GenerateTokenState.Success(mapper.getAuthModel(responseBody)))
                        } ?: run {
                            emit(
                                GenerateTokenState.Error(
                                    ErrorOutputDefault(
                                        code = response.code(),
                                        message = "Response body is null",
                                        errorBody = response.errorBody(),
                                        raw = response.raw()
                                    )
                                )
                            )
                        }
                    }

                    else -> {
                        emit(
                            GenerateTokenState.Error(
                                ErrorOutputDefault(
                                    code = response.code(),
                                    message = response.message(),
                                    errorBody = response.errorBody(),
                                    raw = response.raw()
                                )
                            )
                        )
                    }
                }

            }
        } catch (e: Exception) {
            emit(
                GenerateTokenState.Error(
                    ErrorOutputDefault(
                        code = -1,
                        message = e.message ?: "Unknown error",
                        errorBody = null,
                        raw = null
                    )
                )
            )
        }
    }.onStart {
        emit(GenerateTokenState.Loading)
    }.flowOn(coroutineContext)
}

sealed class GenerateTokenState {
    data object Idle : GenerateTokenState()
    data object Loading : GenerateTokenState()
    data class Success(val data: AuthModel) : GenerateTokenState()
    data class Error(val error: ErrorOutputDefault) : GenerateTokenState()
}