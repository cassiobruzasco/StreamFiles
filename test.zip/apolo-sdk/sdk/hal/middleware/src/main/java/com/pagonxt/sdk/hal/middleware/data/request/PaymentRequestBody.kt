package com.pagonxt.sdk.hal.middleware.data.request

import com.google.gson.annotations.SerializedName

data class PaymentRequestBody(
    @SerializedName("idempotency_key") val idempotencyKey: String,
    @SerializedName("request_id") val requestId: String,
    @SerializedName("order_id") val orderId: String,
    @SerializedName("data") val data: PaymentDataRequestBody
)

data class PaymentDataRequestBody(
    @SerializedName("amount") val amount: Int,
    @SerializedName("currency") val currency: String,
    @SerializedName("customer_id") val customerId: String,
    @SerializedName("payment") val payment: PaymentDetailRequestBody
)

data class PaymentDetailRequestBody(
    @SerializedName("payment_id") val paymentId: String,
    @SerializedName("payment_method") val paymentMethod: String,
    @SerializedName("transaction_type") val transactionType: String,
    @SerializedName("number_installments") val numberInstallments: Int,
    @SerializedName("soft_descriptor") val softDescriptor: String,
    @SerializedName("dynamic_mcc") val dynamicMcc: String,
    @SerializedName("card") val card: CardRequestBody
)

data class CardRequestBody(
    @SerializedName("number") val number: String,
    @SerializedName("entry_mode") val entryMode: String,
    @SerializedName("emv") val emv: String,
    @SerializedName("track_2") val track2: String
)