package com.pagonxt.sdk.hal.middleware.domain.enum

internal enum class StatusChipEnum {
    CHIP_INSERTED,
    CHIP_REMOVED,
    CHIP_NEVER_INSERTED;
}
