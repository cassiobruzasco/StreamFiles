package com.pagonxt.sdk.hal.middleware.domain.extension

import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager

fun PlatformManager.runIfIsBound(bound: () -> Unit, notBound: (() -> Unit)? = null) {
    if (this.isBound) bound.invoke() else notBound?.invoke()
}