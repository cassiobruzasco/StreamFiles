package com.pagonxt.sdk.hal.middleware.domain.usecase

import okhttp3.Response
import okhttp3.ResponseBody

data class ErrorOutputDefault(
    val code: Int,
    val message: String,
    val errorBody: ResponseBody?,
    val raw: Response?
)