package com.pagonxt.sdk.hal.middleware.data.remote

import com.pagonxt.sdk.hal.middleware.data.constant.SharedPreferencesConst.AUTH_TOKEN_BASIC
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.PaymentRequestBody
import com.pagonxt.sdk.hal.middleware.data.response.AuthResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Header
import retrofit2.http.POST

internal interface ApiService {
    /**
     * <a href="https://gms-dpm-payments-v2-gwproxy-ms.app.uat.gms.corp/swagger-ui/index.html#">Documentation</a>
     * <a href="https://docs.globalgetnet.com/pt/products/online-payments/regional-api/swagger#tag/payments">Documentation</a>
     */
    @FormUrlEncoded
    @POST("authentication/oauth2/access_token")
    suspend fun postGenerateToken(
        @Header("Authorization") authorization: String = AUTH_TOKEN_BASIC,
        @Field("grant_type") grantType: String = "client_credentials"
    ): Response<AuthResponse>

    @POST("dpm/payments-gwproxy/v2/payments/combined")
    suspend fun postPaymentCombined(
        @Header("x-seller-id") sellerId: String,
        @Header("Authorization") authorization: String,
        @Header("country") country: String,
        @Header("tenant") tenant: String,
        @Body requestBody: PaymentCombinedRequestBody
    ): Response<PaymentCombinedResponse>

    @POST("dpm/payments-gwproxy/v2/payments")
    suspend fun postPayment(
        @Header("Authorization") authorization: String,
        @Body requestBody: PaymentRequestBody
    ): Response<PaymentResponse>
}