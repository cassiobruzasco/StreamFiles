package com.pagonxt.sdk.hal.middleware.domain.model

import com.pagonxt.sdk.hal.middleware.domain.enum.CardTypeEnum

data class CardDataModel(
    val aid: String?,
    val applicationName: String,
    val cardholderName: String?,
    val expirationDate: String,
    val issuerCountryCode: String?,
    val labelName: String,
    val pan: String,
    val serviceCode: String?,
    val track1: String?,
    val track2: String?,
    val track3: String?,
    val type: CardTypeEnum
)