package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.hal.emvKernel.Decision
import com.pagonxt.hal.emvKernel.ProcessResult
import com.pagonxt.hal.utils.byteArray.toHex
import com.pagonxt.hal.utils.tlv.toByteArray
import com.pagonxt.sdk.hal.middleware.domain.enum.DecisionEnum
import com.pagonxt.sdk.hal.middleware.domain.model.ProcessResultModel

class ProcessResultMapper {
    fun getProcessResult(data: ProcessResult?): ProcessResultModel? =
        data?.let {
            ProcessResultModel(
                decision = getDecision(data.decision),
                ksn = data.ksn,
                pinOffline = data.pinOffline,
                pinOnline = data.pinOnline,
                signature = data.signature,
                tagsEmv = data.tlvs.toByteArray().toHex()
            )
        } ?: run {
            null
        }

    private fun getDecision(decision: Decision): DecisionEnum =
        when (decision) {
            Decision.APPROVED -> DecisionEnum.APPROVED
            Decision.REFUND -> DecisionEnum.REFUND
            Decision.DENIAL -> DecisionEnum.DENIAL
            Decision.MAGNETIC -> DecisionEnum.MAGNETIC
            Decision.GO_ON_LINE -> DecisionEnum.GO_ON_LINE
        }
}