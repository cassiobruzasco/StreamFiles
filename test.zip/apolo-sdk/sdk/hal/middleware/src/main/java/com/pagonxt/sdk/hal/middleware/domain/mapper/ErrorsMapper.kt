package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.hal.emvKernel.Errors
import com.pagonxt.sdk.hal.middleware.domain.enum.ErrorsEnum

class ErrorsMapper {
    fun getErrors(data: Errors?): ErrorsEnum? =
        data?.let {
            when (data) {
                Errors.TABLE_ERROR -> ErrorsEnum.TABLE_ERROR
                Errors.NO_MATCH -> ErrorsEnum.NO_MATCH
                Errors.DUMBCARD -> ErrorsEnum.DUMBCARD
                Errors.CARDPROBLEMS -> ErrorsEnum.CARDPROBLEMS
                Errors.CARDBLOCKED -> ErrorsEnum.CARDBLOCKED
                Errors.CANCELED -> ErrorsEnum.CANCELED
                Errors.INVPARM -> ErrorsEnum.INVPARM
                Errors.TIMEOUT -> ErrorsEnum.TIMEOUT
                Errors.EXECERR -> ErrorsEnum.EXECERR
                Errors.TABERR -> ErrorsEnum.TABERR
                Errors.UNKNOWNSTAT -> ErrorsEnum.UNKNOWNSTAT
                Errors.RSPERR -> ErrorsEnum.RSPERR
                Errors.COMMTOUT -> ErrorsEnum.COMMTOUT
                Errors.INTERR -> ErrorsEnum.INTERR
                Errors.MCDATAERR -> ErrorsEnum.MCDATAERR
                Errors.ERRPIN -> ErrorsEnum.ERRPIN
                Errors.NOCARD -> ErrorsEnum.NOCARD
                Errors.PINBUSY -> ErrorsEnum.PINBUSY
                Errors.ERRCARD -> ErrorsEnum.ERRCARD
                Errors.CARDINV -> ErrorsEnum.CARDINV
                Errors.CARDERRSTRUCT -> ErrorsEnum.CARDERRSTRUCT
                Errors.CARDINVALIDAT -> ErrorsEnum.CARDINVALIDAT
                Errors.CARDINVDATA -> ErrorsEnum.CARDINVDATA
                Errors.CARDAPPNAV -> ErrorsEnum.CARDAPPNAV
                Errors.CARDAPPNAUT -> ErrorsEnum.CARDAPPNAUT
                Errors.NOBALANCE -> ErrorsEnum.NOBALANCE
                Errors.LIMITEXC -> ErrorsEnum.LIMITEXC
                Errors.CARDNOTEFFECT -> ErrorsEnum.CARDNOTEFFECT
                Errors.ERRFALBACK -> ErrorsEnum.ERRFALBACK
                Errors.CTLSSMULTIPLE -> ErrorsEnum.CTLSSMULTIPLE
                Errors.ERRCTLSS -> ErrorsEnum.ERRCTLSS
                Errors.CTLSSINVALIDAT -> ErrorsEnum.CTLSSINVALIDAT
                Errors.CTLSSPROBLEMS -> ErrorsEnum.CTLSSPROBLEMS
                Errors.CTLSSAPPNAV -> ErrorsEnum.CTLSSAPPNAV
                Errors.CTLSSAPPNAUT -> ErrorsEnum.CTLSSAPPNAUT
                Errors.CTLSSEXTCVM -> ErrorsEnum.CTLSSEXTCVM
                Errors.CTLSFALLBACK -> ErrorsEnum.CTLSFALLBACK
                Errors.LOCKED -> ErrorsEnum.LOCKED
            }
        } ?: run {
            null
        }
}