package com.pagonxt.sdk.hal.middleware.domain.enum

/**
 * Tables extracted from the document LAC POS Terminal - Technical Specification - Version 819 DRAFT16 (13-Jun-2024)
 * Page 20 - AID_CTLSS_APPSUPPORT:
 *
 * 0 = Not supported.
 * 1 = Supports VISA MSD.
 * 2 = Supports VISA qVSDC.
 * 3 = Supports MasterCard PayPass Mag Stripe.
 * 4 = Supports MasterCard PayPass M/Chip.
 * 5 = Supports Amex Expresspay Magstripe Mode.
 * 6 = Supports Amex Expresspay EMV Mode.
 * 7 = Supports D-PAS Magstripe Mode.
 * 8 = Supports D-PAS EMV Mode.
 *
 */
enum class AidContactlessAppSupportEnum(val value: Int) {
    NOT_SUPPORTED(0),
    VISA_MSD(1),
    VISA_VSDC(2),
    MASTERCARD_PAY_PASS_MAG_STRIPE(3),
    MASTERCARD_PAY_PASS_M_CHIP(4),
    AMEX_EXPRESS_PAY_MAG_STRIPE_MODE(5),
    AMEX_EXPRESS_PAY_EMV_MODE(6),
    D_PAS_MAG_STRIPE_MODE(7),
    D_PAS_EMV_MODE(8);

    companion object {
        fun from(value: Int): AidContactlessAppSupportEnum {
            return entries.find { it.value == value } ?: NOT_SUPPORTED
        }
    }
}