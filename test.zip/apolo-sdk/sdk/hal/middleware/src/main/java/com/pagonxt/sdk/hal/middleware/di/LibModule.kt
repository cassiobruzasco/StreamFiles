package com.pagonxt.sdk.hal.middleware.di

import android.content.Context
import android.content.SharedPreferences
import com.pagonxt.sdk.hal.middleware.data.constant.BaseUrlConst.DUMMY_API_BASE_URL
import com.pagonxt.sdk.hal.middleware.data.constant.BaseUrlConst.OTHER_API_BASE_URL
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.DUMMY_API_NAMED
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.DUMMY_API_NAMED_QUALIFIER
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.OTHER_API_NAMED
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.OTHER_API_NAMED_QUALIFIER
import com.pagonxt.sdk.hal.middleware.data.constant.SharedPreferencesConst.PAYMENT_SHARED_PREFERENCES
import com.pagonxt.sdk.hal.middleware.data.remote.ApiService
import com.pagonxt.sdk.hal.middleware.domain.broadcast.PlatformPackageBroadcastReceiver
import com.pagonxt.sdk.hal.middleware.domain.emv.BCGlobal
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager
import com.pagonxt.sdk.hal.middleware.sdk.SdkHelper
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.core.qualifier.named
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

internal fun libModule(
    context: Context,
    onPlatformBound: (() -> Unit)? = null,
) = module {

    single {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()
    }

    // Retrofit singletons with qualifiers
    single(named(DUMMY_API_NAMED)) {
        Retrofit.Builder()
            .baseUrl(DUMMY_API_BASE_URL)
            .client(get())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
    single(named(OTHER_API_NAMED)) {
        Retrofit.Builder()
            .baseUrl(OTHER_API_BASE_URL)
            .client(get())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // ApiService singletons with qualifiers
    single<ApiService>(named(DUMMY_API_NAMED_QUALIFIER)) {
        get<Retrofit>(named(DUMMY_API_NAMED)).create(
            ApiService::class.java
        )
    }
    single<ApiService>(named(OTHER_API_NAMED_QUALIFIER)) {
        get<Retrofit>(named(OTHER_API_NAMED)).create(
            ApiService::class.java
        )
    }

    // SharedPreferences singleton
    single<SharedPreferences> {
        context.getSharedPreferences(PAYMENT_SHARED_PREFERENCES, Context.MODE_PRIVATE)
    }

    // PlatformManager singleton
    single {
        PlatformManager(context, get(), get(), get(), get())
    }

    // SDK Helper
    single { SdkHelper(get(), get(), onPlatformBound) }

    // BC Global
    factory { BCGlobal(get(), context) }

    // PlatformPackageBroadcastReceiver
    factory { PlatformPackageBroadcastReceiver(get()) }
}