package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.pagonxt.sdk.hal.middleware.domain.mapper.PublicKeyTableMapper
import com.pagonxt.sdk.hal.middleware.domain.model.PublicKeyTableModel
import com.pagonxt.sdk.hal.middleware.domain.repository.TransactionRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class GetPublicKeyTableUseCase(
    private val repository: TransactionRepository,
    private val mapper: PublicKeyTableMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke() = flow {
        try {
            repository.getPublicKeyTable().let { response ->
                when (response.code()) {
                    200 -> {
                        response.body()?.let { body ->
                            emit(PublicKeyTableState.Success(mapper.getPublicKey(body)))
                        } ?: run {
                            emit(PublicKeyTableState.Error("PublicKeyTable empty response body"))
                        }
                    }

                    else -> {
                        emit(PublicKeyTableState.Error(response.message()))
                    }
                }

            }
        } catch (e: Exception) {
            emit(PublicKeyTableState.Error(e.message ?: "Unknown Error"))
        }
    }.onStart {
        emit(PublicKeyTableState.Loading)
    }.flowOn(coroutineContext)
}

abstract class PublicKeyTableState {
    object Loading : PublicKeyTableState()
    data class Success(val data: List<PublicKeyTableModel>) : PublicKeyTableState()
    data class Error(val message: String) : PublicKeyTableState()
}