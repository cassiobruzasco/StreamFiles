package com.pagonxt.sdk.hal.middleware.data.response

import com.google.gson.annotations.SerializedName

data class PaymentResponse(
    @SerializedName("seller_id") val sellerId: String?,
    @SerializedName("payment_id") val paymentId: String?,
    @SerializedName("order_id") val orderId: String?,
    @SerializedName("amount") val amount: String?,
    @SerializedName("currency") val currency: String?,
    @SerializedName("status") val status: String?,
    @SerializedName("payment_method") val paymentMethod: String?,
    @SerializedName("received_at") val receivedAt: String?,
    @SerializedName("transaction_id") val transactionId: String?,
    @SerializedName("original_transaction_id") val originalTransactionId: String?,
    @SerializedName("authorized_at") val authorizedAt: String?,
    @SerializedName("reason_code") val reasonCode: String?,
    @SerializedName("reason_message") val reasonMessage: String?,
    @SerializedName("acquirer") val acquirer: String?,
    @SerializedName("soft_descriptor") val softDescriptor: String?,
    @SerializedName("authorization_code") val authorizationCode: String?,
    @SerializedName("acquirer_transaction_id") val acquirerTransactionId: String?
)