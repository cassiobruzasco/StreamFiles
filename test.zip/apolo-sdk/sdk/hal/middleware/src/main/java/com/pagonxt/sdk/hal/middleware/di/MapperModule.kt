package com.pagonxt.sdk.hal.middleware.di

import com.pagonxt.sdk.hal.middleware.domain.mapper.AidTableMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.AuthMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.CardDataMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.ErrorsMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.PaymentCombinedMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.PaymentMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.ProcessResultMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.PublicKeyTableMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.ResultDataMapper
import com.pagonxt.sdk.hal.middleware.domain.mapper.TerminalTableMapper
import org.koin.dsl.module

internal fun mapperModule() = module {
    single { AidTableMapper() }
    single { PublicKeyTableMapper() }
    single { TerminalTableMapper() }
    single { PaymentCombinedMapper() }
    single { AuthMapper(get()) }
    single { PaymentMapper() }
    single { CardDataMapper() }
    single { ProcessResultMapper() }
    single { ResultDataMapper() }
    single { ErrorsMapper() }
}