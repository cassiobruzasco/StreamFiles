package com.pagonxt.sdk.hal.middleware.domain.extension

import java.text.NumberFormat
import java.util.Locale

// TODO: where to use?
//fun String.formatCurrency(): String {
//    val amount = if (this.isNotEmpty()) this.toDouble() / 100 else 0.0
//    return try {
//        NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(amount)
//    } catch (e: Exception) {
//        TransactionConst.MONEY_VALUE_ZERO
//    }
//}