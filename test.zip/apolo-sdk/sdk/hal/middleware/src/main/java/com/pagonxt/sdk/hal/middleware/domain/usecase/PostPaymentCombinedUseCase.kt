package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.google.gson.Gson
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedRequestBody
import com.pagonxt.sdk.hal.middleware.domain.mapper.PaymentCombinedMapper
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedErrorModel
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentCombinedModel
import com.pagonxt.sdk.hal.middleware.domain.repository.SEPRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class PostPaymentCombinedUseCase(
    private val repository: SEPRepository,
    private val mapper: PaymentCombinedMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke(requestBody: PaymentCombinedRequestBody) = flow {
        try {
            repository.postPaymentCombined(
                requestBody = requestBody
            ).let { response ->
                when (response.code()) {
                    200 -> {
                        response.body()?.let { responseBody ->
                            emit(
                                PaymentCombinedState.Success(
                                    mapper.getPaymentCombinedModel(
                                        responseBody
                                    )
                                )
                            )
                        } ?: run {
                            emit(PaymentCombinedState.EmptyError("PostPaymentCreditUseCase empty response body"))
                        }
                    }

                    201 -> {
                        response.body()?.let { responseBody ->
                            emit(
                                PaymentCombinedState.Success(
                                    mapper.getPaymentCombinedModel(
                                        responseBody
                                    )
                                )
                            )
                        } ?: run {
                            emit(PaymentCombinedState.EmptyError("PostPaymentCreditUseCase empty response body"))
                        }
                    }

                    400 -> {
                        response.body()?.let { responseBody ->
                            emit(
                                PaymentCombinedState.Error(
                                    mapper.getPaymentCombinedErrorModel(responseBody)
                                )
                            )
                        } ?: run {
                            emit(PaymentCombinedState.EmptyError("PostPaymentCreditUseCase empty response body"))
                        }
                    }

                    404 -> {
                        response.body()?.let { responseBody ->
                            emit(
                                PaymentCombinedState.Error(
                                    mapper.getPaymentCombinedErrorModel(responseBody)
                                )
                            )
                        } ?: run {
                            emit(PaymentCombinedState.EmptyError("PostPaymentCreditUseCase empty response body"))
                        }
                    }

                    500 -> {
                        response.body()?.let { responseBody ->
                            emit(
                                PaymentCombinedState.Error(
                                    mapper.getPaymentCombinedErrorModel(responseBody)
                                )
                            )
                        } ?: run {
                            emit(PaymentCombinedState.EmptyError("PostPaymentCreditUseCase empty response body"))
                        }
                    }

                    else -> {
                        response.errorBody()?.let {
                            emit(
                                PaymentCombinedState.EmptyError(
                                    "" +
                                            "PostPaymentCreditUseCase error:" +
                                            "\ncode: ${response.code()}" +
                                            "\nmessage: ${response.message()}" +
                                            "\nerrorBody: ${Gson().toJson(Gson().toJson(it))}"
                                )
                            )
                        } ?: run {
                            emit(
                                PaymentCombinedState.EmptyError(
                                    "" +
                                            "PostPaymentCreditUseCase error:" +
                                            "\ncode: ${response.code()}" +
                                            "\nmessage: ${response.message()}" +
                                            "\nerrorBody: ${Gson().toJson(response.errorBody())}"
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            emit(PaymentCombinedState.FatalError(e))
        }
    }.onStart {
        emit(PaymentCombinedState.Loading)
    }.flowOn(coroutineContext)
}

sealed class PaymentCombinedState {
    data object Loading : PaymentCombinedState()
    data class Success(val data: PaymentCombinedModel) : PaymentCombinedState()
    data class Error(val error: PaymentCombinedErrorModel) : PaymentCombinedState()
    data class EmptyError(val message: String) : PaymentCombinedState()
    data class FatalError(val error: Exception) : PaymentCombinedState()
}