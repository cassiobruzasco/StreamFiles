package com.pagonxt.sdk.hal.middleware.domain.utils

object TransactionUtils {
    fun parseEMVTAGS(tags: String): IntArray {
        val ret = ArrayList<Int>()
        var offset = 0
        while (offset < tags.length) {
            val subTag = tags.substring(offset, offset + 2)
            offset += if (subTag.equals("9F", ignoreCase = true) || subTag.equals(
                    "5F",
                    ignoreCase = true
                )
            ) {
                ret.add(
                    ConvertUtils.byteArrayToInt(
                        ConvertUtils.hexStringToByte(
                            tags.substring(
                                offset,
                                offset + 4
                            )
                        )
                    )
                )
                4
            } else {
                ret.add(ConvertUtils.byteArrayToInt(ConvertUtils.hexStringToByte(subTag)))
                2
            }
        }
        return convertIntegers(ret)
    }

    private fun convertIntegers(integers: ArrayList<Int>): IntArray {
        val ret = IntArray(integers.size)
        val iterator: Iterator<Int> = integers.iterator()
        for (i in ret.indices) {
            ret[i] = iterator.next()
        }
        return ret
    }
}