package com.pagonxt.sdk.hal.middleware

import android.content.Context
import com.pagonxt.sdk.hal.middleware.di.libModule
import com.pagonxt.sdk.hal.middleware.di.mapperModule
import com.pagonxt.sdk.hal.middleware.di.repositoryModule
import com.pagonxt.sdk.hal.middleware.di.stateViewModule
import com.pagonxt.sdk.hal.middleware.di.useCaseModule
import com.pagonxt.sdk.hal.middleware.sdk.SdkHelper
import org.koin.dsl.module

class Middleware(
    private val sdkHelper: SdkHelper
) {
    companion object {
        fun injection(
            context: Context,
            onPlatformBound: (() -> Unit)? = null,
        ) = module {
            includes(
                libModule(context, onPlatformBound),
                mapperModule(),
                repositoryModule(context),
                useCaseModule(),
                stateViewModule()
            )
        }
    }

    fun setup() {
        sdkHelper.connectSdk()
    }
}