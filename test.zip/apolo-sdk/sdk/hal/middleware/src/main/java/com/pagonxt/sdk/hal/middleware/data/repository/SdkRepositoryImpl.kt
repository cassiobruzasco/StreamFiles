package com.pagonxt.sdk.hal.middleware.data.repository

import android.content.Context
import android.util.Log
import com.getnet.posdigital.PosDigital
import com.getnet.posdigital.info.IInfoCallback
import com.getnet.posdigital.info.InfoResponse
import com.pagonxt.sdk.hal.middleware.domain.repository.SdkRepository
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class SdkRepositoryImpl(
    context: Context
) : SdkRepository {
    companion object {
        val TAG: String = SdkRepositoryImpl::class.java.simpleName
    }

    private val appContext: Context = context.applicationContext

    override suspend fun connect(): SdkRepositoryState =
        suspendCancellableCoroutine { connection ->
            try {
                // Defensive: avoid leaking receivers if connect is called multiple times.
                runCatching {
                    if (PosDigital.getInstance().isInitiated()) {
                        PosDigital.unregister(appContext)
                    }
                }

                PosDigital.register(appContext, object : PosDigital.BindCallback {
                    override fun onConnected() {
                        if (connection.isActive) connection.resume(SdkRepositoryState.OnConnected)
                    }

                    override fun onDisconnected() {
                        if (connection.isActive) connection.resume(SdkRepositoryState.OnDisconnected)
                    }

                    override fun onError(e: Exception) {
                        if (connection.isActive) connection.resume(SdkRepositoryState.OnError(e))
                    }
                })
            } catch (e: Exception) {
                if (connection.isActive) connection.resume(SdkRepositoryState.OnError(e))
            }
        }


    override suspend fun disconnect(): SdkRepositoryState {
        return try {
            runCatching {
                if (PosDigital.getInstance().isInitiated()) {
                    PosDigital.unregister(appContext)
                }
            }.getOrThrow()
            SdkRepositoryState.OnDisconnected
        } catch (e: Exception) {
            Log.e(
                TAG,
                "disconnectPosDigitalService - Erro de exception no Destroy da Activity: ${e.message}",
            )
            SdkRepositoryState.OnError(e)
        }
    }

    override suspend fun info(): SdkInfoRepositoryState =
        suspendCancellableCoroutine { connection ->
            PosDigital.getInstance().getInfo().info(object : IInfoCallback.Stub() {
                override fun onInfo(p0: InfoResponse?) {
                    p0?.let {
                        if (connection.isActive) connection.resume(
                            SdkInfoRepositoryState.OnInfo(
                                it
                            )
                        )
                    } ?: run {
                        Log.d(TAG, "InfoResponse is null")
                        if (connection.isActive) connection.resume(
                            SdkInfoRepositoryState.OnError(
                                "InfoResponse is null"
                            )
                        )
                    }
                }

                override fun onError(p0: String?) {
                    if (connection.isActive) connection.resume(
                        SdkInfoRepositoryState.OnError(
                            p0
                        )
                    )
                }
            })
        }
}

sealed class SdkRepositoryState {
    data object OnConnected : SdkRepositoryState()
    data object OnDisconnected : SdkRepositoryState()
    data class OnError(val error: Exception?) : SdkRepositoryState()
}

sealed class SdkInfoRepositoryState {
    data class OnInfo(val data: InfoResponse) : SdkInfoRepositoryState()
    data class OnError(val error: String?) : SdkInfoRepositoryState()
}