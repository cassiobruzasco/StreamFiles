package com.pagonxt.sdk.hal.middleware.domain.model

internal data class SEPInfoModel(
    val build: SEPBuildInfoModel
)

internal data class SEPBuildInfoModel(
    val groupId: String,
    val artifactId: String,
    val version: String,
    val date: String
)
