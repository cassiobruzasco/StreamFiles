package com.pagonxt.sdk.hal.middleware.domain.enum

enum class DecisionEnum {
    GO_ON_LINE,
    DENIAL,
    APPROVED,
    REFUND,
    MAGNETIC;
}