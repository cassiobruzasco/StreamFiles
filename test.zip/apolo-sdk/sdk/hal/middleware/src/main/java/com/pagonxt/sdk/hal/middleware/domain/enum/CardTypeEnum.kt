package com.pagonxt.sdk.hal.middleware.domain.enum

enum class CardTypeEnum {
    Magnetic,
    Contact,
    Contactless,
    ContactlessMag;
}