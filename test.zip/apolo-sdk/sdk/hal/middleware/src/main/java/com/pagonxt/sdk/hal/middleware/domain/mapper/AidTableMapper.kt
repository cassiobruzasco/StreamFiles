package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.sdk.hal.middleware.data.response.AidTableResponse
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel

class AidTableMapper {
    internal fun getAidTable(response: List<AidTableResponse>): List<AidTableModel> =
        response.map {
            AidTableModel(
                terminalCapabilityAdditional = it.terminalCapabilityAdditional,
                code = it.code,
                amountNullContactless = it.amountNullContactless,
                appSupportContactless = it.appSupportContactless,
                requestCVMContactless = it.requestCVMContactless,
                floorContactless = it.floorContactless,
                magStripeVRSContactless = it.magStripeVRSContactless,
                terminalActionCodeDefaultContactless = it.terminalActionCodeDefaultContactless,
                terminalActionCodeDenialContactless = it.terminalActionCodeDenialContactless,
                terminalActionCodeOnlineContactless = it.terminalActionCodeOnlineContactless,
                transactionLimitContactless = it.transactionLimitContactless,
                ddol = it.ddol,
                floor = it.floor,
                maxPercentage = it.maxPercentage,
                merchantCategoryCode = it.merchantCategoryCode,
                option1 = it.option1,
                product = it.product,
                terminalActionCodeDefault = it.terminalActionCodeDefault,
                terminalActionCodeDenial = it.terminalActionCodeDenial,
                terminalActionCodeOnline = it.terminalActionCodeOnline,
                tags = it.tags,
                tamCode = it.tamCode,
                tamTags = it.tamTags,
                targetPercentage = it.targetPercentage,
                transactionCategoryCode = it.transactionCategoryCode,
                tdol = it.tdol,
                terminalCapability = it.terminalCapability,
                threshold = it.threshold,
                type = it.type,
                version1 = it.version1,
                version2 = it.version2,
                version3 = it.version3,
                terminalCapabilityContactless = it.terminalCapability
            )
        }
}