package com.pagonxt.sdk.hal.middleware.data.constant

internal object BaseUrlConst {
    const val DUMMY_API_BASE_URL = "https://dummyjson.com/"
    const val OTHER_API_BASE_URL = "https://api.pre.globalgetnet.com/"
}