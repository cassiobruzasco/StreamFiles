package com.pagonxt.sdk.hal.middleware.domain.constant

internal object PackageManagerConst {
    const val PLATFORM_PACKAGE_NAME = "com.pagonxt.hal.platform"
}