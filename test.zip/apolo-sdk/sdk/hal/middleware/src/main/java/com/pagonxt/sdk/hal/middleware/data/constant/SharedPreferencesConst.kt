package com.pagonxt.sdk.hal.middleware.data.constant

internal object SharedPreferencesConst {
    const val PAYMENT_SHARED_PREFERENCES = "payment"
    const val AUTH_TOKEN = "auth_token"
    const val AUTH_TOKEN_BASIC = "Basic Y2lkXzc0YzBmZmI1LWUzNWUtNDEyZi1iZjU0LTZmZDhmN2YwMTgyMDo0MzgzNjE5OS04M2QwLTQwMjgtOWE4Mi04NDg3OGFmMjliNDI="
}