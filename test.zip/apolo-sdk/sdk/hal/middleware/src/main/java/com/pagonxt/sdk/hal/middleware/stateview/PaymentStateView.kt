package com.pagonxt.sdk.hal.middleware.stateview

import com.pagonxt.sdk.hal.middleware.domain.usecase.PaymentState
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostPaymentUseCase
import com.pagonxt.sdk.hal.middleware.data.request.PaymentRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.CardRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.PaymentDataRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.PaymentDetailRequestBody
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Bridges the payment use-case with the engine.
 *
 * Uses [SharedFlow] with replay=0 so a new collector never receives a stale
 * Success/Error from a previous transaction — eliminating the need for manual reset().
 */
class PaymentStateView internal constructor(
    private val useCase: PostPaymentUseCase
) {
    private val _paymentState = MutableSharedFlow<PaymentState>(
        replay = 0,
        extraBufferCapacity = 1
    )

    /** Hot stream of payment operation results. Each postPayment() emits Loading → Success|Error. */
    val paymentStateView: SharedFlow<PaymentState> = _paymentState.asSharedFlow()

    fun postPayment(
        amount: Int,
        pan: String,
        tagsEmv: String,
        track2: String,
        requestBody: PaymentRequestBody? = null
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            useCase.invoke(
                requestBody = setPaymentRequestBody(
                    amount = amount,
                    pan = pan,
                    tagsEmv = tagsEmv,
                    track2 = track2
                )
            ).collect { state ->
                _paymentState.emit(state)
            }
        }
    }

    private fun setPaymentRequestBody(
        amount: Int,
        pan: String,
        tagsEmv: String,
        track2: String
    ) =
        PaymentRequestBody(
            idempotencyKey = "3f5aeeb8-bba7-4897-99a5-717f2cb055a4",
            requestId = "576c9012-57f4-4b2d-ae85-a231ec9c7e8a",
            orderId = "5a9c4615-827c-4615-9014-6b0f08dccd74",
            data = PaymentDataRequestBody(
                amount = amount,
//                currency = "CLP",
                currency = "BRL",
                customerId = "marcos_13",
                payment = PaymentDetailRequestBody(
                    paymentId = "13b623f0-5971-4923-950a-7ba1610672af",
                    paymentMethod = "DIRECT_CREDIT",
                    transactionType = "FULL",
                    numberInstallments = 1,
                    softDescriptor = "COPO TERMICO 473ML PRETO STANLEY",
                    dynamicMcc = "1234",
                    card = CardRequestBody(
                        number = pan,
                        entryMode = "chip",
//                        emv = "9f2701809f3303e0f8c8950580000080009f37045d21705a9f100706010a03a0b8089f2608819ba36f3f7934149f360205b782021c009c01009f1a0204849a032002279f02060000000309605F2A0200325f3401019f34031e03009f120c56495341204352454449544f5f201a2f435249535449414e2047414c494e444f2043484156455a2020",
                        emv = tagsEmv,
//                        track2 = "4025240000000943=281028102800006930"
                        track2 = track2
                    )
                )
            )
        )
}