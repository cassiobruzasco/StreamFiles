package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.pagonxt.sdk.hal.middleware.data.request.PaymentRequestBody
import com.pagonxt.sdk.hal.middleware.domain.mapper.PaymentMapper
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentModel
import com.pagonxt.sdk.hal.middleware.domain.repository.SEPRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class PostPaymentUseCase(
    private val repository: SEPRepository,
    private val mapper: PaymentMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke(requestBody: PaymentRequestBody) = flow {
        try {
            repository.postPayment(requestBody)
                .let { response ->
                    when (response.code()) {
                        200 -> {
                            response.body()?.let { responseBody ->
                                emit(
                                    PaymentState.Success(
                                        mapper.getPayment(responseBody)
                                    )
                                )
                            } ?: run {
                                emit(PaymentState.EmptyError("PostPaymentUseCase empty response body"))
                            }
                        }

                        else -> {
                            emit(
                                PaymentState.Error(
                                    ErrorOutputDefault(
                                        code = response.code(),
                                        message = response.message(),
                                        errorBody = response.errorBody(),
                                        raw = response.raw()
                                    )
                                )
                            )
                        }
                    }
                }
        } catch (e: Exception) {
            emit(
                PaymentState.Error(
                    ErrorOutputDefault(
                        code = -1,
                        message = "PostPaymentUseCase exception: ${e.message}",
                        errorBody = null,
                        raw = null
                    )
                )
            )
        }
    }.onStart {
        emit(PaymentState.Loading)
    }.flowOn(coroutineContext)
}

sealed class PaymentState {
    data object Idle : PaymentState()
    data object Loading : PaymentState()
    data class Success(val data: PaymentModel) : PaymentState()
    data class Error(val error: ErrorOutputDefault) : PaymentState()
    data class EmptyError(val message: String) : PaymentState()
}