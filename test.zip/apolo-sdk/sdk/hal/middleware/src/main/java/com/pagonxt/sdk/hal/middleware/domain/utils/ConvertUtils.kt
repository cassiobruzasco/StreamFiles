package com.pagonxt.sdk.hal.middleware.domain.utils

import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import kotlin.experimental.and
import kotlin.experimental.or

object ConvertUtils {

    @JvmStatic
    fun byteToHexString(data: ByteArray): String {
        val sb = StringBuilder(data.size * 2)
        for (b in data) sb.append(String.format("%02x", b and 0xFF.toByte()))
        return sb.toString()
    }

    @JvmStatic
    fun asciiArrayToString(array: ByteArray): String {
        val sb = java.lang.StringBuilder(array.size)
        for (b in array) {
            if (b in 0x20..0x7E) sb.append(Char(b.toUShort()))
        }
        return sb.toString()
    }

    @JvmStatic
    fun hex2byte(s: String): ByteArray? {
        return if (s.length % 2 == 0) hex2byte(s.toByteArray(),0,s.length shr 1)
            else hex2byte("0$s")
    }

    fun hex2byte(b: ByteArray, offset: Int, len: Int): ByteArray {
        val d = ByteArray(len)
        for (i in 0 until len * 2) {
            val shift = if (i % 2 == 1) 0 else 4
            d[i shr 1] = ((d[i shr 1] or Char(b[offset + i].toUShort()).digitToIntOrNull(16)!!.toByte())
                ?: (-1 shl shift)).toByte()
        }
        return d
    }

    @JvmStatic
    fun byteArrayToInt(array: ByteArray): Int {
        var ret = -1
        val size = array.size
        var ok = true
        val data = ByteArray(4)
        when (size) {
            1 -> data[3] = array[0]
            2 -> {
                data[2] = array[0]
                data[3] = array[1]
            }
            3 -> {
                data[1] = array[0]
                data[2] = array[1]
                data[3] = array[3]
            }
            4 -> System.arraycopy(array, 0, data, 0, size)
            else -> ok = false
        }
        if (ok) {
            val wrapper = ByteBuffer.wrap(data)
            ret = wrapper.int
        }
        return ret
    }

    @JvmStatic
    fun intToByteArray(value: Int): ByteArray {
        val ret = ByteArray(2)
        ret[0] = (value shr 8).toByte()
        ret[1] = value.toByte()
        return ret
    }

    @JvmStatic
    fun byteArrayFromLong(value: Long, length: Int): ByteArray {
        val array = ByteArray(length)
        var v = value
        for (i in 0 until length) {
            array[length - 1 - i] = (v and 255L).toInt().toByte()
            v = v ushr 8
        }
        return array
    }

    @JvmStatic
    fun stringToBCD(value: String): ByteArray? {
        var value = value
        var ret: ByteArray? = null
        var highNibble: Int
        var lowNibble: Int
        var index = 0

        // testa se é um número ou caracteres especiais
        if (isNumberOrSpecialCharacter(value)) {
            // verifica se tem comprimento ímpar
            if (value.length % 2 != 0) {
                //jp39087 - QC2264 - Estava adicionando um '0' e conforme certificação deve adicionar um '?'
                value += "?"
            }
            ret = ByteArray(value.length / 2)
            var i = 0
            while (i < value.length) {
                highNibble = value[i] - '0'
                lowNibble = value[i + 1] - '0'
                ret[index] = ret[index] or (highNibble shl 4).toByte()
                ret[index] = ret[index] or lowNibble.toByte()
                index++
                i += 2
            }
        }
        return ret
    }

    private fun isNumberOrSpecialCharacter(str: String): Boolean {
        var ret = true
        var character: Char
        for (element in str) {
            character = element
            if (character < '0' || character > '?') {
                ret = false
                break
            }
        }
        return ret
    }

    @JvmStatic
    fun stringToAsciiArray(str: String): ByteArray {
        return str.toByteArray(StandardCharsets.US_ASCII)
    }

    @JvmStatic
    fun asciiStringFromHex(hexString: String): String {
        val convertedASCII = java.lang.StringBuilder()
        var i = 0
        while (i < hexString.length) {
            val str = hexString.substring(i, i + 2)
            convertedASCII.append(str.toInt(16).toChar())
            i += 2
        }
        return convertedASCII.toString()
    }

    @JvmStatic
    fun str2Long(amount: String): Long {
        return if (amount.isNotEmpty()) amount
                .replace(",", "")
                .replace(".", "")
                .replace("R$", "").trim { it <= ' ' }.toLong() else 0L
    }

    @JvmStatic
    fun hexStringToByte(strData: String): ByteArray {
        var mutableStrData = strData
        if (mutableStrData.length % 2 != 0)
            mutableStrData = "0$mutableStrData"

        val len = mutableStrData.length
        val data = ByteArray(len / 2)
        for (i in 0 until len step 2) {
            data[i / 2] =
                ((Character.digit(mutableStrData[i], 16) shl 4) + Character.digit(mutableStrData[i + 1], 16)).toByte()
        }
        return data
    }

    @JvmStatic
    fun hexStringToByte(strData: String, alignRight: Boolean): ByteArray {
        var mutableStrData = strData
        if (mutableStrData.length % 2 != 0) {
            mutableStrData = if (alignRight) {
                mutableStrData + "F"
            } else {
                "0$mutableStrData"
            }
        }

        val len = mutableStrData.length
        val data = ByteArray(len / 2)
        for (i in 0 until len step 2) {
            data[i / 2] =
                ((Character.digit(mutableStrData[i], 16) shl 4) + Character.digit(mutableStrData[i + 1], 16)).toByte()
        }
        return data
    }

    @JvmStatic
    fun bcd2str(b: ByteArray, offset: Int, len: Int, padLeft: Boolean): String? {
        val d = java.lang.StringBuilder(len)
        val start = if (len and 1 == 1 && padLeft) 1 else 0
        for (i in start until len + start) {
            val shift = if (i and 1 == 1) 0 else 4
            var c = Character.forDigit(b[offset + (i shr 1)].toInt() shr shift and 15, 16)
            if (c == 'd') {
                c = '='
            }
            d.append(c.uppercaseChar())
        }
        return d.toString()
    }

    @JvmStatic
    fun bcdToInt(bcd: ByteArray): Int {
        var ret = 0
        val len = bcd.size
        if (len > 2 || len == 0) ret = -1 else if (len == 1) {
            ret += (bcd[0].toInt() and 0xF0 shr 4) * 10
            ret += bcd[0].toInt() and 0x0F
        } else {
            ret += (bcd[0].toInt() and 0xF0 shr 4) * 1000
            ret += (bcd[0].toInt() and 0x0F) * 100
            ret += (bcd[1].toInt() and 0xF0 shr 4) * 10
            ret += bcd[1].toInt() and 0x0F
        }
        return ret
    }

    @JvmStatic
    fun bcdToLong(bcd: ByteArray): Long {
        var ret: Long = 0
        val len = bcd.size
        if (len > 4 || len == 0) ret = -1 else if (len == 1) {
            ret += ((bcd[0].toInt() and 0xF0 shr 4) * 10).toLong()
            ret += (bcd[0].toInt() and 0x0F).toLong()
        } else {
            ret += ((bcd[0].toInt() and 0xF0 shr 4) * 10000000).toLong()
            ret += ((bcd[0].toInt() and 0x0F) * 1000000).toLong()
            ret += ((bcd[1].toInt() and 0xF0 shr 4) * 100000).toLong()
            ret += ((bcd[1].toInt() and 0x0F) * 10000).toLong()
            ret += ((bcd[2].toInt() and 0xF0 shr 4) * 1000).toLong()
            ret += ((bcd[2].toInt() and 0x0F) * 100).toLong()
            ret += ((bcd[3].toInt() and 0xF0 shr 4) * 10).toLong()
            ret += (bcd[3].toInt() and 0x0F).toLong()
        }
        return ret
    }

    @JvmStatic
    fun bcdToString(bcd: ByteArray): String? {
        var ret: String? = ""
        var aux: Int
        for (value in bcd) {
            aux = value.toInt() and 0xF0 shr 4
            ret += aux
            aux = value.toInt() and 0x0F
            ret += aux
        }
        return ret
    }

}