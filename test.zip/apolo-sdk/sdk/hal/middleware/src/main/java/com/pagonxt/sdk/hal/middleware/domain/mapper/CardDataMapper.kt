package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.hal.emvKernel.CardData
import com.pagonxt.hal.emvKernel.CardType
import com.pagonxt.sdk.hal.middleware.domain.enum.CardTypeEnum
import com.pagonxt.sdk.hal.middleware.domain.model.CardDataModel

class CardDataMapper {
    fun getCardData(data: CardData?): CardDataModel? =
        data?.let {
            CardDataModel(
                aid = data.aid,
                applicationName = data.applicationName,
                cardholderName = data.cardholderName,
                expirationDate = data.expirationDate,
                issuerCountryCode = data.issuerCountryCode,
                labelName = data.labelName,
                pan = data.pan,
                serviceCode = data.serviceCode,
                track1 = data.track1,
                track2 = data.track2,
                track3 = data.track3,
                type = getCardType(data.type)
            )
        } ?: run {
            null
        }

    private fun getCardType(type: CardType): CardTypeEnum = when (type) {
        CardType.Magnetic -> CardTypeEnum.Magnetic
        CardType.Contact -> CardTypeEnum.Contact
        CardType.Contactless -> CardTypeEnum.Contactless
        CardType.ContactlessMag -> CardTypeEnum.ContactlessMag
    }
}