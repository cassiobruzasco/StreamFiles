package com.pagonxt.sdk.hal.middleware.domain.constant

object ByteConst {
    const val BIT_1 = 1
    const val BIT_2 = 2
    const val BIT_3 = 3
    const val BIT_4 = 4
    const val BIT_5 = 5
    const val BIT_6 = 6
    const val BIT_7 = 7
    const val BIT_8 = 8
}