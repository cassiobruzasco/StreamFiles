package com.pagonxt.sdk.hal.middleware.domain.usecase

import com.pagonxt.sdk.hal.middleware.domain.mapper.TerminalTableMapper
import com.pagonxt.sdk.hal.middleware.domain.model.TerminalTableModel
import com.pagonxt.sdk.hal.middleware.domain.repository.TransactionRepository
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlin.coroutines.CoroutineContext

internal class GetTerminalTableUseCase(
    private val repository: TransactionRepository,
    private val mapper: TerminalTableMapper,
    private val coroutineContext: CoroutineContext
) {
    fun invoke() = flow {
        try {
            repository.getTerminalTable().let { response ->
                when (response.code()) {
                    200 -> {
                        response.body()?.let { body ->
                            emit(TerminalTableState.Success(mapper.getTerminalTable(body)))
                        } ?: run {
                            emit(TerminalTableState.Error("TerminalTable empty response body"))
                        }
                    }

                    else -> {
                        emit(TerminalTableState.Error(response.message()))
                    }
                }
            }
        } catch (e: Exception) {
            emit(TerminalTableState.Error(e.message ?: "Unknown Error"))
        }
    }.onStart {
        emit(TerminalTableState.Loading)
    }.flowOn(coroutineContext)
}

abstract class TerminalTableState {
    object Loading : TerminalTableState()
    data class Success(val data: TerminalTableModel) : TerminalTableState()
    data class Error(val message: String) : TerminalTableState()
}