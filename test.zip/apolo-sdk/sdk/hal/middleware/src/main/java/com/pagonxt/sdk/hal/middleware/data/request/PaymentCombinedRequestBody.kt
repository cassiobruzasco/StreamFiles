package com.pagonxt.sdk.hal.middleware.data.request

import com.google.gson.annotations.SerializedName

data class PaymentCombinedRequestBody(
    @SerializedName("additional_data") val additionalData: Map<String, Any>?,
    @SerializedName("request_id") val requestId: String?,
    @SerializedName("order_id") val orderId: String?,
    @SerializedName("data") val data: PaymentCombinedData?,
    @SerializedName("encrypted_data") val encryptedData: String?
)

data class PaymentCombinedData(
    @SerializedName("amount") val amount: Long?,
    @SerializedName("currency") val currency: String?,
    @SerializedName("customer_id") val customerId: String?,
    @SerializedName("payments") val payments: List<PaymentCombinedPayment>?,
    @SerializedName("sub_merchant") val subMerchant: PaymentCombinedSubMerchant?,
    @SerializedName("additional_data") val additionalData: Map<String, Any>?
)

data class PaymentCombinedPayment(
    @SerializedName("idempotency_key") val idempotencyKey: String?,
    @SerializedName("payment_id") val paymentId: String?,
    @SerializedName("amount") val amount: Long?,
    @SerializedName("payment_method") val paymentMethod: String?,
    @SerializedName("save_card_data") val saveCardData: Boolean?,
    @SerializedName("transaction_type") val transactionType: String?,
    @SerializedName("number_installments") val numberInstallments: Int?,
    @SerializedName("soft_descriptor") val softDescriptor: String?,
    @SerializedName("dynamic_mcc") val dynamicMcc: String?,
    @SerializedName("card") val card: PaymentCombinedCard?,
    @SerializedName("tokenization") val tokenization: PaymentCombinedTokenization?,
    @SerializedName("wallet") val wallet: PaymentCombinedWallet?,
    @SerializedName("xid") val xid: String?,
    @SerializedName("ucaf") val ucaf: String?,
    @SerializedName("eci") val eci: String?,
    @SerializedName("tdsdsxid") val tdsdsxid: String?,
    @SerializedName("tdsver") val tdsver: String?,
    @SerializedName("is_pre_paid") val isPrePaid: Boolean?,
    @SerializedName("network_token") val networkToken: String?,
    @SerializedName("payment_tag") val paymentTag: String?,
    @SerializedName("billing_address") val billingAddress: PaymentCombinedBillingAddress?,
    @SerializedName("installment") val installment: PaymentCombinedInstallment?,
    @SerializedName("cross_border_data") val crossBorderData: PaymentCombinedCrossBorderData?
)

data class PaymentCombinedCard(
    @SerializedName("number") val number: String?,
    @SerializedName("expiration_month") val expirationMonth: String?,
    @SerializedName("expiration_year") val expirationYear: String?,
    @SerializedName("cardholder_name") val cardholderName: String?,
    @SerializedName("security_code") val securityCode: String?,
    @SerializedName("brand") val brand: String?,
    @SerializedName("number_token") val numberToken: String?,
    @SerializedName("entry_mode") val entryMode: String?,
    @SerializedName("seq_number") val seqNumber: String?,
    @SerializedName("pin_block") val pinBlock: String?,
    @SerializedName("pin_key_id") val pinKeyId: String?,
    @SerializedName("ksn") val ksn: String?,
    @SerializedName("emv") val emv: String?,
    @SerializedName("aid") val aid: String?,
    @SerializedName("cardholder_verification_method") val cardholderVerificationMethod: String?,
    @SerializedName("aggregator") val aggregator: String?,
    @SerializedName("service_code") val serviceCode: PaymentCombinedServiceCode?,
    @SerializedName("track_1") val track1: String?,
    @SerializedName("track_2") val track2: String?
)

data class PaymentCombinedServiceCode(
    @SerializedName("interchange") val interchange: String?,
    @SerializedName("chip") val chip: Boolean?,
    @SerializedName("authorization_process") val authorizationProcess: String?,
    @SerializedName("pin_required") val pinRequired: String?,
    @SerializedName("range_of_services") val rangeOfServices: String?
)

data class PaymentCombinedTokenization(
    @SerializedName("type") val type: String?,
    @SerializedName("cryptogram") val cryptogram: String?,
    @SerializedName("eci") val eci: String?,
    @SerializedName("requestor_id") val requestorId: String?,
    @SerializedName("pan") val pan: String?,
    @SerializedName("token_pan") val tokenPan: String?
)

data class PaymentCombinedWallet(
    @SerializedName("type") val type: String?,
    @SerializedName("id") val id: String?,
    @SerializedName("merchant_id") val merchantId: String?,
    @SerializedName("identification") val identification: String?,
    @SerializedName("payee_document") val payeeDocument: String?,
    @SerializedName("payee_name") val payeeName: String?,
    @SerializedName("authorization_token") val authorizationToken: String?,
    @SerializedName("fund_transfer") val fundTransfer: PaymentCombinedFundTransfer?,
    @SerializedName("capture_type") val captureType: String?,
    @SerializedName("ticket_number") val ticketNumber: String?,
    @SerializedName("capture_channel") val captureChannel: String?,
    @SerializedName("plans") val plans: String?,
    @SerializedName("sub_plan") val subPlan: String?
)

data class PaymentCombinedFundTransfer(
    @SerializedName("pay_action") val payAction: String?,
    @SerializedName("receiver") val receiver: PaymentCombinedReceiver?
)

data class PaymentCombinedReceiver(
    @SerializedName("account_number") val accountNumber: String?,
    @SerializedName("account_type") val accountType: String?,
    @SerializedName("first_name") val firstName: String?,
    @SerializedName("middle_name") val middleName: String?,
    @SerializedName("last_name") val lastName: String?,
    @SerializedName("addr_street") val addrStreet: String?,
    @SerializedName("addr_city") val addrCity: String?,
    @SerializedName("addr_state") val addrState: String?,
    @SerializedName("addr_country") val addrCountry: String?,
    @SerializedName("addr_postal_code") val addrPostalCode: String?,
    @SerializedName("nationality") val nationality: String?,
    @SerializedName("phone") val phone: String?,
    @SerializedName("date_of_birth") val dateOfBirth: String?,
    @SerializedName("id_type") val idType: String?,
    @SerializedName("id_num") val idNum: String?
)

data class PaymentCombinedBillingAddress(
    @SerializedName("street") val street: String?,
    @SerializedName("number") val number: String?,
    @SerializedName("complement") val complement: String?,
    @SerializedName("district") val district: String?,
    @SerializedName("city") val city: String?,
    @SerializedName("state") val state: String?,
    @SerializedName("country") val country: String?,
    @SerializedName("postal_code") val postalCode: String?,
    @SerializedName("type") val type: String?
)

data class PaymentCombinedInstallment(
    @SerializedName("quote_id") val quoteId: String?,
    @SerializedName("type") val type: String?,
    @SerializedName("number") val number: Int?,
    @SerializedName("schema") val schema: String?,
    @SerializedName("interest_rate") val interestRate: Int?
)

data class PaymentCombinedCrossBorderData(
    @SerializedName("first_name") val firstName: String?,
    @SerializedName("last_name") val lastName: String?,
    @SerializedName("type") val type: String?,
    @SerializedName("document_number") val documentNumber: String?,
    @SerializedName("email") val email: String?
)

data class PaymentCombinedSubMerchant(
    @SerializedName("identification_code") val identificationCode: String?,
    @SerializedName("gateway_id") val gatewayId: String?,
    @SerializedName("document_type") val documentType: String?,
    @SerializedName("document_number") val documentNumber: String?,
    @SerializedName("address") val address: String?,
    @SerializedName("city") val city: String?,
    @SerializedName("state") val state: String?,
    @SerializedName("postal_code") val postalCode: String?,
    @SerializedName("district") val district: String?,
    @SerializedName("country_code") val countryCode: String?,
    @SerializedName("address_number") val addressNumber: String?,
    @SerializedName("address_complement") val addressComplement: String?,
    @SerializedName("acceptor") val acceptor: PaymentCombinedAcceptor?,
    @SerializedName("business_name") val businessName: String?,
    @SerializedName("foreign_type") val foreignType: String?,
    @SerializedName("number") val number: String?,
    @SerializedName("complement") val complement: String?
)

data class PaymentCombinedAcceptor(
    @SerializedName("url_address") val urlAddress: String?,
    @SerializedName("customer_service_phone_number") val customerServicePhoneNumber: String?,
    @SerializedName("phone_number") val phoneNumber: String?,
    @SerializedName("additional_contact") val additionalContact: String?,
    @SerializedName("tax_id") val taxId: String?
)