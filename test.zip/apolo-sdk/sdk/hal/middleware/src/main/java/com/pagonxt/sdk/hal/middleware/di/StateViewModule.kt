package com.pagonxt.sdk.hal.middleware.di

import com.pagonxt.sdk.hal.middleware.stateview.AidTableStateView
import com.pagonxt.sdk.hal.middleware.stateview.GenerateTokenStateView
import com.pagonxt.sdk.hal.middleware.stateview.PaymentCombinedStateView
import com.pagonxt.sdk.hal.middleware.stateview.PaymentStateView
import org.koin.dsl.module

internal fun stateViewModule() = module {
    single { AidTableStateView(get()) }
    single { GenerateTokenStateView(get()) }
    single { PaymentCombinedStateView(get()) }
    single { PaymentStateView(get()) }
}