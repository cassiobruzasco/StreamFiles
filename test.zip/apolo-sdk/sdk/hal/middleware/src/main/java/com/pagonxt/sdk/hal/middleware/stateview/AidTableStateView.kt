package com.pagonxt.sdk.hal.middleware.stateview

import com.pagonxt.sdk.hal.middleware.domain.usecase.AidTableState
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetAidTableUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AidTableStateView internal constructor(
    private val useCase: GetAidTableUseCase,
) {
    private val aidState = MutableStateFlow<AidTableState>(AidTableState.Loading)
    val aidStateView: StateFlow<AidTableState> = aidState

    fun fetchAidTable() {
        CoroutineScope(Dispatchers.IO).launch {
            useCase.invoke().collect { state ->
                aidState.emit(state)
            }
        }
    }
}