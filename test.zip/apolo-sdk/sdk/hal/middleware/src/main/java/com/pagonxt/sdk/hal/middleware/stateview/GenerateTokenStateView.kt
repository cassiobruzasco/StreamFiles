package com.pagonxt.sdk.hal.middleware.stateview

import com.pagonxt.sdk.hal.middleware.domain.usecase.GenerateTokenState
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostGenerateTokenUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Bridges the token-generation use-case with the engine.
 *
 * Uses [SharedFlow] with replay=0 — no stale results replayed between transactions.
 */
class GenerateTokenStateView internal constructor(
    private val useCase: PostGenerateTokenUseCase
) {
    private val _generateTokenState = MutableSharedFlow<GenerateTokenState>(
        replay = 0,
        extraBufferCapacity = 1
    )

    val generateTokenStateView: SharedFlow<GenerateTokenState> = _generateTokenState.asSharedFlow()

    fun generateToken() {
        CoroutineScope(Dispatchers.IO).launch {
            useCase.invoke().collect { state ->
                _generateTokenState.emit(state)
            }
        }
    }
}