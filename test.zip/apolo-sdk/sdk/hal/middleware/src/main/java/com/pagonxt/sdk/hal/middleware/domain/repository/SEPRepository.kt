package com.pagonxt.sdk.hal.middleware.domain.repository

import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedRequestBody
import com.pagonxt.sdk.hal.middleware.data.request.PaymentRequestBody
import com.pagonxt.sdk.hal.middleware.data.response.AuthResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentCombinedResponse
import com.pagonxt.sdk.hal.middleware.data.response.PaymentResponse
import retrofit2.Response

interface SEPRepository {
    suspend fun postGenerateToken(): Response<AuthResponse>
    suspend fun postPaymentCombined(requestBody: PaymentCombinedRequestBody): Response<PaymentCombinedResponse>
    suspend fun postPayment(requestBody: PaymentRequestBody): Response<PaymentResponse>
}