package com.pagonxt.sdk.hal.middleware.data.response

import com.google.gson.annotations.SerializedName

data class TerminalTableResponse(
    @SerializedName("VERSAO") val version: String,
    @SerializedName("ESTAB") val establishment: String,
    @SerializedName("CNPJ") val cnpj: String,
    @SerializedName("SENHA_TECN") val technicianPassword: String,
    @SerializedName("CRIPTO") val crypto: String,
    @SerializedName("WK") val workingKey: String,
    @SerializedName("MK_INDEX") val masterKeyIndex: String,
    @SerializedName("SMID") val smid: String,
    @SerializedName("NII") val nii: String,
    @SerializedName("DISC_PERFIL") val profile: String,
    @SerializedName("TAM_CABEC") val tamHeader: String,
    @SerializedName("CABEC") val header: String,
    @SerializedName("TAM_RZ_SOCIAL") val tamCorporateName: String,
    @SerializedName("RZ_SOCIAL") val corporateName: String,
    @SerializedName("TAM_MERCHANT_CITY") val tamMerchantCity: String,
    @SerializedName("MERCHANT_CITY") val merchantCity: String,
    @SerializedName("TAM_MERCHANT_NAME") val tamMerchantName: String,
    @SerializedName("MERCHANT_NAME") val merchantName: String,
    @SerializedName("PAIS_CODIGO") val countryCode: String,
    @SerializedName("FUSO") val timeZone: String,
    @SerializedName("FUSO_SINAL") val timeZoneSignal: String,
    @SerializedName("HVERAO_DIF") val summerTimeDifference: String,
    @SerializedName("HVERAO_INI") val summerTimeStart: String,
    @SerializedName("HVERAO_FIM") val summerTimeEnd: String,
    @SerializedName("OPCAO1") val option1: String,
    @SerializedName("OPCAO2") val option2: String,
    @SerializedName("DUKPT_INDEX") val dukptIndex: String,
    @SerializedName("INIC_NII") val configNii: String,
    @SerializedName("QRCODE_TIMEOUT") val qrcodeTimeout: String,
    @SerializedName("QRCODE_NII") val qrcodeNii: String,
    @SerializedName("MERCHANT_CATEGORY_CODE") val merchantCategoryCode: String,
    @SerializedName("PIX_TIMEOUT") val pixTimeout: String,
    @SerializedName("PIX_NII") val pixNii: String
)