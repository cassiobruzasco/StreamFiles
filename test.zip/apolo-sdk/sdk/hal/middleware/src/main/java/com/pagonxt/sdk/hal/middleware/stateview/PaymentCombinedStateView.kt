package com.pagonxt.sdk.hal.middleware.stateview

import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedBillingAddress
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedCard
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedData
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedPayment
import com.pagonxt.sdk.hal.middleware.data.request.PaymentCombinedRequestBody
import com.pagonxt.sdk.hal.middleware.domain.usecase.PaymentCombinedState
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostPaymentCombinedUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PaymentCombinedStateView internal constructor(
    private val useCase: PostPaymentCombinedUseCase
) {
    private val paymentCombinedState =
        MutableStateFlow<PaymentCombinedState>(PaymentCombinedState.Loading)
    val paymentCombinedStateView: StateFlow<PaymentCombinedState> = paymentCombinedState

    fun postPaymentCombined(
        requestBody: PaymentCombinedRequestBody? = null
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            useCase.invoke(
                requestBody = getPaymentCombined()
            ).collect { state ->
                paymentCombinedState.emit(state)
            }
        }
    }


    private fun getPaymentCombined() =
        PaymentCombinedRequestBody(
            additionalData = null, // Not used at root in your JSON
            requestId = "6d46a121-a4c6-4deb-890e-0bf816837c19",
            orderId = "f62f162b-3d4e-4a6d-832b-bcc0b4ff25fd",
            data = PaymentCombinedData(
                amount = 11000L,
                currency = "CLP",
                customerId = "marcos_13",
                payments = listOf(
                    PaymentCombinedPayment(
                        amount = 5500L,
                        idempotencyKey = "83a97339-96c1-44ec-a9e0-aa6973f4cce9",
                        paymentId = "13b623f0-5971-4923-950a-7ba1610672af",
                        saveCardData = false,
//                        orderId = "test_order_id_1",
                        paymentMethod = "CREDIT",
                        transactionType = "FULL",
                        numberInstallments = 1,
                        dynamicMcc = "1234",
                        card = PaymentCombinedCard(
                            number = "4025240000000943",
                            expirationMonth = "10",
                            expirationYear = "28",
                            entryMode = "chip",
                            emv = "9f2701809f3303e0f8c8950580000080009f37045d21705a9f100706010a03a0b8089f2608819ba36f3f7934149f360205b782021c009c01009f1a0204849a032002279f02060000000309605F2A0200325f3401019f34031e03009f120c56495341204352454449544f5f201a2f435249535449414e2047414c494e444f2043484156455a2020",
                            track2 = "4025240000000943=281028102800006930",
                            cardholderName = null,
                            securityCode = null,
                            brand = null,
                            numberToken = null,
                            seqNumber = null,
                            pinBlock = null,
                            pinKeyId = null,
                            ksn = null,
                            aid = null,
                            cardholderVerificationMethod = null,
                            aggregator = null,
                            serviceCode = null,
                            track1 = null
                        ),
                        billingAddress = PaymentCombinedBillingAddress(
                            street = "R a",
                            number = "1",
                            district = "B",
                            city = "City Z",
                            state = "SP",
                            country = "Brazil",
                            postalCode = "05781000",
                            complement = "NA",
                            type = "RES"
                        ),
                        softDescriptor = null,
                        tokenization = null,
                        wallet = null,
                        xid = null,
                        ucaf = null,
                        eci = null,
                        tdsdsxid = null,
                        tdsver = null,
                        isPrePaid = null,
                        networkToken = null,
                        paymentTag = null,
                        installment = null,
                        crossBorderData = null
                    ),
                    PaymentCombinedPayment(
                        amount = 5500L,
                        idempotencyKey = "41ab2730-9f38-4216-9d8d-e14435e64795",
                        paymentId = "19366e05-2cfc-43db-866d-8a48f243a3e5",
                        saveCardData = false,
//                        orderId = "test_order_id_2",
                        paymentMethod = "DEBIT",
                        transactionType = "FULL",
                        numberInstallments = 1,
                        dynamicMcc = "1234",
                        card = PaymentCombinedCard(
                            number = "4025240000000943",
                            expirationMonth = "10",
                            expirationYear = "28",
                            entryMode = "chip",
                            emv = "9f2701809f3303e0f8c8950580000080009f37045d21705a9f100706010a03a0b8089f2608819ba36f3f7934149f360205b782021c009c01009f1a0204849a032002279f02060000000309605F2A0200325f3401019f34031e03009f120c56495341204352454449544f5f201a2f435249535449414e2047414c494e444f2043484156455a2020",
                            track2 = "4025240000000943=281028102800006930",
                            cardholderName = null,
                            securityCode = null,
                            brand = null,
                            numberToken = null,
                            seqNumber = null,
                            pinBlock = null,
                            pinKeyId = null,
                            ksn = null,
                            aid = null,
                            cardholderVerificationMethod = null,
                            aggregator = null,
                            serviceCode = null,
                            track1 = null
                        ),
                        billingAddress = PaymentCombinedBillingAddress(
                            street = "R a",
                            number = "1",
                            district = "B",
                            city = "City Z",
                            state = "SP",
                            country = "Brazil",
                            postalCode = "05781000",
                            complement = "NA",
                            type = "RES"
                        ),
                        softDescriptor = null,
                        tokenization = null,
                        wallet = null,
                        xid = null,
                        ucaf = null,
                        eci = null,
                        tdsdsxid = null,
                        tdsver = null,
                        isPrePaid = null,
                        networkToken = null,
                        paymentTag = null,
                        installment = null,
                        crossBorderData = null
                    )
                ),
                subMerchant = null,
                additionalData = mapOf(
                    "device" to mapOf(
                        "device_id" to "id",
                        "ip_address" to "127.0.0.0"
                    ),
                    "customer" to mapOf(
                        "document_type" to "RUT",
                        "document_number" to "02441356709",
                        "email" to "aceitei@getnet.com.br",
                        "name" to "Jose da Silva",
                        "phone_number" to "11999999999",
                        "shippings" to mapOf(
                            "address" to mapOf(
                                "street" to "R B",
                                "number" to "2",
                                "district" to "X",
                                "city" to "Oros",
                                "state" to "CE",
                                "country" to "Brazil",
                                "postal_code" to "63520000",
                                "complement" to "NA",
                                "type" to "R"
                            ),
                            "name" to "Jose da Silva",
                            "phone_number" to "11999999999"
                        )
                    ),
                    "order" to mapOf(
                        "items" to listOf(
                            mapOf(
                                "id" to "101803",
                                "name" to "COPO TERMICO 473ML PRETO STANLEY",
                                "price" to 139.9,
                                "quantity" to 1,
                                "discount" to 0.0,
                                "deliveryType" to "PAC",
                                "categoryId" to "913",
                                "sellerId" to "MSC002",
                                "taxValue" to 0.00,
                                "taxRate" to 0.0
                            )
                        )
                    )
                )
            ),
            encryptedData = null
        )
}