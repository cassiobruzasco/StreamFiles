package com.pagonxt.sdk.hal.middleware.domain.constant

object TransactionConst {
    const val DUKPT_SLOT_INVALID = -1
}