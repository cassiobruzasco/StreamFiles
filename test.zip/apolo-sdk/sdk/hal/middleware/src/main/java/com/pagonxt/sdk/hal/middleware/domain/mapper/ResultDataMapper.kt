package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.hal.emvKernel.ResultData
import com.pagonxt.hal.utils.byteArray.toHex
import com.pagonxt.hal.utils.tlv.toByteArray
import com.pagonxt.sdk.hal.middleware.domain.model.ResultDataModel

class ResultDataMapper {
    fun getResultData(data: ResultData?): ResultDataModel? =
        data?.let {
            ResultDataModel(
                approved = it.approved,
                cryptogramFirst = it.cryptogramFirst,
                cryptogramSecond = it.cryptogramSecond,
                issuerScriptResult = it.issuerScriptResult,
                responseCode = it.responseCode,
                tagsEmv = it.tlvs?.toByteArray()?.toHex()
            )
        } ?: run {
            null
        }
}