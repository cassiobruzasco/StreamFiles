package com.pagonxt.sdk.hal.middleware.domain.model

data class ResultDataModel(
    val approved: Boolean,
    val cryptogramFirst: String,
    val cryptogramSecond: String?,
    val issuerScriptResult: String?,
    val responseCode: String,
    val tagsEmv: String?
)