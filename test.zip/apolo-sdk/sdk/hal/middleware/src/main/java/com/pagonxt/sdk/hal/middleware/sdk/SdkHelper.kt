package com.pagonxt.sdk.hal.middleware.sdk

import android.util.Log
import com.getnet.posdigital.info.InfoResponse
import com.pagonxt.sdk.hal.middleware.domain.platform.PlatformManager
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetSdkInfoUseCaseState
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetSdkUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetSdkUseCaseState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SdkHelper(
    private val platformManager: PlatformManager,
    private val useCase: GetSdkUseCase,
    /**
     * Called once the PlatformService is successfully bound and [PlatformManager.isReady].
     * Inject country-specific setup here (e.g. BrPlatformManager.setUpEMVParameters).
     * Defaults to no-op so non-Brazil flavors don't need to provide it.
     */
    private val onPlatformBound: (() -> Unit)? = null,
) {
    companion object {
        // TODO: Is correct to use infoResponse here or should be handled inside the use case and exposed through a StateFlow or similar approach?
        // TODO: or Should storage on shared preferences or database be considered for storing the infoResponse data?
        var infoResponse: InfoResponse? = null
        val TAG: String = SdkHelper::class.java.simpleName
    }

    fun connectSdk() {
        CoroutineScope(Dispatchers.Main).launch {
            useCase.connectSdk().collect { state ->
                when (state) {
                    GetSdkUseCaseState.Loading -> {
                        /**
                         * Do nothing
                         */
                    }

                    GetSdkUseCaseState.OnConnected -> {
                        Log.d(TAG, "connectPosDigitalService - onConnected")
                        getInfoSdk()
                        with(platformManager) {
                            bindPlatformServiceIfNeeded { isBound ->
                                if (isBound) {
                                    Log.d(TAG, "connectPosDigitalService - platform bound, calling onPlatformBound")
                                    onPlatformBound?.invoke()
                                } else {
                                    // Retry once if the first attempt failed.
                                    bindPlatformServiceIfNeeded { retryBound ->
                                        if (retryBound) onPlatformBound?.invoke()
                                        Log.d(TAG, "connectPosDigitalService - bindPlatformServiceIfNeeded retry: $retryBound")
                                    }
                                }
                                Log.d(TAG, "connectPosDigitalService - bindPlatformServiceIfNeeded: $isBound")
                            }
                        }
                    }

                    is GetSdkUseCaseState.OnError -> {
                        Log.e(TAG, "connectPosDigitalService - onError: $state")
                    }

                    GetSdkUseCaseState.OnDisconnected -> {
                        Log.d(TAG, "connectPosDigitalService - service SDK OnDisconnected")
                    }
                }
            }
        }
    }

    private fun getInfoSdk() {
        CoroutineScope(Dispatchers.Main).launch {
            useCase.getInfoSdk().collect { state ->
                when (state) {
                    is GetSdkInfoUseCaseState.OnInfo -> {
                        Log.d(TAG, "infoPosDigitalService - onInfo(): ${state.data}")
                        infoResponse = state.data
                    }

                    is GetSdkInfoUseCaseState.OnError -> {
                        Log.d(TAG, "infoPosDigitalService - OnError(): $state")
                    }

                    GetSdkInfoUseCaseState.Loading -> {
                        /**
                         * Do nothing
                         */
                    }
                }
            }
        }
    }

    fun disconnectSdk() {
        CoroutineScope(Dispatchers.Main).launch {
            useCase.disconnectSdk().collect { state ->
                when (state) {
                    GetSdkUseCaseState.Loading -> {
                        /**
                         * Do nothing
                         */
                    }

                    GetSdkUseCaseState.OnDisconnected -> {
                        Log.d(TAG, "disconnectPosDigitalService - OnDisconnected")
                    }

                    is GetSdkUseCaseState.OnError -> {
                        Log.d(TAG, "disconnectPosDigitalService - OnError: $state")
                    }

                    else -> {
                        /**
                         * Do nothing
                         */
                    }
                }
            }
        }
    }
}