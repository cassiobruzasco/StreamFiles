package com.pagonxt.sdk.hal.middleware.data.response

import com.google.gson.annotations.SerializedName

data class AidTableResponse(
    @SerializedName("ADD_TERMCAP") val terminalCapabilityAdditional: String,
    @SerializedName("CODIGO") val code: String,
    @SerializedName("CTLSS_AMOUNTNUL") val amountNullContactless: String,
    @SerializedName("CTLSS_APPSUPPORT") val appSupportContactless: String,
    @SerializedName("CTLSS_CVMREQ") val requestCVMContactless: String,
    @SerializedName("CTLSS_FLOOR") val floorContactless: String,
    @SerializedName("CTLSS_MSTRIPE_VRS") val magStripeVRSContactless: String,
    @SerializedName("CTLSS_TAC_DEFAULT") val terminalActionCodeDefaultContactless: String,
    @SerializedName("CTLSS_TAC_DENIAL") val terminalActionCodeDenialContactless: String,
    @SerializedName("CTLSS_TAC_ONLINE") val terminalActionCodeOnlineContactless: String,
    @SerializedName("CTLSS_TRNLIMIT") val transactionLimitContactless: String,
    @SerializedName("DDOL") val ddol: String,
    @SerializedName("FLOOR") val floor: String,
    @SerializedName("MAX_PERC") val maxPercentage: String,
    @SerializedName("MERCH_CATEGORY") val merchantCategoryCode: String,
    @SerializedName("OPCAO1") val option1: String,
    @SerializedName("PRODUTO") val product: String,
    @SerializedName("TAC_DEFAULT") val terminalActionCodeDefault: String,
    @SerializedName("TAC_DENIAL") val terminalActionCodeDenial: String,
    @SerializedName("TAC_ONLINE") val terminalActionCodeOnline: String,
    @SerializedName("TAGS") val tags: String,
    @SerializedName("TAM_CODIGO") val tamCode: String,
    @SerializedName("TAM_TAGS") val tamTags: String,
    @SerializedName("TARGET_PERC") val targetPercentage: String,
    @SerializedName("TCC") val transactionCategoryCode: String,
    @SerializedName("TDOL") val tdol: String,
    @SerializedName("TERM_CAP") val terminalCapability: String,
    @SerializedName("THRESHOLD") val threshold: String,
    @SerializedName("TIPO") val type: String,
    @SerializedName("VERSAO1") val version1: String,
    @SerializedName("VERSAO2") val version2: String,
    @SerializedName("VERSAO3") val version3: String
)
