package com.pagonxt.sdk.hal.middleware.domain.platform

import android.content.Context
import android.util.Log
import com.pagonxt.hal.PlatformService
import com.pagonxt.hal.emvKernel.Risk
import com.pagonxt.hal.emvService.IEMVInterface
import com.pagonxt.hal.encryption.IEncryptionInterface
import com.pagonxt.sdk.hal.middleware.domain.broadcast.PlatformPackageBroadcastReceiver
import com.pagonxt.sdk.hal.middleware.domain.constant.PlatformManagerConst.BIND_PLATFORM_ATTEMPTS
import com.pagonxt.sdk.hal.middleware.domain.constant.PlatformManagerConst.BIND_PLATFORM_DELAY_DURATION
import com.pagonxt.sdk.hal.middleware.domain.constant.TransactionConst.DUKPT_SLOT_INVALID
import com.pagonxt.sdk.hal.middleware.domain.extension.toCAKey
import com.pagonxt.sdk.hal.middleware.domain.extension.toTerminal
import com.pagonxt.sdk.hal.middleware.domain.model.AidTableModel
import com.pagonxt.sdk.hal.middleware.domain.model.PublicKeyTableModel
import com.pagonxt.sdk.hal.middleware.domain.model.TerminalTableModel
import com.pagonxt.sdk.hal.middleware.domain.usecase.AidTableState
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetAidTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetPublicKeyTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetTerminalTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.PublicKeyTableState
import com.pagonxt.sdk.hal.middleware.domain.usecase.TerminalTableState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlatformManager internal constructor(
    private val context: Context,
    private val aidTableUseCase: GetAidTableUseCase,
    private val publicKeyTableUseCase: GetPublicKeyTableUseCase,
    private val terminalTableUseCase: GetTerminalTableUseCase,
    private val platformPackageBroadcastReceiver: PlatformPackageBroadcastReceiver
) {
    companion object {
        private val TAG = PlatformManager::class.simpleName
    }

    init {
        Log.d(TAG, "PlatformManager instance created: ${this.hashCode()}")
    }

    private val platformService: PlatformService = PlatformService

    private var encryptionService: IEncryptionInterface? = null

    private var isEmvParametersDefined: Boolean = false

    private var aidTable: List<AidTableModel> = emptyList()

    var emvService: IEMVInterface? = null

    val isBound: Boolean
        get() = PlatformService.isBound

    val isReady: Boolean
        get() = isBound && emvService != null && !platformPackageBroadcastReceiver.hasPlatformChanged()

    fun bindPlatformServiceIfNeeded(
        onCompletion: ((Boolean) -> Unit)? = null
    ) {
        if (isReady) {
            Log.d(TAG, "BindPlatformServiceIfNeeded skipped.")
            onCompletion?.invoke(true)
            return
        }

        CoroutineScope(Dispatchers.Default).launch {
            platformService.bind(context)

            var checkBound = 1
            while (!isBound && checkBound <= BIND_PLATFORM_ATTEMPTS) {
                Log.d(TAG, "Waiting to bind to PlatformService. try ($checkBound).")
                checkBound++
                delay(BIND_PLATFORM_DELAY_DURATION)
            }

            if (isBound) {
                Log.d(TAG, "PlatformService Bounded: $isBound.")
                emvService = platformService.getEMV()
                Log.d(TAG, "emvService set: $emvService")
                Log.d(TAG, "CardReaderGlobal registered as EMV event listener.")
                encryptionService = platformService.getEncryption()
                platformPackageBroadcastReceiver.resetPlatformFlag()
                isEmvParametersDefined = false
            } else {
                Log.e(
                    TAG,
                    "Failed to bind to PlatformService after $BIND_PLATFORM_ATTEMPTS attempts."
                )
                onCompletion?.invoke(false)
            }
        }
    }

    /**
     * EMV Service
     */
    fun setupEMVParameters(
        onCompletion: ((Boolean) -> Unit)?,
        setAIDParameter: (List<AidTableModel>) -> Unit
    ) {
        if (isEmvParametersDefined || !isReady) {
            Log.d(
                TAG,
                "setUpEMVParameters skipped: isEmvParametersDefined: $isEmvParametersDefined, isReady: $isReady."
            )
            onCompletion?.invoke(isBound)
            return
        }
        isEmvParametersDefined = true
        reset()
        CoroutineScope(Dispatchers.IO).launch {
            terminalTableUseCase.invoke().collect { state ->
                when (state) {
                    is TerminalTableState.Success -> {
                        setTerminal(state.data)
                    }

                    is TerminalTableState.Error -> {
                        Log.e(TAG, "Error fetching Terminal Table: ${state.message}")
                    }

                    TerminalTableState.Loading -> {}
                }
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            aidTableUseCase.invoke().collect { state ->
                when (state) {
                    is AidTableState.Success -> {
                        setAIDParameter(state.data)
                        aidTable = state.data
                    }

                    is AidTableState.Error -> {
                        Log.e(TAG, "Error fetching AID Table: ${state.message}")
                    }

                    AidTableState.Loading -> {}
                }
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            publicKeyTableUseCase.invoke().collect { state ->
                when (state) {
                    is PublicKeyTableState.Success -> {
                        setCAKey(state.data)
                    }

                    is PublicKeyTableState.Error -> {
                        Log.e(TAG, "Error fetching Public Key Table: ${state.message}")
                    }

                    PublicKeyTableState.Loading -> {}
                }
            }
        }
        // TODO: Where need to call this methods?
        // setRevoked()
        // setTLV()
        onCompletion?.invoke(isBound)
    }

    fun reset() {
        emvService?.apply {
            reset()
        } ?: run {
            Log.d(TAG, "Error on 'reset' method, emvService is null.")
        }
    }

    private fun setTerminal(terminal: TerminalTableModel? = null) {
        emvService?.apply {
            terminal?.let {
                setTerminal(it.toTerminal())
            }
        } ?: run {
            Log.d(TAG, "Error on 'setTerminal' method, emvService is null.")
        }
    }

    private fun setCAKey(caKeysCustomList: List<PublicKeyTableModel>? = null) {
        emvService?.apply {
            caKeysCustomList
                ?.map { it.toCAKey() }
                ?.let { caKeys -> setCAKey(caKeys) }
        } ?: run {
            Log.d(TAG, "Error on 'setCaKeys' method, emvService is null.")
        }
    }

    fun setRiskManagement(aidSelected: String) {
        aidTable.firstOrNull { it.code.uppercase() == aidSelected.uppercase() }
            ?.let { aidModel ->
                emvService?.apply {
                    /**
                     * @param thresholdValue Transaction amount threshold below which risk checks apply. Used for velocity checking.
                     * @param targetPercentage The % of transactions below the threshold that aew allowed to go offline
                     * @param maximumTargetPercentage Hard limit on offline approvals, even within target % logic
                     *
                     * If you want to force all transactions to go online:
                     * @param thresholdValue = 0L
                     * @param targetPercentage = 0
                     * @param maximumTargetPercentage = 0
                     */
                    Risk(
                        thresholdValue = aidModel.threshold.toLong(),
                        targetPercentage = aidModel.targetPercentage.toInt(),
                        maximumTargetPercentage = aidModel.maxPercentage.toInt()
                    ).let {
                        setRiskManagement(it)
                    }
                } ?: run {
                    Log.e(TAG, "Error on 'setRiskManagement' method, emvService is null.")
                }
            } ?: run {
            Log.e(TAG, "Error on 'setRiskManagement' method, AID not found.")
        }
    }

    fun cancel() {
        emvService?.apply {
            cancel()
        } ?: run {
            Log.d(TAG, "Error on 'cancel' method, emvService is null.")
        }
    }

    /**
     * Encryption Service
     */
    fun getDUKPTPosition(
        slotToFindDUKPT: Int,
        tryAnotherSlotIfNotFind: Int? = null
    ) =
        when {
            /** Search for the DUKPT key in slot 3 first */
            encryptionService?.getKSNbyPosition(slotToFindDUKPT)
                ?.isNotEmpty() == true -> slotToFindDUKPT
            /** Search for the DUKPT key in slot 2 if not found in slot 3 */
            tryAnotherSlotIfNotFind != null &&
                    encryptionService?.getKSNbyPosition(tryAnotherSlotIfNotFind)
                        ?.isNotEmpty() == true -> tryAnotherSlotIfNotFind
            /** If neither key is found, return -1 to indicate an error */
            else -> DUKPT_SLOT_INVALID
        }

    fun registerPlatform() {
        platformPackageBroadcastReceiver.registerReceiver(context)
    }

    fun unregisterPlatform() {
        platformPackageBroadcastReceiver.unregisterReceiver(context)
    }

    fun unbindPlatform() {
        if (!isBound) {
            Log.d(TAG, "unbindPlatform skipped: PlatformService not bound.")
            return
        }
        try {
            platformService.unbind(context)
        } catch (e: IllegalArgumentException) {
            Log.e(TAG, "Error unbinding service: ${e.message}")
        }
    }
}