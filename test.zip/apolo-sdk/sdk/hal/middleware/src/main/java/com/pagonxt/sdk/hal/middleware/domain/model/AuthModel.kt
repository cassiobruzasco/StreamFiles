package com.pagonxt.sdk.hal.middleware.domain.model

data class AuthModel(
    val authorization: String,
    val scope: String,
    val expiresIn: Int
)