package com.pagonxt.sdk.hal.middleware.di

import android.content.Context
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.DUMMY_API_NAMED_QUALIFIER
import com.pagonxt.sdk.hal.middleware.data.constant.NamedQualifierConst.OTHER_API_NAMED_QUALIFIER
import com.pagonxt.sdk.hal.middleware.data.repository.SdkRepositoryImpl
import com.pagonxt.sdk.hal.middleware.data.repository.RepositoryImpl
import com.pagonxt.sdk.hal.middleware.domain.repository.SdkRepository
import com.pagonxt.sdk.hal.middleware.domain.repository.SEPRepository
import com.pagonxt.sdk.hal.middleware.domain.repository.TransactionRepository
import org.koin.core.qualifier.named
import org.koin.dsl.module

internal fun repositoryModule(context: Context) = module {
    single<TransactionRepository> {
        RepositoryImpl(
            get(named(DUMMY_API_NAMED_QUALIFIER)),
            context,
            get()
        )
    }

    single<SEPRepository> {
        RepositoryImpl(
            get(named(OTHER_API_NAMED_QUALIFIER)),
            context,
            get()
        )
    }

    single<SdkRepository> {
        SdkRepositoryImpl(
            context
        )
    }
}