package com.pagonxt.sdk.hal.middleware.di

import com.pagonxt.sdk.hal.middleware.domain.usecase.GetAidTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetPublicKeyTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetSdkUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.GetTerminalTableUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostGenerateTokenUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostPaymentCombinedUseCase
import com.pagonxt.sdk.hal.middleware.domain.usecase.PostPaymentUseCase
import kotlinx.coroutines.Dispatchers
import org.koin.dsl.module

internal fun useCaseModule() = module {
    single { GetAidTableUseCase(get(), get(), Dispatchers.IO) }
    single { GetPublicKeyTableUseCase(get(), get(), Dispatchers.IO) }
    single { GetTerminalTableUseCase(get(), get(), Dispatchers.IO) }
    single { PostPaymentCombinedUseCase(get(), get(), Dispatchers.IO) }
    single { PostGenerateTokenUseCase(get(), get(), Dispatchers.IO) }
    single { PostPaymentUseCase(get(), get(), Dispatchers.IO) }
    single { GetSdkUseCase(get(), Dispatchers.IO) }
}