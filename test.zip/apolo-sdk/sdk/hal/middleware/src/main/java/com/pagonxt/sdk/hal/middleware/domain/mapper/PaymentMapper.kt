package com.pagonxt.sdk.hal.middleware.domain.mapper

import com.pagonxt.sdk.hal.middleware.data.response.PaymentResponse
import com.pagonxt.sdk.hal.middleware.domain.model.PaymentModel

class PaymentMapper {
    internal fun getPayment(response: PaymentResponse): PaymentModel = PaymentModel(
        sellerId = response.sellerId,
        paymentId = response.paymentId,
        orderId = response.orderId,
        amount = response.amount,
        currency = response.currency,
        status = response.status,
        paymentMethod = response.paymentMethod,
        receivedAt = response.receivedAt,
        transactionId = response.transactionId,
        originalTransactionId = response.originalTransactionId,
        authorizedAt = response.authorizedAt,
        reasonCode = response.reasonCode,
        reasonMessage = response.reasonMessage,
        acquirer = response.acquirer,
        softDescriptor = response.softDescriptor,
        authorizationCode = response.authorizationCode,
        acquirerTransactionId = response.acquirerTransactionId
    )
}