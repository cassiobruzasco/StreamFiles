package com.pagonxt.sdk.hal.middleware.domain.model

import com.pagonxt.sdk.hal.middleware.domain.enum.DecisionEnum

data class ProcessResultModel(
    val decision: DecisionEnum,
    val ksn: String?,
    val pinOffline: Boolean,
    val pinOnline: String?,
    val signature: Boolean,
    val tagsEmv: String
)