plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.maven.publish)
}

kotlin {
    jvmToolchain(rootProject.extra["jvmToolchainVersion"] as Int)
}

android {
    namespace = "com.pagonxt.sdk.hal.middleware"
    compileSdk {
        version = release(rootProject.extra["compileSdkVersion"] as Int)
    }

    defaultConfig {
        minSdk = rootProject.extra["minSdkVersion"] as Int

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    publishing {
        singleVariant("release") {
            withJavadocJar()
        }
    }
}

afterEvaluate {
    publishing {
        publications {
            create<MavenPublication>("release") {
                from(components["release"])

                groupId = "com.pagonxt.sdk"
                artifactId = "pagonxt-sdk-hal-middleware"
                version = "1.0.0-SNAPSHOT"
            }
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    //  Retrofit
    implementation(libs.com.squareup.retrofit)
    implementation(libs.com.squareup.retrofit.converter.gson)

    //  OkHttp
    implementation(libs.com.squareup.okhttp3.logging)

    //  Koin
    implementation(libs.koin.android)
    implementation(libs.koin.androidx.compose)

    //  New HAL
    // TODO: remove this local libs when upload to jfrog
    implementation(fileTree("libs"))
//    implementation(libs.middleware.libplatform.get().toString() + "@aar")
//    implementation(libs.middleware.libposdigital.get().toString() + "@aar")
    implementation(libs.middleware.utils.get().toString() + "@aar")
}