package com.pagonxt.sdk.common_utils.extensions

import java.math.BigDecimal
import java.math.RoundingMode

val Int.bd: BigDecimal get() = BigDecimal(this)
val Long.bd: BigDecimal get() = BigDecimal(this)
val Double.bd: BigDecimal get() = BigDecimal(this.toString()) // String para segurança!
val String.bd: BigDecimal get() = BigDecimal(this)

operator fun BigDecimal.plus(other: Int): BigDecimal = this.add(other.bd)
operator fun BigDecimal.minus(other: Int): BigDecimal = this.subtract(other.bd)
operator fun BigDecimal.times(other: Int): BigDecimal = this.multiply(other.bd)
operator fun BigDecimal.div(other: Int): BigDecimal = this.divide(other.bd, 2, RoundingMode.HALF_EVEN)

operator fun BigDecimal.plus(other: Double): BigDecimal = this.add(other.bd)
operator fun BigDecimal.minus(other: Double): BigDecimal = this.subtract(other.bd)
operator fun BigDecimal.times(other: Double): BigDecimal = this.multiply(other.bd)

operator fun BigDecimal.div(other: Double): BigDecimal = this.divide(other.bd, 2, RoundingMode.HALF_EVEN)


infix fun BigDecimal.percent(percentage: Number): BigDecimal {
    val percentValue = BigDecimal(percentage.toString())
    return this.multiply(percentValue)
        .divide(BigDecimal("100"), 2, RoundingMode.HALF_EVEN)
}

infix fun BigDecimal.plusPercent(percentage: Number): BigDecimal {
    return this.add(this percent percentage)
}

infix fun BigDecimal.minusPercent(percentage: Number): BigDecimal {
    return this.subtract(this percent percentage)
}