package com.pagonxt.sdk.common_utils.extensions

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Convert Long (cents) to BigDecimal (Currency unit) visual
 * Ex: 1250L -> 12.50 (To display on screen or calculate interest on full value)
 */
val Long.asMoney: BigDecimal
    get() = BigDecimal.valueOf(this).movePointLeft(2)

/**
 * Convert BigDecimal (Currency unit) to Long (cents)
 * Ex: 12.50 -> 1250L
 */
val BigDecimal.asCents: Long
    get() = this.movePointRight(2).setScale(0, RoundingMode.HALF_EVEN).toLong()

/**
 * Calculate percentage (%) over Long value (in cents), returning BigDecimal with exact value.
 * Useful when you need to keep precision, e.g., 10% of 155 cents is 15.5
 */
infix fun Long.percentExact(percent: Number): BigDecimal {
    return BigDecimal.valueOf(this)
        .multiply(BigDecimal(percent.toString()))
        .divide(BigDecimal("100"))
}

/**
 * Calculate percentage (%) over Long value (in cents), returning Long (cents) rounded.
 * Useful for final calculations where fractional cents do not exist.
 */
infix fun Long.percent(percent: Number): Long {
    return (this percentExact percent)
        .setScale(0, RoundingMode.HALF_EVEN)
        .toLong()
}

/**
 * Calculate what percentage (%) this Long value (in cents) is of the total Long value (in cents).
 * Returns BigDecimal with 2 decimal places.
 */
infix fun Long.percentageOf(total: Long): BigDecimal {
    if (total == 0L) return BigDecimal.ZERO
    return BigDecimal.valueOf(this)
        .multiply(BigDecimal("100"))
        .divide(BigDecimal.valueOf(total), 2, RoundingMode.HALF_EVEN)
}