package com.pagonxt.sdk.core.domain.models

/**
 * Base contract for all payment steps in the SDK.
 * By using an open interface, each country/flavor can define its own
 * sealed interfaces inheriting from this, allowing infinite extensibility.
 */
interface PaymentStep

/**
 * Common steps that are highly likely to be shared.
 */
sealed interface CorePaymentStep : PaymentStep {
    data object AmountEntry : CorePaymentStep
    data object ProductSelection : CorePaymentStep
    data object CardCapture : CorePaymentStep
    data object EmvProcessing : CorePaymentStep
    data object ReceiptPrinting : CorePaymentStep
    data object Finished : CorePaymentStep
}