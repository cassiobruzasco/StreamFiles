package com.pagonxt.sdk.core.presentation.mvi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Base ViewModel for all MVI screens in the SDK.
 * It abstracts away the boilerplate of handling One-Shot Effects (ViewEffect).
 */
abstract class BaseMviViewModel<Event : ViewEvent, State : ViewState, Effect : ViewEffect> :
    ViewModel(), MviContract<Event, State, Effect> {

    private val _effects = MutableSharedFlow<Effect>()
    override val effects: SharedFlow<Effect> = _effects.asSharedFlow()

    /**
     * Helper function to emit effects cleanly from child ViewModels
     * without needing to explicitly call [viewModelScope.launch { }] every time.
     */
    protected fun emitEffect(effect: Effect) {
        viewModelScope.launch {
            _effects.emit(effect)
        }
    }

    // Note: 'state' and 'processEvent' remain abstract (enforced by the interface)
    // because each screen defines its own reactive state and business rules.
}