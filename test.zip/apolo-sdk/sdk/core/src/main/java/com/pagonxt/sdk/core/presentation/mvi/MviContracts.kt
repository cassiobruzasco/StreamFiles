package com.pagonxt.sdk.core.presentation.mvi

import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharedFlow


/**
 * This is the immutable state of the screen.
 * The UI only observes and renders what it holds.
 */
interface ViewState

/**
 * This is the user actions that are allowed at the screen.
 * The UI sends these actions to the ViewModel.
 */
interface ViewEvent

/**
 * Represents one-shot triggers to be emitted and consumed.
 */
interface ViewEffect

/**
 * Base contract for all ViewModels.
 * Grants a unidirection data flow.
 */
interface MviContract<Event : ViewEvent, State : ViewState, Effect : ViewEffect> {
    val state: StateFlow<State>
    val effects: SharedFlow<Effect>
    fun processEvent(event: Event)
}