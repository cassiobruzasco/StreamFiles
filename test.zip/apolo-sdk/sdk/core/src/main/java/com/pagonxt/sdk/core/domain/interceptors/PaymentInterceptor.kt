package com.pagonxt.sdk.core.domain.interceptors

import com.pagonxt.sdk.core.domain.models.TransactionData

sealed interface InterceptorResult {
    data class Continue(val updatedData: TransactionData) : InterceptorResult
    data class Halt(val reasonCode: String, val message: String) : InterceptorResult
}

interface PaymentInterceptor {
    suspend fun intercept(transaction: TransactionData): InterceptorResult
}