package com.pagonxt.sdk.core.domain.repository

import com.pagonxt.sdk.core.domain.models.CardData
import com.pagonxt.sdk.core.domain.models.TransactionData
import kotlinx.coroutines.flow.StateFlow

/**
 * Base repository contract.
 * @param T The specific TransactionData implementation for the flavor.
 */
interface TransactionRepository<T : TransactionData> {
    val currentTransaction: StateFlow<T?>

    fun updateAmount(amountInCents: Long)
    fun recordCardData(cardData: CardData)
    fun clearTransaction()
}