package com.pagonxt.sdk.core.domain.usecases

import com.pagonxt.sdk.core.domain.models.CorePaymentStep
import com.pagonxt.sdk.core.domain.models.PaymentStep

/**
 * Base UseCase for determining the next payment step.
 * Uses the Template Method Pattern to enforce global SDK rules
 * while allowing flavor-specific customizations.
 */
abstract class GetNextPaymentStepUseCase {

    /**
     * The main entry point. This method is FINAL (by default in Kotlin)
     * or deliberately not overridden, enforcing our core locks.
     */
    operator fun invoke(currentStep: PaymentStep): PaymentStep {

        // --- CORE ENFORCEMENTS (BLOCKS) ---

        // Rule 1: Once the flow reaches Finished, it can NEVER escape Finished.
        if (currentStep is CorePaymentStep.Finished) {
            return CorePaymentStep.Finished
        }

        // --- FLAVOR-SPECIFIC EVALUATION ---

        val nextStep = evaluateNextStep(currentStep)

        // (Optional) Additional post-evaluation rules could be added here
        // e.g., preventing a direct jump from Receipt back to Amount.

        return nextStep
    }

    /**
     * Each flavor/country must implement this to define its specific flow logic.
     */
    protected abstract fun evaluateNextStep(currentStep: PaymentStep): PaymentStep
}