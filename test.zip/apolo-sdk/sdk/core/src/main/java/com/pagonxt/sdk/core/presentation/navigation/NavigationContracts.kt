package com.pagonxt.sdk.core.presentation.navigation

import androidx.compose.runtime.Composable
import kotlin.reflect.KClass

/**
 * Base interface for all Type-Safe routes in the SDK.
 */
interface SdkRoute

/**
 * Callback allowing a custom injected screen to return control to the SDK.
 */
typealias ResumeSdkFlowCallback = (nextSdkRouteInstance: SdkRoute) -> Unit

/**
 * A "Slot" representing a third party Compose screen injected into the SDK.
 */
typealias ExternalCustomScreen = @Composable (resumeFlow: ResumeSdkFlowCallback) -> Unit

/**
 * Interceptor rule engine. The client app evaluates the current and default next route,
 * and decides whether to hijack the flow and redirect to a custom route.
 */
interface SdkFlowInterceptor {
    fun overrideNextRoute(currentRoute: SdkRoute, defaultNextRoute: SdkRoute): SdkRoute
}

/**
 * Configuration payload provided by the host app upon SDK initialization.
 */
data class SdkUiNavigationConfig(
    val interceptor: SdkFlowInterceptor? = null,
    val customScreens: Map<KClass<out SdkRoute>, ExternalCustomScreen> = emptyMap()
)