package com.pagonxt.sdk.core.domain.models

/**
 * Base contract for transaction data.
 * Exposes only the universally required properties that any payment needs.
 */
interface TransactionData {
    val amountInCents: Long
    val cardData: CardData?
    val isReadyToCapture: Boolean
    val isCardCaptured: Boolean
}