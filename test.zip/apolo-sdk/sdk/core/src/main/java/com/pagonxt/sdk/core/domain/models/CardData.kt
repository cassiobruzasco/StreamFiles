package com.pagonxt.sdk.core.domain.models

data class CardData(
    val aid: String?,
    val applicationName: String,
    val cardholderName: String?,
    val expirationDate: String,
    val issuerCountryCode: String?,
    val labelName: String,
    // TODO: need to be internal?
    val pan: String,
    val serviceCode: String?,
    // TODO: need to be internal?
    val track1: String?,
    // TODO: need to be internal?
    val track2: String?,
    // TODO: need to be internal?
    val track3: String?,
    val type: CardType,
    val products: List<CardProducts>
) {
    val maskedPan: String
        get() = if (pan.length >= 10) {
            pan.take(6) + "*".repeat(pan.length - 10) + pan.takeLast(4)
        } else {
            "*".repeat(pan.length - 4) + pan.takeLast(4)
        }
}

sealed interface CardType {
    data object Magnetic : CardType
    data object Contact : CardType
    data object Contactless : CardType
    data object ContactlessMag : CardType
}

sealed interface CardProducts {
    data object Debit : CardProducts
    data object Credit : CardProducts
    data object Voucher : CardProducts
    data object Other : CardProducts
}