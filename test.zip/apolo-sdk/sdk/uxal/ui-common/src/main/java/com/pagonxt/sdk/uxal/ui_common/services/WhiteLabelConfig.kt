package com.pagonxt.sdk.uxal.ui_common.services

data class WhiteLabelConfig(
    val colorOverrides: Map<String, Long>,
    val textOverrides: Map<String, String>
)