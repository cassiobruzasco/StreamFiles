package com.pagonxt.sdk.uxal.ui_common.components

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

sealed interface KeypadEvent {
    data class Digit(val number: Int) : KeypadEvent
    data object Backspace : KeypadEvent
    data object CustomAction : KeypadEvent
}

data class ActionKeyConfig(
    val icon: ImageVector? = null,
    val label: String? = null,
    val color: Color = Color.Black
)

@Composable
fun Keypad(
    onKeyClick: (KeypadEvent) -> Unit,
    leftActionConfig: ActionKeyConfig? = null,
    rightActionConfig: ActionKeyConfig? = ActionKeyConfig(icon = Icons.AutoMirrored.Outlined.Backspace)
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        val keys = listOf(
            KeypadEvent.Digit(1), KeypadEvent.Digit(2), KeypadEvent.Digit(3),
            KeypadEvent.Digit(4), KeypadEvent.Digit(5), KeypadEvent.Digit(6),
            KeypadEvent.Digit(7), KeypadEvent.Digit(8), KeypadEvent.Digit(9),
            leftActionConfig, KeypadEvent.Digit(0), rightActionConfig
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .height(300.dp)
                .border(0.5.dp, Color(0xFFCBCBCB))
        ) {
            items(keys) { keyItem ->
                Box(
                    modifier = Modifier
                        .height(75.dp)
                        .border(width = 0.5.dp, color = Color(0xFFCBCBCB))
                        .clickable(enabled = keyItem != null) {
                            when (keyItem) {
                                is KeypadEvent -> onKeyClick(keyItem)
                                is ActionKeyConfig -> {
                                    if (keyItem.icon == Icons.AutoMirrored.Outlined.Backspace) {
                                        onKeyClick(KeypadEvent.Backspace)
                                    } else {
                                        onKeyClick(KeypadEvent.CustomAction)
                                    }
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    when (keyItem) {
                        is KeypadEvent.Digit -> {
                            Text(
                                text = keyItem.number.toString(),
                                fontSize = 28.sp,
                                color = Color.Black,
                                fontWeight = FontWeight.Normal
                            )
                        }
                        is ActionKeyConfig -> {
                            if (keyItem.icon != null) {
                                Icon(
                                    imageVector = keyItem.icon,
                                    contentDescription = keyItem.label,
                                    tint = keyItem.color,
                                    modifier = Modifier.height(28.dp)
                                )
                            } else if (keyItem.label != null) {
                                Text(
                                    text = keyItem.label,
                                    fontSize = 20.sp,
                                    color = keyItem.color,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewKeypad() {
    MaterialTheme {
        Keypad(onKeyClick = {})
    }
}