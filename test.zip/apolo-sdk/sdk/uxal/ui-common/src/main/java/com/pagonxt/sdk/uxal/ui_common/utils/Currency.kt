package com.pagonxt.sdk.uxal.ui_common.utils

import java.math.BigDecimal
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

/**
 * Returns the currency symbol for the native locale.
 */
fun Locale.getCurrencySymbol(): String {
    return Currency.getInstance(this).getSymbol(this)
}

/**
 * Transforms a Cents (Long) currency value into formatted string
 */
fun Long.toCurrencyString(locale: Locale): String {
    val numberFormat = NumberFormat.getCurrencyInstance(locale)
    val value = (this.toDouble() / 100).toBigDecimal()
    return numberFormat.format(value)
}

/**
 * Transforms Cents (Long) to String, ignoring currency symbol.
 */
fun Long.toAmountStringOnly(locale: Locale): String {
    val currency = Currency.getInstance(locale)
    val numberFormat = NumberFormat.getInstance(locale).apply {
        minimumFractionDigits = currency.defaultFractionDigits
        maximumFractionDigits = currency.defaultFractionDigits
    }
    val value = (this.toDouble() / 100).toBigDecimal()
    return numberFormat.format(value)
}

fun BigDecimal.toCurrencyString(locale: Locale): String {
    return NumberFormat.getCurrencyInstance(locale).format(this)
}