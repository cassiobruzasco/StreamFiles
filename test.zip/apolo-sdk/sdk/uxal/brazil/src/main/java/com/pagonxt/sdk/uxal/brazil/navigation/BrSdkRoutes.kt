package com.pagonxt.sdk.uxal.brazil.navigation

import com.pagonxt.sdk.core.presentation.navigation.SdkRoute
import kotlinx.serialization.Serializable

/**
 * Type-safe routes for the Brazil Sale Flow.
 */
@Serializable
sealed interface BrSdkRoutes : SdkRoute {
    @Serializable
    data object AmountAndProduct : BrSdkRoutes
    @Serializable
    data object CardReading : BrSdkRoutes
    @Serializable
    data object EmvProcessing : BrSdkRoutes
    @Serializable
    data object PaymentSuccess : BrSdkRoutes
}