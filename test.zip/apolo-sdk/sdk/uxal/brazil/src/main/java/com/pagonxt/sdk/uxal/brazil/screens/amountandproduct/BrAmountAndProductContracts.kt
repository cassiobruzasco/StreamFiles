package com.pagonxt.sdk.uxal.brazil.screens.amountandproduct

import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.core.presentation.mvi.ViewEffect
import com.pagonxt.sdk.core.presentation.mvi.ViewEvent
import com.pagonxt.sdk.core.presentation.mvi.ViewState

/**
 * Immutable state for the Amount and Product Selection screen.
 */
data class BrAmountAndProductViewState(
    val formattedAmount: String = "0.00",
    val isAmountValid: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val viewEffect: BrAmountAndProductViewEffect? = null,
) : ViewState

/**
 * User actions triggered from the UI.
 */
sealed interface BrAmountAndProductViewEvent : ViewEvent {
    data object OnBackClicked : BrAmountAndProductViewEvent
    data class OnPaymentMethodSelected(val method: BrSaleMethod) : BrAmountAndProductViewEvent
}

/**
 * One-shot navigation effects.
 */
sealed interface BrAmountAndProductViewEffect : ViewEffect {
    data object NavigateBack : BrAmountAndProductViewEffect
    data class NavigateToNextStep(val route: String) : BrAmountAndProductViewEffect
}