package com.pagonxt.sdk.uxal.brazil.screens.amountandproduct

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Pix
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrAmountAndProductSelection(
    state: BrAmountAndProductViewState,
    onEvent: (BrAmountAndProductViewEvent) -> Unit
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                title = { Text("Payment") },
                navigationIcon = {
                    IconButton(onClick = { onEvent(BrAmountAndProductViewEvent.OnBackClicked) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Amount Display
            Text(
                text = "Amount",
                fontSize = 16.sp,
                color = Color.Gray
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = state.formattedAmount,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Payment Methods Grid
            Text(
                text = "Select Payment Method",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PaymentMethodButton(
                    text = "Credit",
                    icon = Icons.Filled.CreditCard,
                    isEnabled = state.isAmountValid,
                    onTap = { onEvent(BrAmountAndProductViewEvent.OnPaymentMethodSelected(BrSaleMethod.CreditCard)) }
                )
                PaymentMethodButton(
                    text = "Debit",
                    icon = Icons.Filled.CreditCard,
                    isEnabled = state.isAmountValid,
                    onTap = { onEvent(BrAmountAndProductViewEvent.OnPaymentMethodSelected(BrSaleMethod.DebitCard)) }
                )
                PaymentMethodButton(
                    text = "Voucher",
                    icon = Icons.Filled.Money,
                    isEnabled = state.isAmountValid,
                    onTap = { onEvent(BrAmountAndProductViewEvent.OnPaymentMethodSelected(BrSaleMethod.Voucher)) }
                )
                PaymentMethodButton(
                    text = "Pix",
                    icon = Icons.Filled.Pix,
                    isEnabled = state.isAmountValid,
                    onTap = { onEvent(BrAmountAndProductViewEvent.OnPaymentMethodSelected(BrSaleMethod.Pix)) }
                )
            }
        }
    }
}

@Composable
private fun PaymentMethodButton(
    text: String,
    icon: ImageVector,
    isEnabled: Boolean,
    onTap: () -> Unit
) {
    val alpha = if (isEnabled) 1f else 0.5f

    Column(
        modifier = Modifier
            .size(80.dp)
            .border(1.dp, Color.LightGray.copy(alpha = alpha), RoundedCornerShape(12.dp))
            .background(Color.Transparent, RoundedCornerShape(12.dp))
            .clickable(enabled = isEnabled) { onTap() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = text,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = alpha),
            modifier = Modifier.size(32.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha)
        )
    }
}

@Preview(showBackground = true)
@Composable
private fun PreviewBrAmountAndProductSelection() {
    MaterialTheme {
        BrAmountAndProductSelection(
            state = BrAmountAndProductViewState(
                formattedAmount = "R$ 150.00",
                isAmountValid = true
            ),
            onEvent = {}
        )
    }
}