package com.pagonxt.sdk.uxal.brazil.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.core.presentation.mvi.BaseMviViewModel
import com.pagonxt.sdk.core.presentation.mvi.MviContract
import com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess.BrPaymentSuccessViewEffect
import com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess.BrPaymentSuccessViewEvent
import com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess.BrPaymentSuccessViewState
import com.pagonxt.sdk.uxal.ui_common.utils.toCurrencyString
import com.pagonxt.sdk.uxal.brazil.utils.BRAZIL_LOCALE
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BrPaymentSuccessViewModel(
    private val repository: BrTransactionRepository
) : BaseMviViewModel<BrPaymentSuccessViewEvent, BrPaymentSuccessViewState, BrPaymentSuccessViewEffect>() {

    private val _uiStateFlow = MutableStateFlow(BrPaymentSuccessViewState())

    private val _effects = MutableSharedFlow<BrPaymentSuccessViewEffect>()
    override val effects: SharedFlow<BrPaymentSuccessViewEffect> = _effects.asSharedFlow()

    override val state: StateFlow<BrPaymentSuccessViewState> = combine(
        _uiStateFlow,
        repository.currentTransaction
    ) { uiState, transaction ->
        uiState.copy(
            formattedAmount = (transaction?.amountInCents ?: 0).toCurrencyString(BRAZIL_LOCALE),
            paymentMethodName = mapPaymentMethodName(transaction?.params?.paymentMethod)
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = BrPaymentSuccessViewState()
    )

    override fun processEvent(event: BrPaymentSuccessViewEvent) {
        when (event) {
            is BrPaymentSuccessViewEvent.OnFinishClicked -> handleFinish()
        }
    }

    private fun handleFinish() {
        viewModelScope.launch {
            repository.clearTransaction()
            _effects.emit(BrPaymentSuccessViewEffect.NavigateToHome)
        }
    }

    private fun mapPaymentMethodName(method: BrSaleMethod?): String {
        return when (method) {
            is BrSaleMethod.CreditCard -> "Credit"
            is BrSaleMethod.DebitCard -> "Debit"
            is BrSaleMethod.Voucher -> "Voucher"
            is BrSaleMethod.Pix -> "Pix"
            else -> "Unknown"
        }
    }
}