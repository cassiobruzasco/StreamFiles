package com.pagonxt.sdk.uxal.brazil.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.pagonxt.sdk.core.presentation.navigation.SdkUiNavigationConfig
import com.pagonxt.sdk.uxal.brazil.screens.amountandproduct.BrAmountAndProductSelection
import com.pagonxt.sdk.uxal.brazil.screens.amountandproduct.BrAmountAndProductViewEffect
import com.pagonxt.sdk.uxal.brazil.screens.cardreading.BrCardReadingScreen
import com.pagonxt.sdk.uxal.brazil.screens.cardreading.BrCardReadingViewEffect
import com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess.BrPaymentSuccessScreen
import com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess.BrPaymentSuccessViewEffect
import com.pagonxt.sdk.uxal.brazil.viewmodel.BrAmountAndProductViewModel
import com.pagonxt.sdk.uxal.brazil.viewmodel.BrCardReadingViewModel
import com.pagonxt.sdk.uxal.brazil.viewmodel.BrPaymentSuccessViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun BrSaleNavGraph(
    navController: NavHostController,
    sdkConfig: SdkUiNavigationConfig
) {
    fun navigateWithInterceptor(currentRoute: BrSdkRoutes, defaultNextRoute: BrSdkRoutes) {
        val targetRoute = sdkConfig.interceptor?.overrideNextRoute(
            currentRoute = currentRoute,
            defaultNextRoute = defaultNextRoute
        ) ?: defaultNextRoute

        navController.navigate(targetRoute)
    }

    NavHost(
        navController = navController,
        startDestination = BrSdkRoutes.AmountAndProduct
    ) {

        composable<BrSdkRoutes.AmountAndProduct> {
            val viewModel: BrAmountAndProductViewModel = koinViewModel()
            val state by viewModel.state.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) {
                viewModel.effects.collect { effect ->
                    when (effect) {
                        is BrAmountAndProductViewEffect.NavigateToNextStep -> {
                            navigateWithInterceptor(BrSdkRoutes.AmountAndProduct, BrSdkRoutes.CardReading)
                        }
                        is BrAmountAndProductViewEffect.NavigateBack -> {
                            navController.popBackStack()
                        }
                    }
                }
            }

            BrAmountAndProductSelection(
                state = state,
                onEvent = viewModel::processEvent
            )
        }

        composable<BrSdkRoutes.CardReading> {
            val viewModel: BrCardReadingViewModel = koinViewModel()
            val state by viewModel.state.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) {
                viewModel.effects.collect { effect ->
                    when (effect) {
                        is BrCardReadingViewEffect.NavigateToNextStep -> {
                            navigateWithInterceptor(BrSdkRoutes.CardReading, BrSdkRoutes.PaymentSuccess)
                        }
                        is BrCardReadingViewEffect.NavigateBack -> {
                            navController.popBackStack()
                        }
                    }
                }
            }

            BrCardReadingScreen(
                state = state,
                onEvent = viewModel::processEvent
            )
        }

        composable<BrSdkRoutes.PaymentSuccess> {
            val viewModel: BrPaymentSuccessViewModel = koinViewModel()
            val state by viewModel.state.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) {
                viewModel.effects.collect { effect ->
                    when (effect) {
                        is BrPaymentSuccessViewEffect.NavigateToHome -> {
                            navController.popBackStack(navController.graph.startDestinationId, inclusive = false)
                        }
                    }
                }
            }

            BrPaymentSuccessScreen(
                state = state,
                onEvent = viewModel::processEvent
            )
        }

        // SLOT API: INJECT CUSTOM CLIENT SCREENS ---
        sdkConfig.customScreens.forEach { (routeClass, screenContent) ->
            composable(route = routeClass.qualifiedName!!) {
                screenContent { nextSdkRouteInstance ->
                    navController.navigate(nextSdkRouteInstance) {
                        popUpTo(routeClass.qualifiedName!!) { inclusive = true }
                    }
                }
            }
        }
    }
}