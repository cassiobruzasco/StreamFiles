package com.pagonxt.sdk.uxal.brazil.utils

import java.util.Locale

val BRAZIL_LOCALE: Locale = Locale.forLanguageTag("pt-BR")