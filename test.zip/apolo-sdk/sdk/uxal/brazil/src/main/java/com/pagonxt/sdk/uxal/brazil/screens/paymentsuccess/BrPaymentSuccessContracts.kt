package com.pagonxt.sdk.uxal.brazil.screens.paymentsuccess

import com.pagonxt.sdk.core.presentation.mvi.ViewEffect
import com.pagonxt.sdk.core.presentation.mvi.ViewEvent
import com.pagonxt.sdk.core.presentation.mvi.ViewState

/**
 * State representing the final approved receipt info.
 */
data class BrPaymentSuccessViewState(
    val formattedAmount: String = "",
    val paymentMethodName: String = "",
    val successMessage: String? = null,
    val viewEffect: BrPaymentSuccessViewEffect? = null,
) : ViewState

sealed interface BrPaymentSuccessViewEvent : ViewEvent {
    data object OnFinishClicked : BrPaymentSuccessViewEvent
}

sealed interface BrPaymentSuccessViewEffect : ViewEffect {
    data object NavigateToHome : BrPaymentSuccessViewEffect
}