package com.pagonxt.sdk.uxal.brazil.screens.cardreading

import com.pagonxt.sdk.core.presentation.mvi.ViewEffect
import com.pagonxt.sdk.core.presentation.mvi.ViewEvent
import com.pagonxt.sdk.core.presentation.mvi.ViewState

/**
 * Immutable state of the Card Reading screen.
 * The UI only reads this and renders itself.
 */
data class BrCardReadingViewState(
    val showHeader: Boolean = false,
    val amountFormatted: String = "",
    val paymentMethodName: String = "",
    val instructionMessage: String = "",
    val errorMessage: String? = null,
    val isLoading: Boolean = false,
    val viewEffect: BrCardReadingViewEffect? = null
) : ViewState

/**
 * User actions triggered from the Card Reading screen.
 */
sealed interface BrCardReadingViewEvent : ViewEvent {
    data object OnCancelClicked : BrCardReadingViewEvent
    data object ConsumeEffect : BrCardReadingViewEvent
}

/**
 * One-shot actions (like navigation) for the Card Reading screen.
 */
sealed interface BrCardReadingViewEffect : ViewEffect {
    data object NavigateBack : BrCardReadingViewEffect
    data class NavigateToNextStep(val route: String) : BrCardReadingViewEffect
}