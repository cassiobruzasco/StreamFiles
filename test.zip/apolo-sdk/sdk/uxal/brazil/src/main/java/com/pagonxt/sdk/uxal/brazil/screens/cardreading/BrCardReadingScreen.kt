package com.pagonxt.sdk.uxal.brazil.screens.cardreading

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagonxt.sdk.uxal.ui_common.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun BrCardReadingScreen(
    state: BrCardReadingViewState,
    onEvent: (BrCardReadingViewEvent) -> Unit
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                title = {
                    Text(
                        text = "Leitura de Cartão", // Idealmente via CompositionLocal de strings
                        textAlign = TextAlign.Center
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { onEvent(BrCardReadingViewEvent.OnCancelClicked) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header is completely controlled by the State
            if (state.showHeader) {
                HeaderSection(
                    amountFormatted = state.amountFormatted,
                    paymentMethodName = state.paymentMethodName
                )
                HorizontalDivider(color = Color.LightGray, thickness = 1.dp)
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tap_to_pay),
                    contentDescription = "Terminal",
                    modifier = Modifier
                        .aspectRatio(1f)
                        .weight(1f, fill = false),
                    contentScale = ContentScale.Fit
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.padding(bottom = 24.dp)) {
                        if (!state.errorMessage.isNullOrEmpty()) {
                            Text(
                                text = state.errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 16.sp
                            )
                        } else if (state.instructionMessage.isNotEmpty()) {
                            Text(
                                text = state.instructionMessage,
                                fontSize = 16.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = { onEvent(BrCardReadingViewEvent.OnCancelClicked) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primaryContainer),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    ) {
                        Text(
                            text = "Cancelar",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderSection(
    amountFormatted: String,
    paymentMethodName: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = "Valor", fontSize = 14.sp)
            Text(
                text = amountFormatted,
                color = Color.Black,
                fontSize = 24.sp,
                fontWeight = FontWeight.Normal
            )
        }

        if (paymentMethodName.isNotEmpty()) {
            Surface(
                color = Color(0xFFE0E0E0),
                shape = RoundedCornerShape(50),
                modifier = Modifier.height(30.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = paymentMethodName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}