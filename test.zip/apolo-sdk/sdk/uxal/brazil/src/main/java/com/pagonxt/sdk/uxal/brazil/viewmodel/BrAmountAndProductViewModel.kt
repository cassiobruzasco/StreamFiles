package com.pagonxt.sdk.uxal.brazil.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.core.presentation.mvi.BaseMviViewModel
import com.pagonxt.sdk.core.presentation.mvi.MviContract
import com.pagonxt.sdk.uxal.brazil.screens.amountandproduct.BrAmountAndProductViewEffect
import com.pagonxt.sdk.uxal.brazil.screens.amountandproduct.BrAmountAndProductViewEvent
import com.pagonxt.sdk.uxal.brazil.screens.amountandproduct.BrAmountAndProductViewState
import com.pagonxt.sdk.uxal.ui_common.utils.toCurrencyString
import com.pagonxt.sdk.uxal.brazil.utils.BRAZIL_LOCALE
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BrAmountAndProductViewModel(
    private val repository: BrTransactionRepository
) : BaseMviViewModel<BrAmountAndProductViewEvent, BrAmountAndProductViewState, BrAmountAndProductViewEffect>() {

    private val _uiStateFlow = MutableStateFlow(BrAmountAndProductViewState())

    private val _effects = MutableSharedFlow<BrAmountAndProductViewEffect>()
    override val effects: SharedFlow<BrAmountAndProductViewEffect> = _effects.asSharedFlow()

    override val state: StateFlow<BrAmountAndProductViewState> = combine(
        _uiStateFlow,
        repository.params
    ) { uiState, params ->
        uiState.copy(
            formattedAmount = params.amountInCents.toCurrencyString(BRAZIL_LOCALE),
            isAmountValid = params.amountInCents > 0
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = BrAmountAndProductViewState()
    )

    override fun processEvent(event: BrAmountAndProductViewEvent) {
        when (event) {
            is BrAmountAndProductViewEvent.OnBackClicked -> handleBack()
            is BrAmountAndProductViewEvent.OnPaymentMethodSelected -> handlePaymentMethod(event.method)
        }
    }

    private fun handlePaymentMethod(method: BrSaleMethod) {
        viewModelScope.launch {
            repository.updatePaymentMethod(method)
            repository.beginTransaction()
            _effects.emit(BrAmountAndProductViewEffect.NavigateToNextStep("BrSdkRoutes.CardReading"))
        }
    }

    private fun handleBack() {
        viewModelScope.launch {
            _effects.emit(BrAmountAndProductViewEffect.NavigateBack)
        }
    }
}