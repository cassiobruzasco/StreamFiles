package com.pagonxt.sdk.uxal.brazil.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pagonxt.sdk.brazil.payment.domain.models.BrSaleMethod
import com.pagonxt.sdk.brazil.payment.domain.repository.BrTransactionRepository
import com.pagonxt.sdk.brazil.payment.domain.usecases.BrRequestCardCaptureUseCase
import com.pagonxt.sdk.brazil.payment.domain.usecases.CardCaptureResult
import com.pagonxt.sdk.core.presentation.mvi.BaseMviViewModel
import com.pagonxt.sdk.core.presentation.mvi.MviContract
import com.pagonxt.sdk.uxal.brazil.screens.cardreading.BrCardReadingViewEffect
import com.pagonxt.sdk.uxal.brazil.screens.cardreading.BrCardReadingViewEvent
import com.pagonxt.sdk.uxal.brazil.screens.cardreading.BrCardReadingViewState
import com.pagonxt.sdk.uxal.brazil.utils.BRAZIL_LOCALE
import com.pagonxt.sdk.uxal.ui_common.utils.toCurrencyString
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BrCardReadingViewModel(
    repository: BrTransactionRepository,
    private val requestCardCaptureUseCase: BrRequestCardCaptureUseCase
) : BaseMviViewModel<BrCardReadingViewEvent, BrCardReadingViewState, BrCardReadingViewEffect>() {

    private val _viewState = MutableStateFlow(BrCardReadingViewState())

    private val _effects = MutableSharedFlow<BrCardReadingViewEffect>()
    override val effects: SharedFlow<BrCardReadingViewEffect> = _effects.asSharedFlow()

    override val state: StateFlow<BrCardReadingViewState> = combine(
        _viewState,
        repository.currentTransaction
    ) { uiState, transaction ->
        val isAmountValid = (transaction?.amountInCents ?: 0) > 0
        uiState.copy(
            showHeader = isAmountValid,
            amountFormatted = (transaction?.amountInCents ?: 0).toCurrencyString(BRAZIL_LOCALE),
            paymentMethodName = mapPaymentMethodName(transaction?.params?.paymentMethod),
            instructionMessage = if (uiState.isLoading) "Processing..." else "Tap, insert, or swipe your card.",
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = BrCardReadingViewState()
    )

    init {
        startCardReading()
    }

    override fun processEvent(event: BrCardReadingViewEvent) {
        when (event) {
            is BrCardReadingViewEvent.OnCancelClicked -> handleCancel()
            BrCardReadingViewEvent.ConsumeEffect -> {
            }
        }
    }

    private fun startCardReading() {
        if (_viewState.value.isLoading) return

        viewModelScope.launch {
            _viewState.update { it.copy(isLoading = true, errorMessage = null) }

            when (val result = requestCardCaptureUseCase()) {
                is CardCaptureResult.Success -> {
                    _viewState.update { it.copy(isLoading = false) }
                    _effects.emit(BrCardReadingViewEffect.NavigateToNextStep("Routes.EmvProcessing"))
                }
                is CardCaptureResult.HardwareError -> {
                    _viewState.update { it.copy(isLoading = false, errorMessage = "Failed to read card: ${result.code}") }
                }
                is CardCaptureResult.InvalidAmount -> {
                    _viewState.update { it.copy(isLoading = false, errorMessage = "Amount is invalid.") }
                }

                is CardCaptureResult.HaltedByInterceptor -> {
                    // Exemplo com interceptor (se o seu use case tiver)
                }
            }
        }
    }

    private fun handleCancel() {
        viewModelScope.launch {
            _effects.emit(BrCardReadingViewEffect.NavigateBack)
        }
    }

    private fun mapPaymentMethodName(method: BrSaleMethod?): String {
        return when (method) {
            is BrSaleMethod.CreditCard -> "Credit"
            is BrSaleMethod.DebitCard -> "Debit"
            is BrSaleMethod.Voucher -> "Voucher"
            is BrSaleMethod.Pix -> "PIX"
            else -> ""
        }
    }
}