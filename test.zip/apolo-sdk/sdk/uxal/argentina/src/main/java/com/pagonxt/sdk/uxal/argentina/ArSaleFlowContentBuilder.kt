package com.pagonxt.sdk.uxal.argentina

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.pagonxt.sdk.core.flow.sale.SaleFlowIntent
import com.pagonxt.sdk.core.flow.sale.SaleFlowState
import com.pagonxt.sdk.uxal.argentina.screens.ArAmountAndProductSelection
import com.pagonxt.sdk.uxal.argentina.screens.ArAmountAndProductSelectionContract
import com.pagonxt.sdk.uxal.argentina.screens.ArTipDefinition
import com.pagonxt.sdk.uxal.argentina.screens.ArTipDefinitionContract
import com.pagonxt.sdk.core.uxal.ContentBuilder
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.payment.sale.ArSaleFlowIntent
import com.pagonxt.sdk.payment.sale.ArSaleFlowState

/**
 * Implementação da tela de fluxo de venda (Sale) específica para a Argentina.
 *
 * Esta classe é a peça central da camada de UXAL (User eXperience Abstraction Layer) para o país.
 * Ela atua como um **Adaptador** e **Roteador**, conectando a lógica de negócios do módulo
 * de pagamento (`payment/argentina`) com as implementações de UI.
 *
 * ## Arquitetura e Desacoplamento
 *
 * 1.  **Abstração vs. Concretude:** A classe implementa a interface genérica `ContentBuilder<SaleFlowState, SaleFlowIntent>`.
 *     Isso permite que o núcleo do SDK trabalhe com a abstração sem conhecer os detalhes da Argentina.
 *
 * 2.  **Roteamento de Estado:** `Content` recebe o `flowState` abstrato. Ele usa um `when` para
 *     identificar o tipo concreto do estado (ex: `ArSaleFlowState.AmountDefinition`, `ArSaleFlowState.TipDefinition`)
 *     e renderizar a tela Composable apropriada para aquele estado.
 *
 * 3.  **Tradução de Intenção:** As telas de UI internas (ex: `AmountAndProductScreen`, `TipCalculatorScreen`)
 *     emitem intenções de UI locais. Esta classe intercepta essas intenções e as traduz para as
 *     intenções de fluxo de negócio (`ArSaleFlowIntent`) que o `SaleEngineImpl` da Argentina espera.
 *
 * Este padrão garante um forte desacoplamento entre a lógica de negócios (como os estados são
 * definidos e quando eles mudam) e a apresentação da UI (como cada estado é renderizado).
 * Para adicionar suporte a um novo país, um desenvolvedor precisaria criar um `SaleScreen`
 * similar, mapeando os estados e intenções daquele país para suas respectivas telas.
 */
class ArSaleFlowContentBuilder() : ContentBuilder<SaleFlowState, SaleFlowIntent> {

    @Composable
    override fun Content(
        resourceResolver: ResourceResolver,
        flowState: SaleFlowState,
        onIntent: (SaleFlowIntent) -> Unit,
        onExit: () -> Unit
    ) {
        // Roteia o estado de fluxo abstrato para a tela concreta apropriada.
        return when (flowState) {
            is SaleFlowState.InitialState,
            is ArSaleFlowState.AmountDefinition,
            is ArSaleFlowState.ProductDefinition.Selection -> {
                ArAmountAndProductSelection(
                    resourceResolver,
                    // Mapeia o estado de fluxo para o estado de UI que a tela espera.
                    remember(flowState) {
                        when (flowState) {
                            is ArSaleFlowState.AmountDefinition.ValidAmount -> ArAmountAndProductSelectionContract.ViewData(
                                amountInCents = flowState.newAmountInCents,
                            )

                            is ArSaleFlowState.AmountDefinition.InvalidAmount -> ArAmountAndProductSelectionContract.ViewData(
                                amountInCents = flowState.lastValidAmount
                            )

                            is ArSaleFlowState.ProductDefinition.Selection -> ArAmountAndProductSelectionContract.ViewData(
                                amountInCents = flowState.amount
                            )

                            else -> ArAmountAndProductSelectionContract.ViewData(0)
                        }
                    },
                    // Traduz a intenção da UI para uma intenção de fluxo de negócio.
                    onAction = { localIntent ->
                        when (localIntent) {
                            is ArAmountAndProductSelectionContract.ViewAction.ChangeAmount -> onIntent(
                                ArSaleFlowIntent.ChangeAmount(
                                    localIntent.value
                                )
                            )

                            is ArAmountAndProductSelectionContract.ViewAction.SelectPayment -> onIntent(
                                ArSaleFlowIntent.ProductSelect(localIntent.method)
                            )

                            is ArAmountAndProductSelectionContract.ViewAction.BackClicked -> {
                                onExit()
                            }
                        }
                    })
            }

            is ArSaleFlowState.ProductDefinition.Selected,
            is ArSaleFlowState.TipDefinition -> {
                ArTipDefinition(
                    resourceResolver,
                    state = remember(flowState) {
                        when (flowState) {
                            is ArSaleFlowState.ProductDefinition.Selected -> ArTipDefinitionContract.ViewData.Initial(
                                flowState.amount
                            )

                            is ArSaleFlowState.TipDefinition.InvalidTip -> ArTipDefinitionContract.ViewData.Invalid(
                                flowState.amount,
                            )

                            is ArSaleFlowState.TipDefinition.ValidTip -> ArTipDefinitionContract.ViewData.Definition(
                                flowState.tipPercentage,
                                flowState.tipAmountInCents,
                                flowState.newAmountInCents,
                                flowState.baseAmountInCents
                            )

                            else -> {
                                TODO()
                            }
                        }
                    },
                    onAction = { uiIntent ->
                        when (uiIntent) {
                            ArTipDefinitionContract.ViewAction.GoNext -> onIntent(ArSaleFlowIntent.RequestCard)
                            is ArTipDefinitionContract.ViewAction.SetPercentage -> onIntent(
                                ArSaleFlowIntent.TipDefinition.SetPercentage(
                                    uiIntent.percentage
                                )
                            )

                            is ArTipDefinitionContract.ViewAction.SetTipAmount -> onIntent(
                                ArSaleFlowIntent.TipDefinition.SetAmount(
                                    uiIntent.amount
                                )
                            )

                            ArTipDefinitionContract.ViewAction.Return -> onIntent(
                                ArSaleFlowIntent.ChangeAmount(-1)
                            )
                        }
                    })
            }

            // Tela de fallback para estados que ainda não têm uma UI implementada.
            else -> {
                Column(
                    modifier = Modifier.Companion.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.Companion.CenterHorizontally
                ) {
                    Text(text = "Por favor espere, pantalla en construcción.")
                }
            }
        }

    }
}