package com.pagonxt.sdk.uxal.argentina.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.Composable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.uxal.R
import com.pagonxt.sdk.uxal.ui_common.services.ResourceResolverImpl
import com.pagonxt.sdk.uxal.ui_common.services.WhiteLabelConfig

internal object ArCardReadingContract {
    data class ViewData(
        val amountInCents: Long,
        val instructionMessage: String?,
        val errorMessage: String? = null,
    )

    sealed class ViewAction {
        data object Canceled : ViewAction()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ArCardReading(
    resourceResolver: ResourceResolver,
    state: ArCardReadingContract.ViewData,
    onAction: (ArCardReadingContract.ViewAction) -> Unit
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                title = {
                    Text(
                        resourceResolver.resolveText("uxal_ar_card_reading_screen_title"),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        onAction(ArCardReadingContract.ViewAction.Canceled)
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tap_to_pay),
                    contentDescription = "Terminal",
                    modifier = Modifier
                        .aspectRatio(1f)
                        .weight(1f, fill = false),
                    contentScale = ContentScale.Fit
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        if (state.errorMessage?.isNotEmpty() == true)
                            Text(
                                text = state.errorMessage,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 16.sp
                            )
                        else if (state.instructionMessage?.isNotEmpty() == true)
                            Text(
                                text = state.instructionMessage,
                                fontSize = 16.sp
                            )
                    }

                    OutlinedButton(
                        onClick = { onAction(ArCardReadingContract.ViewAction.Canceled) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.primaryContainer
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    ) {
                        Text(
                            text = resourceResolver.resolveText("uxal_ar_card_reading_cancel"),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}


@Preview(showBackground = true, heightDp = 650, widthDp = 380)
@Composable
fun ArCardReadingPreview() {
    MaterialTheme {
        ArCardReading(
            state = ArCardReadingContract.ViewData(
                0,
                "Mensagem de Status"
            ),
            onAction = {},
            resourceResolver = ResourceResolverImpl(
                LocalContext.current,
                WhiteLabelConfig(emptyMap(), emptyMap())
            )
        )
    }
}