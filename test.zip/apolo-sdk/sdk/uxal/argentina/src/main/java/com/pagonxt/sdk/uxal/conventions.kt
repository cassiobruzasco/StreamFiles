package com.pagonxt.sdk.uxal

import com.pagonxt.sdk.uxal.argentina.ArSaleFlowContentBuilder

typealias SaleFlowBuilder = ArSaleFlowContentBuilder
