package com.pagonxt.sdk.uxal.argentina.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagonxt.sdk.core.utils.asCents
import com.pagonxt.sdk.core.utils.asMoney
import com.pagonxt.sdk.core.utils.bd
import com.pagonxt.sdk.core.utils.percent
import com.pagonxt.sdk.core.utils.percentageOf
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.uxal.argentina.utils.ARGENTINA_LOCALE
import com.pagonxt.sdk.uxal.ui_common.services.ResourceResolverImpl
import com.pagonxt.sdk.uxal.ui_common.services.WhiteLabelConfig
import com.pagonxt.sdk.uxal.ui_common.utils.CurrencyUtils
import java.math.BigDecimal
import java.util.Locale

object ArTipDefinitionContract {
    sealed class ViewData {
        data class Initial(
            val amount: Long
        ) : ViewData()

        data class Definition(
            val percentage: BigDecimal,
            val tipAmountInCents: Long,
            val newAmountInCents: Long,
            val baseAmountInCents: Long
        ) : ViewData()

        data class Invalid(
            val baseAmountInCents: Long
        ) : ViewData()
    }

    sealed class ViewAction {
        data class SetPercentage(
            val percentage: BigDecimal
        ) : ViewAction()

        data class SetTipAmount(
            val amount: Long
        ) : ViewAction()

        data object GoNext : ViewAction()
        data object Return : ViewAction()
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArTipDefinition(
    resourceResolver: ResourceResolver,
    state: ArTipDefinitionContract.ViewData,
    onAction: (ArTipDefinitionContract.ViewAction) -> Unit = {}
) {
    val decimalRegex = Regex("^\\d*\\.?\\d{0,2}$")

    var baseAmount by remember {
        mutableStateOf(BigDecimal("0"))
    }
    var newAmount by remember {
        mutableStateOf(BigDecimal("0"))
    }
    var invalid by remember(state) {
        mutableStateOf(false)
    }

    when (state) {
        is ArTipDefinitionContract.ViewData.Definition -> {
            newAmount = state.newAmountInCents.asMoney
            baseAmount = state.baseAmountInCents.asMoney
        }

        is ArTipDefinitionContract.ViewData.Initial -> {
            baseAmount = state.amount.asMoney
        }

        is ArTipDefinitionContract.ViewData.Invalid -> {
            invalid = true
        }
    }

    var percentText by remember {
        mutableStateOf("")
    }
    var valueText by remember {
        mutableStateOf("")
    }

    val focusManager = LocalFocusManager.current

    val totalWithTip = newAmount

    fun updateFromPercent(percentStr: String) {
        percentText = percentStr
        if (percentStr == "") {
            valueText = ""
            onAction(ArTipDefinitionContract.ViewAction.SetPercentage(0.bd))
            return
        }
        val p = percentStr.toBigDecimalOrNull()
        if (p != null) {
            val calculatedValue = baseAmount percent p
            valueText = CurrencyUtils.getValueOnly(calculatedValue, ARGENTINA_LOCALE)
            onAction(ArTipDefinitionContract.ViewAction.SetPercentage(p))
        } else {
            valueText = ""
            invalid = true
        }
    }

    fun updateFromValue(valueStr: String) {
        valueText = valueStr
        if (valueStr == "") {
            percentText = ""
            onAction(ArTipDefinitionContract.ViewAction.SetTipAmount(0))
            return
        }
        val v = valueStr.toBigDecimalOrNull()
        if (v != null) {
            val calculatedPercent = v.asCents percentageOf baseAmount.asCents
            percentText = String.format(Locale.US, "%.2f", calculatedPercent)
            onAction(ArTipDefinitionContract.ViewAction.SetTipAmount(v.asCents))
        } else {
            percentText = ""
            invalid = true
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                title = {
                    Text(
                        resourceResolver.resolveText("uxal_ar_propina_title"),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        onAction(ArTipDefinitionContract.ViewAction.Return)
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
        bottomBar = {
            Button(
                onClick = { onAction(ArTipDefinitionContract.ViewAction.GoNext) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                enabled = !invalid
            ) {
                Text(
                    text = resourceResolver.resolveText("uxal_ar_propina_continuar"),
                    fontSize = 18.sp
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = resourceResolver.resolveText("uxal_ar_propina_label1"),
                        style = MaterialTheme.typography.labelLarge
                    )
                    Text(
                        text = CurrencyUtils.getValue(baseAmount, ARGENTINA_LOCALE),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(
                            alpha = 0.2f
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = resourceResolver.resolveText("uxal_ar_propina_label2"),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = CurrencyUtils.getValue(totalWithTip, ARGENTINA_LOCALE),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Text(
                text = resourceResolver.resolveText("uxal_ar_propina_sugerencias"),
                style = MaterialTheme.typography.titleSmall
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val percentages = listOf(5, 10, 15, 20)
                percentages.forEach { percent ->
                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            updateFromPercent(percent.toString())
                        },
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(text = "$percent%")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = percentText,
                    onValueChange = {
                        val sanitizedInput = it.replace(",", ".")

                        if (sanitizedInput.isEmpty() || sanitizedInput.matches(decimalRegex)) {
                            updateFromPercent(sanitizedInput)
                        }
                    },
                    label = {
                        Text(
                            resourceResolver.resolveText("uxal_ar_propina_percentaje"),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    suffix = { Text("%") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    isError = invalid,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textAlign = TextAlign.End)
                )

                OutlinedTextField(
                    value = valueText,
                    onValueChange = {

                        val sanitizedInput = it.replace(",", ".")

                        if (sanitizedInput.isEmpty() || sanitizedInput.matches(decimalRegex)) {
                            updateFromValue(sanitizedInput)
                        }
                    },
                    label = {
                        Text(
                            resourceResolver.resolveText("uxal_ar_propina_importe"),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    prefix = { Text("$ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    isError = invalid,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(textAlign = TextAlign.End)
                )
            }
        }
    }
}

@Preview(showBackground = true, heightDp = 650, widthDp = 380)
@Composable
fun PreviewArTipScreen() {
    MaterialTheme {
        ArTipDefinition(
            resourceResolver = ResourceResolverImpl(
                LocalContext.current,
                WhiteLabelConfig(emptyMap(), emptyMap())
            ),
            ArTipDefinitionContract.ViewData.Initial(100)
        )
    }
}