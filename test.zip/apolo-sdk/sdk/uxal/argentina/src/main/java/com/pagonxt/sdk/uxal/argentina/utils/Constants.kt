package com.pagonxt.sdk.uxal.argentina.utils

import java.util.Locale

internal val ARGENTINA_LOCALE = Locale.forLanguageTag("es-AR")