@file:OptIn(ExperimentalMaterial3Api::class)

package com.pagonxt.sdk.uxal.argentina.screens

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pagonxt.sdk.core.uxal.ResourceResolver
import com.pagonxt.sdk.payment.sale.ArSaleMethod
import com.pagonxt.sdk.uxal.argentina.utils.ARGENTINA_LOCALE
import com.pagonxt.sdk.uxal.ui_common.components.KeyType
import com.pagonxt.sdk.uxal.ui_common.components.Keypad
import com.pagonxt.sdk.uxal.ui_common.components.KeypadKey
import com.pagonxt.sdk.uxal.ui_common.services.ResourceResolverImpl
import com.pagonxt.sdk.uxal.ui_common.services.WhiteLabelConfig
import com.pagonxt.sdk.uxal.ui_common.utils.CurrencyUtils
import com.pagonxt.sdk.uxal.ui_common.utils.toComposeColor
import com.pagonxt.sdk.uxal.ui_common.vectors.backspace

object ArAmountAndProductSelectionContract {
    data class ViewData(
        val amountInCents: Long,
        val errorMessage: String? = null
    )

    sealed class ViewAction {
        data class ChangeAmount(val value: Long) : ViewAction()
        data class SelectPayment(val method: ArSaleMethod) : ViewAction()
        data object BackClicked : ViewAction()
    }
}

@Composable
fun ArAmountAndProductSelection(
    resourceResolver: ResourceResolver,
    state: ArAmountAndProductSelectionContract.ViewData,
    onAction: (ArAmountAndProductSelectionContract.ViewAction) -> Unit
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                title = {
                    Text(
                        resourceResolver.resolveText("uxal_ar_sale_title"),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        onAction(ArAmountAndProductSelectionContract.ViewAction.BackClicked)
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.weight(1f))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 24.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.Top, modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Text(
                        text = CurrencyUtils.getSymbol(ARGENTINA_LOCALE),
                        fontSize = 24.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 8.dp, end = 4.dp)
                    )
                    Text(
                        text = CurrencyUtils.getValueOnly(state.amountInCents, ARGENTINA_LOCALE),
                        fontSize = 64.sp, color = Color.Gray, fontWeight = FontWeight.Light
                    )
                }
                if (state.errorMessage?.isNotEmpty() == true) {
                    Text(
                        text = state.errorMessage, color = Color.Red
                    )
                }
            }

            Keypad(
                onKeyClick = {
                    Log.d("SaleScreen", "onKeyClick: $it")
                    var amount: Long = state.amountInCents
                    when (it.label) {
                        in 0..9 -> {
                            amount = (amount * 10) + (it.label as Number).toLong()
                        }

                        "backspace" -> {
                            amount /= 10
                        }

                        "00" -> {
                            amount = (amount * 100)
                        }
                    }
                    onAction(ArAmountAndProductSelectionContract.ViewAction.ChangeAmount(amount))
                },
                action1 = KeypadKey(
                    label = "backspace",
                    description = "Apagar",
                    type = KeyType.Action,
                    icon = backspace,
                    drawColor = resourceResolver.resolveColor("uxal_ar_color_keypad_custom")
                        .toComposeColor()
                ),
                action2 = KeypadKey(
                    label = "00",
                    description = "Duplo Zero",
                    type = KeyType.Action,
                    drawColor = resourceResolver.resolveColor("uxal_ar_color_keypad_custom")
                        .toComposeColor()
                ),
            )

            Spacer(modifier = Modifier.weight(1f))

            Text(
                text = resourceResolver.resolveText("uxal_ar_sale_product_selection"),
                fontSize = 14.sp,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                PaymentButton(
                    resourceResolver.resolveText("uxal_ar_sale_tarjeta"),
                    Icons.Default.CreditCard,
                    onTap = {
                        onAction(
                            ArAmountAndProductSelectionContract.ViewAction.SelectPayment(
                                ArSaleMethod.CREDIT_CARD
                            )
                        )
                    })
                PaymentButton(
                    resourceResolver.resolveText("uxal_ar_sale_qrcode"),
                    Icons.Default.QrCode,
                    onTap = {
                        onAction(
                            ArAmountAndProductSelectionContract.ViewAction.SelectPayment(
                                ArSaleMethod.QR_CODE
                            )
                        )
                    })
            }
        }
    }
}

@Composable
fun PaymentButton(text: String, icon: ImageVector, onTap: () -> Unit = {}) {
    Column(
        modifier = Modifier
            .size(80.dp)
            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
            .background(Color.White, RoundedCornerShape(8.dp))
            .clickable {
                onTap()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = text, fontSize = 12.sp, color = Color.Gray)
    }
}

@Preview(showBackground = true, heightDp = 650, widthDp = 380)
@Composable
fun PreviewSalesSelectionAr() {
    MaterialTheme {
        ArAmountAndProductSelection(
            state = ArAmountAndProductSelectionContract.ViewData(
                amountInCents = 120
            ),
            onAction = {},
            resourceResolver = ResourceResolverImpl(
                LocalContext.current,
                WhiteLabelConfig(emptyMap(), emptyMap())
            )
        )
    }
}
