fun getPropertyOrEnv(key: String, envKey: String): String? =
    settings.extra[key] as String? ?: System.getenv(envKey)

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        mavenLocal()
        google()
        mavenCentral()
        maven {
            url = uri("https://artefatosgetnetbr.jfrog.io/artifactory/maven-virtual/")
            credentials {
                username = getPropertyOrEnv("artifactory_user", "ARTIFACTORY_USER")
                password = getPropertyOrEnv("artifactory_password", "ARTIFACTORY_PASSWORD")
            }
        }
    }
}

rootProject.name = "Payment App"
include(":sdk")
include(":sdk:core")
include(":sdk:hal")
include(":sdk:hal:middleware")
include(":sdk:uxal")
include(":sdk:uxal:ui-common")
include(":sdk:uxal:brazil")
include(":sdk:uxal:argentina")
include(":app-argentina")
include(":sdk:hal:brazil")
include(":sdk:hal:argentina")
include(":sdk:hal:core")
include(":sdk:common-utils")
include(":sdk:brazil")
include(":app-brazil")
